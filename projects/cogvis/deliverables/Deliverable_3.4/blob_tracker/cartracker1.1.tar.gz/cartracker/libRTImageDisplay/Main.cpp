#include <stdlib.h>
#include <pthread.h>
#include "ImageDisplay.h"
#include "ImageWindow.h"

/* prototypes */
int procMain(int, char**);
void *start_routine(void *arg);


/* globals */
pthread_t procThread;

pthread_mutex_t mut = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

bool request = false;
void (*createFirstWindow)();


/* local */
struct Args { int argc; char** argv; };


int main(int argc, char** argv) 
{
	Glow::Init(argc, argv);
	Args args = { argc,argv };

	pthread_mutex_init(&mut,NULL);
	pthread_create(&procThread, NULL, start_routine, &args);
	
	pthread_mutex_lock(&mut);
	{
		while (!request)
			pthread_cond_wait(&cond, &mut);
	}
	pthread_mutex_unlock(&mut);
	
	createFirstWindow();

	Glow::MainLoop();
	
	return 0;
}


void *start_routine(void *arg)
{
	Args* args = (Args*) arg;

	int retval = procMain(args->argc, args->argv);

	pthread_cond_destroy(&cond);
	pthread_mutex_destroy(&mut);
	
	exit(retval); 
	
	return 0;
}

