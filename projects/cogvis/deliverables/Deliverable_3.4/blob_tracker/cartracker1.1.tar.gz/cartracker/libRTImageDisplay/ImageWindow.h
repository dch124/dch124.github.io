#ifndef IMAGE_WINDOW_H
#define IMAGE_WINDOW_H

#include <GL/gl.h>
#include <GL/glu.h>
#include <glow.h>

#include "Image.h"


GLOW_NAMESPACE_USING

enum MouseActionType { MOUSE_DOWN, MOUSE_UP };


class ImageWindow : public GlowWindow
/**
  * An openGL/GLUT/GLOW window class that extends GlowWindow. Added 
  * functionality allows images (Image/ImageRGB/ImageGrey) to be piped into
  * the window and the display automatically refreshed with these images.
  * Public mouse handler and graphics handler callback function pointers
  * (and default functions) are included to add user functionality without
  * inheritance.
  */
{
public:
	
	bool		newContent;

        /// Pointer to mouse callback function (this may be user set)
        void            (*mouse_press)(Glow::MouseButton button,int x, int y,Glow::Modifiers modifiers, MouseActionType action);

	/// Pointer to mouse move callback function (this may be user set)
	void		(*mouse_move)(int x, int y);
	
        /// Pointer to graphics render callback function (this may be user set)
        void (*graphics_callback )(GlowComponent *parent) ; 

protected:
/* Protected Data Definitions */
	
	// Dimensions of the image
	unsigned int	width;		///< width of image to display
	unsigned int	height;		///< height of image to display
	unsigned int	size;
	float		scalefactor;
	bool 		size_changed;
	
	Image::Type	type;
	GLint		*pixels;
	GLubyte		*data;
	GLubyte		*data_bk;

        volatile bool   grab_display ;
        int             *gd_ptr ; 
	
public:
/* Public Methods */
	
	ImageWindow(int width, int height, const char* title);
	~ImageWindow(); 

        void set_display_type(Image::Type t){ type = t; };
	void operator << (ImageRGB&);
	void operator << (ImageGrey&);
	void operator << (Image&);
	void operator >> (ImageRGB&);
	void set_zoom(float zoom);
	float get_zoom(){return scalefactor;}	

protected:
/* Protected Methods */
	virtual void	OnEndPaint();
        virtual void	OnMouseDown(Glow::MouseButton button,
        		int x, int y,
        		Glow::Modifiers modifiers);
        virtual void 	OnMouseUp(Glow::MouseButton button,
                        int x, int y,
                        Glow::Modifiers modifiers);

	virtual void 	OnMouseMotion(int x, int y);
	void		repackRGB();
	void		repackGrey();

        void            grab_rgb() ;
};


#endif	// IMAGE_WINDOW_H
