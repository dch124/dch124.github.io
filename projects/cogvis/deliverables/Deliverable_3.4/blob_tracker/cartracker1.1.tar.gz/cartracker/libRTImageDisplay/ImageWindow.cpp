#include <glow.h>

#include "ImageWindow.h"

/**
 * A default mouse handler function which simply and not so usefully
 * prints Mouse button and (x,y) click coords to stderr.
 * In constructor mouse press is set to this.
 * *mouse_press is public and can (should) be set by a specific function
 * in procMain after initialising a window, e.g.
 *
 *       ImageDisplayWindow win1(width,height,"cam 1");
 *       win1.win->mouse_press = mouse_action ;            
 *
 * where mouse_action() has been declared before procMain for example like:
 *       void mouse_action(Glow::MouseButton button,int x, int y,
 *                         Glow::Modifiers modifiers, MouseActionType action)
 *       {
 *         if(button == Glow::leftButton && action == MOUSE_DOWN)
 *         cerr << "You have just pressed on (" << x << ',' << y << ")." << endl;
 *       }                                                                                    
**/
void default_mouse_handler(Glow::MouseButton button,
                              int x, int y,
                              Glow::Modifiers modifiers, MouseActionType action) 
{
    if(action == MOUSE_DOWN){
        if(button == Glow::leftButton){
                cerr << "Left Mouse (" << x << ',' << y << ')' << endl;
        }     
        if(button == Glow::middleButton){
                cerr << "Middle Mouse (" << x << ',' << y << ')' << endl;;
        }                                                     
        if(button == Glow::rightButton){
                cerr << "Right Mouse (" << x << ',' << y << ')' << endl;
        }                                                     
    }
/*
    if(action == MOUSE_UP){
        if(button == Glow::leftButton){
                cerr << "Left Up " << x << ' ' << y << ' ';
        }
        if(button == Glow::middleButton){
                cerr << "Middle Up" << x << ' ' << y << ' ';
        }
        if(button == Glow::rightButton){
                cerr << "Right Up " << x << ' ' << y << ' ';
        }                                                    
    }
*/
}

void default_mouse_move_handler(int x, int y){}

void default_graphics_callback(GlowComponent* parent)
/**
 * Default callback function for ImageWindow class (does nothing).
 *
 * @param parent a pointer to the parent window.
 */
{
}


ImageWindow::ImageWindow(int w, int h, const char* title )
{
        GlowWindowParams wp;

        grab_display = false ;
        graphics_callback = default_graphics_callback ;

        wp.width  = width  = w;
        wp.height = height = h;
        wp.title  = title;
        wp.eventMask = Glow::mouseEvents | Glow::motionEvents;

	scalefactor = 1;
        // allocate enough memory for greyscale and colour images
        size = width * height;
        data = new GLubyte[size * 3];
        data_bk = new GLubyte[size * 3];

        type = Image::COLOUR;
        newContent = false;

        ///Initialises the GlowWindow with the parameter set above
        GlowWindow::Init(wp);

        ///points mouse_press at a function, 
        ///note can use specific fns from elsewhere
        mouse_press = default_mouse_handler ;
	mouse_move = default_mouse_move_handler ;
}                               

ImageWindow::~ImageWindow()
{
	delete [] data;
	delete [] data_bk;
}

/**
 * Calls mouse_press() when the mouse is depressed :-(
**/
void ImageWindow::OnMouseDown(Glow::MouseButton button,
                              int x, int y,
                              Glow::Modifiers modifiers)
{
	mouse_press(button,x,y,modifiers,MOUSE_DOWN);
}

/**
 * Calls mouse_press() when the mouse is released :-) 
**/    
void ImageWindow::OnMouseUp(Glow::MouseButton button,
                              int x, int y,
                              Glow::Modifiers modifiers)
{
	mouse_press(button,x,y,modifiers,MOUSE_UP);
}

/**
 * Calls mouse_move() when mouse is moved
**/
void ImageWindow::OnMouseMotion(int x, int y)
{
	mouse_move(x,y);
}

void ImageWindow::OnEndPaint()
/**
 * Main window painting method.
 * WARNING: When inheriting from ImageWindow the display grabbing code at the
 * end of this method should be replicated in any replacement OnEndPaint()
 * method or the >> operator will not work properly! (i.e cause program to hang)
 */ 
{
#if 0
	static int total = 0, framecount = 0;
	static int start = Glow::GetMilliseconds(), end;
	
	end = Glow::GetMilliseconds();
	total += end - start;
	if (total > 1000) {
		cerr << framecount << " : ";
		framecount = 0;
		total -= 1000;
	}		

	start = Glow::GetMilliseconds();
	framecount++;
#endif
#if 0
	if (newContent) {
		if (type == Image::COLOUR) {
		       	repackRGB();
		} else {
			repackGrey();
		}


		newContent = false;
	}
#endif
	if(size_changed){
          Reshape((int)(width*scalefactor),(int)(height*scalefactor));
          glPixelZoom(scalefactor,scalefactor);
	  size_changed = false;
	}
	//So a none multiple of 4 width image is displayed properly (CJN)
	//Maybe should go in GLOW::Init(), but don't want to touch that! i
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	if(type == Image::COLOUR)	
            glDrawPixels(width, height, GL_RGB, GL_UNSIGNED_BYTE, data);
	else
            glDrawPixels(width, height, GL_LUMINANCE, GL_UNSIGNED_BYTE, data);


        graphics_callback(this) ;

	Refresh();


        // Grab display to buffer (if requested)
        if(grab_display){
            grab_rgb() ;

            grab_display = false ;
        }
}

void ImageWindow::grab_rgb()
/**
 * Grabs window buffer into rgb array gd_ptr
 */
{
//    glReadPixels(0,0, width, height, GL_RGB, GL_INT, gd_ptr) ;
    glReadPixels(0,0, width, height, GL_RGB, GL_UNSIGNED_BYTE, data_bk) ;

    GLubyte *d = data_bk + (size - width) * 3 ;
    GLint   *p = gd_ptr;

    // GL expects the array to start at the bottom left,
    // but the data starts at the top left
    for(unsigned int i = 0; i < height; i++, d -= 6 * width)
    {
        for (unsigned int j = 0; j < width; j++)
        {
                *(p++) = *(d++);
                *(p++) = *(d++);
                *(p++) = *(d++);
         }
    }


    cerr << "Grabbing RGB" << endl ;
}


void ImageWindow::operator >> (ImageRGB& img)
{
    grab_display = true ;
    gd_ptr = (int*)img.data ;

    while(grab_display) { }
}

void ImageWindow::operator << (ImageRGB& img)
{
        GLubyte *tmp_ptr ; 

	pixels = (GLint *)img.data;
	type = Image::COLOUR;
	newContent = true;
 	repackRGB();

	// Swap back and front buffer
	tmp_ptr = data_bk ;
	data_bk = data ;
	data = tmp_ptr ;
}


void ImageWindow::operator << (ImageGrey& img)
{
        GLubyte *tmp_ptr ; 

	pixels = (GLint*)img.brightness;
	type = Image::GREYSCALE;
	newContent = true;
	repackGrey();

	// Swap back and front buffer
	tmp_ptr = data_bk ;
	data_bk = data ;
	data = tmp_ptr ;
}


void ImageWindow::operator << (Image& img)
{	
	(type == Image::COLOUR)? *this << (ImageRGB&)img
                               : *this << (ImageGrey&)img;
	newContent = true;
}


void ImageWindow::repackRGB()
{
	GLubyte *d = data_bk + (size - width) * 3 ;
	GLint   *p = pixels;

	// GL expects the array to start at the bottom left,
	// but the data starts at the top left
	for(unsigned int i = 0; i < height; i++, d -= 6 * width)
	{
		for (unsigned int j = 0; j < width; j++)
		{
			*(d++) = *(p++);
			*(d++) = *(p++);
			*(d++) = *(p++);
		}
	}
}


void ImageWindow::repackGrey()
{
	GLubyte *d = data_bk + size - width ;
	GLint   *p = pixels;

	// GL expects the array to start at the bottom left,
	// but the data starts at the top left
	for(unsigned int i = 0; i < height; i++, d -= 2 * width)
	{
		for (unsigned int j = 0; j < width; j++, d++, p++) 
			*d = *p;
	}
}

void ImageWindow::set_zoom(float zoom)
{
	scalefactor = zoom;
	size_changed = true;
}



