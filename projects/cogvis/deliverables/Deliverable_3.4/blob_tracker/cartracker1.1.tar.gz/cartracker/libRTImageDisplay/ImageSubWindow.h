/** @file ImageSubWindow.h
 *
 * File containing class definition for the 'ImageSubWindow' class.
 *
 * The methods for this class can be found in ImageSubWindow.cpp
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Display Library (libRTImageDisplay)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/


#ifndef IMAGE_SUB_WINDOW_H
#define IMAGE_SUB_WINDOW_H

#include <GL/gl.h>
#include <GL/glu.h>
#include <glow.h>

#include "Image.h"


GLOW_NAMESPACE_USING

#include <ImageWindow.h>

class ImageSubWindow : public GlowSubwindow
/**
  * An image sub window class based on GlowSubwindow. This has all the 
  * functionality of ImageWindow but requires a container (based on
  * GlowWindow) to actually be displayed on the screen. The purpose of this
  * class is so multiple images (or an image not in the top left of the
  * window) may be displayed. If this is not the intention ImageWindow should
  * be used (it is much simpler as it requires no container class to be 
  * written!).
  */  
{
public:
	
        /// Mouse click calback routine 
        void            (*mouse_press)(Glow::MouseButton button,int x,
                                       int y,
                                       Glow::Modifiers modifiers,
                                       MouseActionType action);

        /// Graphics render callback routine 
        void            (*graphics_callback)(GlowComponent *parent);

protected:
/* Protected Data Definitions */
	
	// Dimensions of the image
	unsigned int	width;		///< width of image to display
	unsigned int	height;		///< height of image to display
	unsigned int	size;           ///< size of image (width*height) 

	Image::Type	type;           ///< Type of Image last used to update 
	GLint		*pixels;        ///< Pointer to image data 
	GLubyte		*data;          ///< Pixel data array 
	GLubyte		*data_bk;       ///< Back buffer pixel data array
	
        GlowComponent* parent_obj ;     ///< Pointer to the parent window
public:
/* Public Methods */
	
	ImageSubWindow(GlowComponent* parent,
                       int x, int y,
                       int width, int height);
	~ImageSubWindow(); 

        void set_display_type(Image::Type t){ type = t; };
	void operator << (ImageRGB&);
	void operator << (ImageGrey&);
	void operator << (Image&);

protected:
/* Protected Methods */
	virtual void	OnEndPaint();
        virtual void	OnMouseDown(Glow::MouseButton button,
        		int x, int y,
        		Glow::Modifiers modifiers);
        virtual void 	OnMouseUp(Glow::MouseButton button,
                        int x, int y,
                        Glow::Modifiers modifiers);

	void		repackRGB();
	void		repackGrey();
};


#endif	// IMAGE_WINDOW_H
