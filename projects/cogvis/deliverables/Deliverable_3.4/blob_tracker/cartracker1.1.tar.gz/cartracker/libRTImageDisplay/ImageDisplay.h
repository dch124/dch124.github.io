
#ifndef IMAGE_DISPLAY_H
#define IMAGE_DISPLAY_H

#include <glow.h>
#include <pthread.h>

#include "Image.h"


GLOW_NAMESPACE_USING

template< typename T >
class ImageDisplay
{
public:
/* Public Data Definitions */
	
	T*			win;
	
	static T*		windowId;
	static GlowWindowParams params;

public:
/* Public Methods */
	ImageDisplay(int width, int height, char* title);
	
	static void createWindow();

	void operator << (ImageRGB&  img) { *win << img; }
	void operator << (ImageGrey& img) { *win << img; }
	void operator << (Image&     img) { *win << img; }

};


/* Globals */
extern pthread_mutex_t mut;
extern pthread_cond_t cond;
extern bool request;
extern void (*createFirstWindow)();


/* Class Data Members */
template< typename T >
T* ImageDisplay< T >::windowId = 0;

template< typename T >
GlowWindowParams ImageDisplay< T >::params;
 

/* Class Methods */

template< typename T >
ImageDisplay< T >::ImageDisplay(int width, int height, char* title)
{
	pthread_mutex_lock(&mut);
	{
		while (request)
			pthread_cond_wait(&cond, &mut);
		
		params.width  = width;
		params.height = height;
		params.title  = title;
		
		request  = true;
		windowId = 0;

		createFirstWindow = createWindow;
		
		pthread_cond_signal(&cond);
	}
	pthread_mutex_unlock(&mut);

	Glow::SetIdleFunc(createWindow);

	pthread_mutex_lock(&mut);
	{
		while (request)
			pthread_cond_wait(&cond, &mut);

		win = windowId;
	}
	pthread_mutex_unlock(&mut);

	Glow::SetIdleFunc(NULL);
}


template< typename T>
void ImageDisplay< T >::createWindow( void )
{
	if (pthread_mutex_trylock(&mut)) return;
	if (request) {
		windowId = new T(params.width, params.height, params.title);
		request = false;
		pthread_cond_signal(&cond);
	}
	pthread_mutex_unlock(&mut);
}


#endif	// IMAGE_DISPLAY_H
