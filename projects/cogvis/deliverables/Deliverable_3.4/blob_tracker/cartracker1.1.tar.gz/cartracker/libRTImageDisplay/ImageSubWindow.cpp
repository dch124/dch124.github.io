/** @file ImageSubWindow.cpp
 *
 * File containing methods for the 'ImageSubWindow' class.
 *
 * The header for this class can be found in ImageSubWindow.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Display Library (libRTImageDisplay)
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following 
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#include <glow.h>

#include "ImageSubWindow.h"

// Use default mouse handler defined in ImageWindow.cpp
extern void default_mouse_handler(Glow::MouseButton button,
                              int x, int y,
                              Glow::Modifiers modifiers, 
                              MouseActionType action) ;

// Use default graphics render handler defined in ImageWindow.cpp
extern void default_graphics_callback(GlowComponent* parent) ;

ImageSubWindow::ImageSubWindow(GlowComponent* parent,
                               int x, int y,
                               int w, int h)
{
        GlowWindowParams wp;

        parent_obj = parent ;
        graphics_callback = default_graphics_callback ;

        wp.x = x ;
        wp.y = y ;
        wp.width  = width  = w;
        wp.height = height = h;
        wp.eventMask = Glow::mouseEvents;


        // allocate enough memory for greyscale and colour images
        size = width * height;
        data = new GLubyte[size * 3];
        data_bk = new GLubyte[size * 3];

        type = Image::COLOUR;

        ///Initialises the GlowWindow with the parameter set above
        GlowSubwindow::Init(parent,wp);

        ///points mouse_press at a function, 
        ///note can use specific fns from elsewhere
        mouse_press = default_mouse_handler ;
}                               

ImageSubWindow::~ImageSubWindow()
{
	delete [] data;
	delete [] data_bk;
}

/**
 * Calls mouse_press() when the mouse is depressed :-(
**/
void ImageSubWindow::OnMouseDown(Glow::MouseButton button,
                              int x, int y,
                              Glow::Modifiers modifiers)
{
	mouse_press(button,x,y,modifiers,MOUSE_DOWN);
}

/**
 * Calls mouse_press() when the mouse is released :-) 
**/    
void ImageSubWindow::OnMouseUp(Glow::MouseButton button,
                              int x, int y,
                              Glow::Modifiers modifiers)
{
	mouse_press(button,x,y,modifiers,MOUSE_UP);
}


/**
 * Redraws the window and calls graphics_callback()
**/
void ImageSubWindow::OnEndPaint()
{

        glRasterPos2f(-1,-1) ;
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	if(type == Image::COLOUR)	
            glDrawPixels(width, height, GL_RGB, GL_UNSIGNED_BYTE, data);
	else
            glDrawPixels(width, height, GL_LUMINANCE, GL_UNSIGNED_BYTE, data);

        graphics_callback(parent_obj) ;

	Refresh();

}


void ImageSubWindow::operator << (ImageRGB& img)
{
        GLubyte *tmp_ptr ; 

	pixels = (GLint *)img.data;
	type = Image::COLOUR;
 	repackRGB();

	// Swap back and front buffer
	tmp_ptr = data_bk ;
	data_bk = data ;
	data = tmp_ptr ;
}


void ImageSubWindow::operator << (ImageGrey& img)
{
        GLubyte *tmp_ptr ; 

	pixels = (GLint*)img.brightness;
	type = Image::GREYSCALE;
	repackGrey();

	// Swap back and front buffer
	tmp_ptr = data_bk ;
	data_bk = data ;
	data = tmp_ptr ;
}


void ImageSubWindow::operator << (Image& img)
{	
	(type == Image::COLOUR)? *this << (ImageRGB&)img
                               : *this << (ImageGrey&)img;
}


void ImageSubWindow::repackRGB()
{
	GLubyte *d = data_bk + (size - width) * 3 ;
	GLint   *p = pixels;

	// GL expects the array to start at the bottom left,
	// but the data starts at the top left
	for(unsigned int i = 0; i < height; i++, d -= 6 * width)
	{
		for (unsigned int j = 0; j < width; j++)
		{
			*(d++) = *(p++);
			*(d++) = *(p++);
			*(d++) = *(p++);
		}
	}
}


void ImageSubWindow::repackGrey()
{
	GLubyte *d = data_bk + size - width ;
	GLint   *p = pixels;

	// GL expects the array to start at the bottom left,
	// but the data starts at the top left
	for(unsigned int i = 0; i < height; i++, d -= 2 * width)
	{
		for (unsigned int j = 0; j < width; j++, d++, p++) 
			*d = *p;
	}
}

