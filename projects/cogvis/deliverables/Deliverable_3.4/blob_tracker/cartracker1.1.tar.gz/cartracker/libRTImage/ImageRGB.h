/** @file ImageRGB.h 
 * 
 * Header file for the class 'ImageRGB'. 
 *
 * The source code for this class can be found in ImageRGB.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage) 
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef IMAGE_RGB_H
#define IMAGE_RGB_H

#include "PixelRGB.h"
#include "ImageBase.h"

class ImageRGB : virtual public ImageBase
/**
 * An image consisting of red, green and blue pixels. 
 *
 * The image is stored as an array of ints, each pixel spanning three ints
 * (one for each of its red, green and blue values).
 */
{
public:
	/// Field selectors for field based methods.
	enum FieldSelector { RED, GREEN, BLUE };
	
/* Public Data Definitions */

	PixelRGB	*data;		///< RGB image data

public:
/* Public Methods */

	/// Create an image with the given dimensions
	ImageRGB(unsigned int width, unsigned int height);

        /// Create an image from a graphics file
        ImageRGB(char *, FileFormat) ;

        /// Create an image from another image
	ImageRGB(ImageRGB&);		///< Copy Constructor

        /// Create an image from a portion of another image
        ImageRGB(ImageRGB&, 
                 unsigned int min_x,
                 unsigned int min_y,
                 unsigned int max_x,
                 unsigned int max_y) ;
	
	~ImageRGB();

	/// set the value of a pixel specified by (x,y)
	void		set_pixel(unsigned int x, unsigned int y, PixelRGB p);

	/// Set the red, green and blue values of a pixel specified by (x,y)
	void		set_rgb(unsigned int x, unsigned int y, 
			        int red, int green, int blue);
	
	/// Set the selected fields value of a pixel specified by (x,y)
	void		set_field(unsigned int x, unsigned int y,
			          FieldSelector, int value);
			          			
	/** 
	 * Return the red, green and blue values of the pixel specified 
	 * by (x,y) in p.
	 */
	void		get_pixel(unsigned int x, unsigned int y, PixelRGB& p);

	/// Return the selected fields value of a pixel specified by (x,y)
	int		get_field(unsigned int x, unsigned int y, 
			          FieldSelector);
	
	/// Set to value (clear) all of the pixels in the image.
	ImageRGB&	clear(int = 0);

	/// Set all of the pixels in the image to the specified value.
	ImageRGB&	clear(PixelRGB&);

	/// Set to value (clear) all values in the selected field.
	ImageRGB&	clear_field(FieldSelector, int = 0);

	/// Copy data from from img. 
	ImageRGB&	copy(ImageRGB& img);

	/// Copy block of data from img.
	ImageRGB&	copy(ImageRGB&    img,
                             unsigned int min_x,
                             unsigned int min_y,
                             unsigned int max_x,
                             unsigned int max_y,
                             unsigned int start_x,
                             unsigned int start_y);

        /// Save in graphics file format
        bool            save(char *, FileFormat) ;
	
	/* Operator overloading */

	/// Overload equals (=) operator for two images.
	ImageRGB&	operator = (ImageRGB& img) 
	 { return this->copy(img); }

        bool            draw_line(int x_start, int y_start,
                                  int x_end, int y_end,
                                  PixelRGB pix);
        bool            draw_filled_circle(unsigned int centre_x,
                                           unsigned int centre_y,
                                           unsigned int radius,
                                           PixelRGB pix);

        bool            enhance_contrast() ;


};


#endif	// IMAGE_RGB_H
