/** @file ImageGrey-conv.cpp
 *
 * File containing convolution methods for the 'ImageGrey' class.
 *
 * The header for this class can be found in ImageGrey.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following 
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#include <stdio.h>
#include <fstream.h>
#include <ImageGrey.h>

float ImageGrey::convolve(unsigned int x,
                          unsigned int y,
                          CMatrix      *kernel)
/**
 * Convolve image with convolution kernel. 
 * N.B. No check is made on the validity of the kernel centre w.r.t. kernel 
 * and image size.
 *
 * @param x X co-ordinate of kernel centre in image
 * @param y Y co-ordinate of kernel centre in image
 * @param kernel Convolution kernel
 */
{
    int x_off ;
    int y_off ;
    int x_cnt ;
    int y_cnt ;
    int x_min ;
    int x_max ;
    int y_min ;
    int y_max ;
    float        *k_ptr ; 
    int          *d_ptr ; 
    float        ret_val = 0 ;

    x_off = kernel->get_no_columns() / 2 ;
    y_off = kernel->get_no_columns() / 2 ;

    x_min = x-x_off ;
    x_max = x+x_off ;
    y_min = y-y_off ;
    y_max = y+y_off ;

    k_ptr = kernel->data ;

    for(y_cnt=y_min ; y_cnt<=y_max ; y_cnt++){ 
        d_ptr = brightness + (y_cnt*width) + x_min ;
        for(x_cnt=x_min ; x_cnt<=x_max ; x_cnt++){ 
            ret_val += *(k_ptr++) * *(d_ptr++) ;
        }
    }

    return ret_val ;
}

void ImageGrey::plot_conv_kernel(unsigned int x,
                                 unsigned int y,
                                 CMatrix      *kernel,
                                 float        scale_fact,
                                 float        offset)
/**
 * Draws convolution kernel into image (for debug and visualisation).
 * N.B. No check is made on the validity of the kernel centre w.r.t. kernel
 * and image size.
 *
 * @param x X co-ordinate of kernal centre in image
 * @param y Y co-ordinate of kernal centre in image
 * @param kernel Convolution kernel
 * @param scale_fact Multiplier for kernel values 
 * @param offset Offset for kernel values 
 */
{
    unsigned int x_off ;
    unsigned int y_off ;
    unsigned int x_cnt ;
    unsigned int y_cnt ;
    unsigned int x_min ;
    unsigned int x_max ;
    unsigned int y_min ;
    unsigned int y_max ;
    float        *k_ptr ;
    int          *d_ptr ;

    x_off = kernel->get_no_columns() / 2 ;
    y_off = kernel->get_no_columns() / 2 ;

    x_min = x-x_off ;
    x_max = x+x_off ;
    y_min = y-y_off ;
    y_max = y+y_off ;

    k_ptr = kernel->data ;

    for(y_cnt=y_min ; y_cnt<=y_max ; y_cnt++){
        d_ptr = brightness + (y_cnt*width) + x_min ;
        for(x_cnt=x_min ; x_cnt<=x_max ; x_cnt++){
           *(d_ptr++) = (int)((float)(*(k_ptr++) + offset) * scale_fact + 0.5) ;
        }
    }

}

float ImageGrey::wavelet_convolve(unsigned int x,
                                  unsigned int y,
                                  Wavelet *wavelet,
                                  float        *real,
                                  float        *imag)
/**
 * Performs convolutions with real and imaginary wavelet kernels. Returns the 
 * SQUARE of the magnitude (for reasons of computational efficiency).
 * N.B. No check is made on the validity of the kernel centre w.r.t. kernel
 * and image size.
 *
 * @param x X co-ordinate of kernal centre in image
 * @param y Y co-ordinate of kernal centre in image
 * @param wavelet ponter to Wavelet object
 * @param real The real part of transform returned to 'real' is not NULL 
 * @param imag The imaginary part of transform returned to 'imag' is not NULL 
 */
{

    register float    r ;
    register float    i ;


    r = convolve(x, y, wavelet->real_kernel) ;
    i = convolve(x, y, wavelet->imag_kernel) ;

    if(real != NULL) *real = r ;
    if(imag != NULL) *imag = i ;

    i *= i ;
    r *= r ;

    return (r + i) ;
}

