/** @file ImageBase.h 
 * 
 * Header file for the abstract class 'ImageBase'. 
 *
 * There is no source code for this class as it is abstract and cannot be
 * initialised.
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage) 
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef IMAGE_BASE_H
#define IMAGE_BASE_H

// Enumeration for save method

enum FileFormat{ FORMAT_BMP_24,
                 FORMAT_BMP_RC,
                 FORMAT_BMP_MONO
};

class ImageBase
/**
 * An abstract base for the two image classes. 
 *
 * This abstract class is used for a base for the two classes ImageRGB and
 * ImageGrey. It declares methods and members which are common to both
 * of these specific classes and allows the classes to be treated the same.
 * 
 */
{
protected:
/* Protected Data Definitions */

	unsigned int	 width;		///< Width of the image
	unsigned int	 height;	///< Height of the image

public:
/* Public Methods */
	/** Returns the width of the image */
	unsigned int	get_width()  { return width;  }

	/** Returns the height of the image */
	unsigned int	get_height() { return height; }

protected:
/* Protected Methods */

	///< Copy Constructor
	ImageBase(ImageBase& img) 
	 : width(img.width), height(img.height) { }
	
	/// Create an image with the given dimensions
	ImageBase(unsigned int w, unsigned int h) 
	 : width(w), height(h) { }

        /// Create an image with 0x0 dimension
        ImageBase() 
         : width(0), height(0) { }

};


#endif	// IMAGE_BASE_H
