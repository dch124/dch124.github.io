/** @file QTencoder.h
 *
 * Header file for the class 'QTencoder'.
 *
 * The source code for this class can be found in QTencoder.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef QT_ENCODER_H
#define QT_ENCODER_H

extern "C" {
#include <quicktime.h>
}
#include <ImageRGB.h>
#include <ImageGrey.h>

class QTencoder
/**
 * A class for writing Quicktime movies
 * Uses the Quicktime4Linux libraries
**/
{
protected:
        quicktime_t*    outfile;        ///< QT file handle
        unsigned char** buff;           ///< Buffer for decoded data
        unsigned int    width;          ///< QT width
        unsigned int    height;         ///< QT height
        float		frame_rate;     ///< QT frame rate

public:
	///Initialise a quicktime movie to write to
        QTencoder(char* path ,unsigned int width, 
                  unsigned int height, float frame_rate, int quality);
        ~QTencoder();

	///Write an ImageRGB frame to the qt movie
        bool operator << (ImageRGB&) ;

	///Write an ImageGrey frame to the qt movie
        bool operator << (ImageGrey&) ;

	///Very important close file function!
	void close();
};

#endif
