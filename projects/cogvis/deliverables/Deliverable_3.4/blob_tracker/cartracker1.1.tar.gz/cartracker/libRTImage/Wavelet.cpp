/** @file CMatrix.h
 *
 * Header file for the class 'Wavelet'.
 *
 * The source code for this class can be found in wavelet.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#include <Wavelet.h>
#include <stdio.h>
#include <fstream.h>
#include <string.h>

#define REAL_POSTFIX ".real"
#define IMAG_POSTFIX ".imag"

Wavelet::Wavelet(char *fn_prefix)
/**
 * Constructor method. Loads convolution kernels from files:
 * <fn_prefix>.real and <fn_prefix>.imag
 *
 * @param fn_prefix kernel filename prefix
 */
{

    char         *real_fn ; 
    char         *imag_fn ; 
    unsigned int r_fn_len ; 
    unsigned int i_fn_len ; 

    InitOk = true ;

    r_fn_len = strlen(fn_prefix) + strlen(REAL_POSTFIX) + 1 ; 
    i_fn_len = strlen(fn_prefix) + strlen(IMAG_POSTFIX) + 1 ; 

    real_fn = new char[r_fn_len] ;
    imag_fn = new char[i_fn_len] ;
    if(real_fn==NULL || imag_fn==NULL) InitOk = false ;
    else{
        sprintf(real_fn,"%s"REAL_POSTFIX,fn_prefix) ; 
        sprintf(imag_fn,"%s"IMAG_POSTFIX,fn_prefix) ; 

        real_kernel = new CMatrix(real_fn) ;
        imag_kernel = new CMatrix(imag_fn) ;

        if(!real_kernel->initialised_ok() ||
           !imag_kernel->initialised_ok() ){
            InitOk = false ;
        }
    }
} 

bool Wavelet::initialised_ok() 
{
    return InitOk ;
}
