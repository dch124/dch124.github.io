/** @file CMatrix.h 
 * 
 * Header file for the class 'CMatrix'. 
 *
 * The source code for this class can be found in CMatrix.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage) 
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef CMATRIX_H
#define CMATRIX_H

class CMatrix
/**
 * A class implementing a convolution kernel matrix.
 */

{
private:
            unsigned int    r ;        ///< No. of Rows
            unsigned int    c ;        ///< No. of Columns
            unsigned int    size ;     ///< Size (rows x columns)
            bool            InitOk ;   ///< Constructor success flag
public:
            float           *data ;    ///< Kernel data 

            /// New object constructor
            CMatrix(unsigned int rows, unsigned int columns) ;

            /// Load from formated file constructor
            CMatrix(char *filename) ;

            /// Load from raw (text) file constructor
            CMatrix(char *filename, unsigned int rows, unsigned int columns) ; 

            void            set_element(unsigned int row,
                                        unsigned int col,
                                        double       val) ;
            float           get_element(unsigned int row,
                                        unsigned int col) ;
            unsigned int    get_no_rows() ;
            unsigned int    get_no_columns() ;
            bool            save(char *filename) ;
            bool            save_raw(char *filename) ;
            float           calc_max_kernel_val() ;
            float           calc_min_kernel_val() ;
            bool            initialised_ok() ;
};

#endif
