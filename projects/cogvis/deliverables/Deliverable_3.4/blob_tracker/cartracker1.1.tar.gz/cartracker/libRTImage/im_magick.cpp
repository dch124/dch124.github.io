/** @file m_magick.cpp
 *
 * Header file for Image Magic C interface code.
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <magick/api.h>

void * im_load(char *filename, unsigned int &w, unsigned int &h)
{
  Image *image ;
  ExceptionInfo
        exception;

      ImageInfo
        *image_info;

      /*
        Initialize the image info structure and read an image.
      */
      InitializeMagick(NULL); // Should really pass argv[0] (only req'd under 
                              // windows)
      GetExceptionInfo(&exception);
      image_info=CloneImageInfo((ImageInfo *) NULL);
      sprintf(image_info->filename,"%s", filename);
      image=ReadImage(image_info,&exception);

   if (image == (Image *) NULL)
        return NULL ;

    w = image->columns ;
    h = image->rows ;

    // Tidy up
    DestroyImageInfo(image_info);
    DestroyExceptionInfo(&exception);

    return (void*)image ;
}

void im_get_data(void *img, int *rgb)
{
    unsigned int cnt ;
    PixelPacket *pp ;   
    int *optr ;
    PixelPacket *iptr ;
    unsigned int sz ;
    Image *image ;

    image = (Image*)img ;
 
    pp =  GetImagePixels( image, 0, 0, image->columns, image->rows) ; 

    sz = image->columns*image->rows ;

    for(cnt=0,iptr=pp, optr=rgb ; cnt<sz ; cnt++, iptr++){
        *(optr++) = iptr->red >> 8 ;
        *(optr++) = iptr->green >> 8 ;
        *(optr++) = iptr->blue >> 8 ;
    }
}

void im_get_data_grey(void *img, int *d)
{
    unsigned int cnt ;
    PixelPacket *pp ;
    int *optr ;
    PixelPacket *iptr ;
    unsigned int sz ;
    Image *image ;

    image = (Image*)img ;

    pp =  GetImagePixels( image, 0, 0, image->columns, image->rows) ;

    sz = image->columns*image->rows ;

    for(cnt=0,iptr=pp, optr=d ; cnt<sz ; cnt++, iptr++, optr++){
        *optr = iptr->red >> 8 ;
        *optr += iptr->green >> 8 ;
        *optr += iptr->blue >> 8 ;
        *optr /= 3 ;
    }
}

void im_free(void *img)
{
    Image *image ;

    image = (Image*)img ;

    DestroyImage(image);

}
