/** @file ImageSource.h 
 * 
 * Header file for the abstract class 'ImageSource'. 
 *
 * There is no source code for this class as it is abstract and cannot be
 * initialised.
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage) 
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/
 
#ifndef IMAGE_SOURCE_H
#define IMAGE_SOURCE_H

#include "Image.h"

class ImageSource
/**
 * The interface for any source of Image's.
 *
 * This interface is implemented by any class from which images can
 * be pulled into an Image object. The contents of the Image's data
 * and brightness buffers are overwritten with the new image from 
 * the specific source.
 * 
 */
{ 
protected:
/* Protected Data Definitions */
	
	Image::Type	type;		///< Default type of source.

public:
/* Public Methods */
	
	/// Virtual destructor
	virtual ~ImageSource() { }
	
	/** 
	 * Set the default type of source.
	 * 
	 * The default type is the image that is extracted to an Image 
	 * object by default.
	 */
	void set_mode(Image::Type t) { type = t; }
	
	/* Image extraction operators */
	
	/// Extract a colour image into the images data buffer.
	virtual ImageSource& operator >> (ImageRGB&)  = 0;
	
	/// Extract a greyscale image into the images brightness buffer.
	virtual ImageSource& operator >> (ImageGrey&) = 0;
	
	/// Extract an image dependant on the default type.
	virtual ImageSource& operator >> (Image&)     = 0;

protected:
/* Protected Methods */
	
	/** 
	 * Default constructor. 
	 * protected as an instance of this class cannot be directly
	 * created. instead an instance of an inherited class should
	 * be used.
	 */
	ImageSource() { }
};


#endif	// IMAGE_SOURCE_H

