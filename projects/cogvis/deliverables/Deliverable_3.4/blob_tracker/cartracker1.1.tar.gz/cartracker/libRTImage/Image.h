/** @file Image.h 
 * 
 * Header file for the class 'Image'. 
 *
 * The source code for this class can be found in Image.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage) 
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef IMAGE_H
#define IMAGE_H

#include "ImageRGB.h"
#include "ImageGrey.h"

/* Define Coefficients for RGB to Brightness relationship */
#define RED_COEF .2989961801
#define GREEN_COEF .5869947588
#define BLUE_COEF .1139912943

class Image : public ImageRGB, public ImageGrey
/**
 * A class made up of both an RGB image and a Greyscale image. 
 *
 * The Image class inherits RGB properties from the ImageRGB class and 
 * greyscale properties from the ImageGrey class. So this class can be 
 * used as either a greyscale or colour image.
 */
{
public:
	/// Possible Image palettes
	enum Type { COLOUR, GREYSCALE };

public:
/* Public Methods */

	Image(Image&);		///< Copy Constructor
	
	/// Create an image with the given dimensions
	Image(unsigned int width, unsigned int height);

	~Image();

	/// Set the rgb values of a pixel specified by (x,y)
	void		set_rgb(unsigned int x, unsigned int y, 
				PixelRGB& p);

	/// Set the brightness value of a pixel specified by (x,y)
	void		set_brightness(unsigned int x, unsigned int y,
		       		       PixelGrey& level);
			          			
	/** 
	 * Return the red, green and blue values of the pixel specified 
	 * by (x,y) in the RGB Pixel p.
	 */
	void		get_rgb(unsigned int x, unsigned int y, 
				PixelRGB& p);

	/// Return the greylevel value of a pixel specified by (x,y)
	void		get_brightness( unsigned int x, unsigned int y,
					PixelGrey& p);
	
	/// Set to value (clear) all of the pixels in the RGB image data.
	Image&		clear_rgb(int = 0);

	/// Set to value (clear) all of the pixels in the RGB image data.
	Image&		clear_rgb(PixelRGB&);

	/// Set to value (clear) all of the pixels in the brightness data.
	Image&		clear_brightness(int = 0);

	/// Copy all RGB and brightness data from this to img.
	Image&		copy(Image& img);
	
	/* Operator overloading */

	Image&		operator = (Image& img);

	/// Update brightness field for all pixels, from the RGB data.
	void		update_brightness(); 

        bool            draw_line(int x_start, int y_start,
                                  int x_end, int y_end,
                                  PixelGrey intensity);
        bool            draw_line(int x_start, int y_start,
                                  int x_end, int y_end,
                                  PixelRGB pix);
        bool            draw_filled_circle(unsigned int centre_x,
                                           unsigned int centre_y,
                                           unsigned int radius,
                                           PixelGrey intensity);
        bool            draw_filled_circle(unsigned int centre_x,
                                           unsigned int centre_y,
                                           unsigned int radius,
                                           PixelRGB pix);
};

#endif	// IMAGE_H
