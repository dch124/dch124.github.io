/* conversion methods */

#include <stdio.h>
#include "ccvt.h"
#include "conv.h"

	
void conv_420p_rgb96(int width,int height,void* src,void* dst)
{
	static unsigned int oldSize = 0;
	static unsigned char* rgb;
	
	unsigned int size = width * height;
	
	// reallocate memory if the sizes have changed
	if (oldSize < size) {
		delete [] rgb;
		rgb = new (unsigned char)[size * 4];
	}
	
	// set up all the pointers
	unsigned char	*s = (unsigned char *)src;
	int		*d = (int *)dst;
	
	static unsigned int offset_U = size;
	static unsigned int offset_V = size + size / 4;
	
	unsigned char* 	Y = s;
	unsigned char*	U = s + offset_U;
	unsigned char*	V = s + offset_V;
	
	// convert away
	ccvt_420p_rgb32(width, height, Y, U, V, rgb);
	conv_rgb32_rgb96(width, height, rgb, d);
}


void conv_420p_grey(int width,int height,void *src,void *dst)
{
	unsigned char	*s = (unsigned char *)src;
	int		*d = (int *)dst;
	
	unsigned int size = width * height;
	
	for (unsigned int i = 0; i < size; i++) *(d++) = *(s++);
}


void conv_rgb24_rgb96(int width, int height, void *src, void *dst)
{
	unsigned char**	rows = (unsigned char**) src;
	unsigned char*	s;
	int* 		d = (int*) dst;
	
	for (int j = 0; j < height; j++) {
		s = rows[j];
		
		for (int i = 0; i < width; i++) {
			*(d++) = *(s++);
			*(d++) = *(s++);
			*(d++) = *(s++);
		}
	}
}

void conv_rgb24_grey(int width, int height, void *src, void *dst)
{
        unsigned char*  s;
        int*            d = (int*) dst;

        s = (unsigned char *)src ;

        for (int j = 0; j < height; j++) {

                for (int i = 0; i < width; i++) {
                        *d = *(s++);
                        *d += *(s++);
                        *d += *(s++);
                        *d /= 3 ;
                        d++ ; 
                }
        }
}



void conv_bgr24_rgb96(int width, int height, void *src, void *dst)
{
        unsigned char*  s ;
        int            *d ;
        int             hw ;

        s = (unsigned char*)src ;
        d = (int*)dst + 2 ;
  
        hw = width*height ;

        for (int j = 0; j < hw; j++, d+=5) {
            *(d--) = *(s++);
            *(d--) = *(s++);
            *(d) = *(s++);
        }
}


void conv_rgb32_rgb96(int width,int height,void *src,void *dst)
{
	unsigned char	*s = (unsigned char *)src;
	int		*d = (int *)dst;
	
	unsigned int size = width * height;

	for (unsigned int i = 0; i < size; i++, s++) {
		*(d++) = *(s++);
		*(d++) = *(s++);
		*(d++) = *(s++);
	}
}


void conv_rgb32_grey(int width,int height,void* src,void* dst)
{
	unsigned char	*s = (unsigned char *)src;
	int		*d = (int *)dst;
	
	unsigned int size = width * height;
	
	for (unsigned int i = 0; i < size; i++, s++)
		*(d++) = (*(s++) + *(s++) + *(s++)) / 3;
}

