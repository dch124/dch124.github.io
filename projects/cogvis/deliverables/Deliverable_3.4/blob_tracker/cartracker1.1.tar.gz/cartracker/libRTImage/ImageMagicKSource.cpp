/** @file ImageMagicKSource.cpp
 *
 * Source code for the class 'ImageMagicKSource'.
 *
 * The source code for this class can be found in ImageMagicKSource.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#include <ImageMagicKSource.h>
#include <im_magick.h>

ImageMagicKSource::ImageMagicKSource(char *filename)
/**
 * Constructor: Opens file + reads data
 */ 
{
    if((img=im_load(filename, width, height))==NULL) ok = false ;
    else ok = true ; 
}

ImageMagicKSource::~ImageMagicKSource()
/**
 * Destructor, frees memory 
 */
{
    im_free(img) ;
}

ImageSource& ImageMagicKSource::operator>> (ImageRGB &image)
/**
 * Writes rgb data to image 
 */
{
    im_get_data(img, (int*)image.data) ;

    return *this ;
}

void ImageMagicKSource::get_size(unsigned int &w, unsigned int &h) 
/**
 * Gets width + height
 */
{
    w = width ;
    h = height ;
}  

ImageSource& ImageMagicKSource::operator>> (ImageGrey &image)
/**
 * Writes greyscale data to image
 */
{
    im_get_data_grey(img, image.brightness) ;
    return *this ;
}

ImageSource& ImageMagicKSource::operator>> (Image &image)
/**
 * Writes data to image
 */
{
    (type == Image::COLOUR) ? *this >> (ImageRGB&)image
                            : *this >> (ImageGrey&)image;
    return *this ;
}


