/** @file QTencoder.cpp
 *
 * File containing methods for the 'QTencoder' class.
 *
 * The header for this class can be found in QTencoder.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/
#include "QTencoder.h"

/**
 * QTencoder Constructor
 * 
 * Sets up a quicktime movie file to write to
 *
 * @param path		The filename to write the movie to
 * @param outfile	The quicktime movie file
 * @param width		The width of the Image/movie
 * @param height	The height of the Image/movie	    
 * @param frame_rate	Framerate to playback at
 * @param quality	JPEG quality factor for compression 
 *			1=low 75=normal 90=high 100=best
**/
QTencoder::QTencoder(char* path, unsigned int w, unsigned int h, float frate, int quality):width(w),height(h),frame_rate(frate)
{
        //open the a file for the quicktime movie
        outfile = quicktime_open(path,0,1); //read access only!
        if (outfile == NULL)
                throw "error opening file to write quicktime to";

	//Set video parameters - Using Interlaced Even Motion JPEG A compression
	quicktime_set_video(outfile, 1, width, height, frame_rate, "mjpa");
	//Set the JPEG quality factor 1=low 75=normal 90=high 100=best
	quicktime_set_jpeg(outfile, quality, 0);

	//Check compression scheme is supported
        if(!quicktime_supported_video(outfile, 0)){
		throw "QT Compression scheme not supported" ;
	}
	//Check colour model is supported - using RGB888
	if(!quicktime_writes_cmodel(outfile, 9, 0)){
		throw "QT Color Model not supported" ;
	}
	//Set colourmodel to RGB888 format
        quicktime_set_cmodel(outfile, 9);

	// allocate memory for rgb rows
        buff = new (unsigned char*)[height];
        for (unsigned int i = 0; i < height ; i++)
                buff[i] = new (unsigned char)[width*3];
}

/**
 * QTencoder destructor
**/
QTencoder::~QTencoder()
{
        // free the memory for each of the rows
        for (unsigned int i = 0; i < height; i++)
                delete [] buff[i];
        delete [] buff;
}

/**
 * Function to close the quicktime file
 * 
 *@note VERY IMPORTANT to call this function to tidy up the quicktime file
**/
void QTencoder::close()
{
	quicktime_close(outfile);
}

/**
 * Write a ImageRGB frame to the quicktime movie file
 * @param img is of type ImageRGB
**/
bool QTencoder::operator << (ImageRGB& img)
{
	bool ret_val = 1;
	PixelRGB* rgb_ptr = img.data;
	unsigned char *buff_ptr = buff[0];
        for(unsigned int y_cnt=0 ; y_cnt< img.get_height() ; y_cnt++){
            buff_ptr = buff[y_cnt];
            for(unsigned int x_cnt=0 ; x_cnt< img.get_width() ; x_cnt++, rgb_ptr++){
		(*buff_ptr++) = (unsigned char)((*rgb_ptr)[0]);
		(*buff_ptr++) = (unsigned char)((*rgb_ptr)[1]);
		(*buff_ptr++) = (unsigned char)((*rgb_ptr)[2]);
	    }	
	}
	//Encode the frame and write to file
	if(quicktime_encode_video(outfile, buff, 0))
		ret_val = 0 ;
	return ret_val;
}

/**
 * Write a ImageGrey frame to the quicktime movie file
 * @param img is of type ImageGrey
**/
bool QTencoder::operator << (ImageGrey& img)
{
        bool ret_val = 1;
        int* b_ptr = img.brightness;
        unsigned char *buff_ptr = buff[0];
        for(unsigned int y_cnt=0 ; y_cnt< img.get_height() ; y_cnt++){
            buff_ptr = buff[y_cnt];
            for(unsigned int x_cnt=0 ; x_cnt< img.get_width() ; x_cnt++, b_ptr++){
                (*buff_ptr++) = (unsigned char)((*b_ptr));
                (*buff_ptr++) = (unsigned char)((*b_ptr));
                (*buff_ptr++) = (unsigned char)((*b_ptr));
            }  
        }
        //Encode the frame and write to file
        if(quicktime_encode_video(outfile, buff, 0))
                ret_val = 0 ;
        return ret_val;
}

