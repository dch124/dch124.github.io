/** @file JPEGSource.cpp
 *
 * File containing methods for the 'JPEGSource' class.
 *
 * The header for this class can be found in JPEGSource.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#include "JPEGSource.h"

JPEGSource::JPEGSource(char* jpeg_name)
/**
 * Initialise the JPEGSource to produce images of width w and height h
 * from file 'jpeg_name'
 *
 * @param jpeg_name     JPEG source file.
 */
{
    loadJPEG(jpeg_name);
    
    // default palette for this ImageSource is colour
    type      = Image::COLOUR;
}


/**
 * Extract colour Image from jpeg source.
 *
 * @param img The colour Image to be extracted to.
 */
ImageSource& JPEGSource::operator >> (ImageRGB& img)
{
    PixelRGB      *img_ptr = img.data; 
    unsigned char *src_ptr;
    
    src_ptr  = image + 4 * width * height;
    src_ptr += 4 * width;

    for (int y_cnt = 0; y_cnt < height; y_cnt++) {
        src_ptr -= 2 * 4 * width;
      
        for (int x_cnt = 0; x_cnt < width; x_cnt++) {
            PixelRGB pix((int) *(src_ptr++),
                         (int) *(src_ptr++),
                         (int) *(src_ptr++));
            *(img_ptr++) = pix ;
            src_ptr++;
        }
    }
    
    return *this;
}

/**
 * Extract a greyscale Image from jpeg source
 *
 * @param img The greyscale Image to be extracted to.
 */
ImageSource& JPEGSource::operator >> (ImageGrey& img)
{
    PixelGrey     *img_ptr = img.brightness;
    unsigned char *src_ptr;
    src_ptr  = image + 4 * width * height;
    src_ptr += 4 * width;

    for (int y_cnt = 0; y_cnt < height; y_cnt++) {
        src_ptr -= 2 * 4 * width;
      
        for (int x_cnt = 0 ; x_cnt < width; x_cnt++) {
            PixelGrey pix(int (float(RED_COEF   * (*src_ptr++)) + 
                               float(GREEN_COEF * (*src_ptr++)) +
                               float(BLUE_COEF  * (*src_ptr++)) ));
            *(img_ptr++) = pix;
            src_ptr++;
        }
    }
    
    return *this;                                   
}

/**
 * Extract a Image from jpeg source.
 *
 * The Image could be colour or greyscale depending on the
 * default palette type for this class.
 *
 * @param img The Image to be extracted to.
 */
ImageSource& JPEGSource::operator >> (Image& img)
{
        (type == Image::COLOUR) ? *this >> (ImageRGB& )img
                                : *this >> (ImageGrey&)img;

        return *this;
}
                    

/**
 * Load an Image from the jpeg source.
 *
 * @param filename The jpeg file to load the image from.
 */ 
void JPEGSource::loadJPEG(char* filename)
{
    FILE *infile = fopen(filename, "rb");
    
    jpeg_error_mgr         jerr;
    jpeg_decompress_struct cinfo;
    
    cinfo.err = jpeg_std_error(&jerr);
 
    jpeg_create_decompress(&cinfo);
    jpeg_stdio_src(&cinfo, infile);
    jpeg_read_header(&cinfo, TRUE);
 
    jpeg_start_decompress(&cinfo);
 
    int rowStride = cinfo.output_width  * cinfo.num_components;
    int total     = cinfo.output_height * rowStride;
 
    JSAMPLE *cdata = new JSAMPLE[total];
    JSAMPLE *base = cdata;
 
    int numread;
    while (cinfo.output_scanline < cinfo.output_height)
    {
        numread = jpeg_read_scanlines(&cinfo, &cdata, cinfo.rec_outbuf_height);
        cdata  += numread * rowStride;
    }

    fclose(infile);
    
    int ArowStride = cinfo.output_width  * (cinfo.num_components + 1);
    int Atotal     = cinfo.output_height * ArowStride;
    
    JSAMPLE* idata = new JSAMPLE[Atotal];
 
    // GL expects the array to start at the bottom left,
    // but the decoded data starts at the top left
    for (int j=Atotal-ArowStride, i=0; j>=0; j-=2*ArowStride)
    {
        for (int k=0; k<rowStride; k+=3, i+=3, j+=4)
        {
        idata[j]   = base[i];
        idata[j+1] = base[i+1];
        idata[j+2] = base[i+2];
        idata[j+3] = 0;
        }
    }
    delete [] base;
    base = idata;              
                 
    // Image data now decompressed and stored in cdata
    image  = base;
    width  = cinfo.output_width;
    height = cinfo.output_height;
 
    jpeg_finish_decompress(&cinfo);
}
                               
