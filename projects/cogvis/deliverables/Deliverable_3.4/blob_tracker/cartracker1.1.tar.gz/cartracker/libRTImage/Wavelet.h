/** @file CMatrix.h
 *
 * Header file for the class 'Wavelet'.
 *
 * The source code for this class can be found in wavelet.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef WAVELET_H
#define WAVELET_H

#include <CMatrix.h>

class Wavelet
/**
 * A class implementing a wavelet transform as a pair of kernel convolutions.
 * Kernel data is loaded from two files prefix.real and prefix.imag.
 */ 
{
private:
            bool               InitOk ;
public:
            CMatrix            *real_kernel ;
            CMatrix            *imag_kernel ;

            Wavelet(char *fn_prefix) ;

            bool               initialised_ok() ;
};

#endif

