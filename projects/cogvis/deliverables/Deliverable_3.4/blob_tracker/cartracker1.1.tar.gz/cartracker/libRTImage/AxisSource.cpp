/** @file AxisSource.cpp
 *
 * File containing methods for the 'AxisSource' class.
 *
 * The header for this class can be found in AxisSource.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#include "AxisSource.h"

AxisSource::AxisSource(char* axis_name, FrameSize frame_size) 
/**
 * Initialise the AxisSource to produce images of width w and height h
 * from web server axis_name
 *
 * @param axis_name     The web server.
 * @param frame_size    Framesize, either HALF(0) or FULL(1).
 * @param dims[0]       The width of the Images to be produced.
 * @param dims[1]       The height of the Images to be produced.
 */
{
        if(frame_size == 0){         //Half.
                dims[0] = 352;
                dims[1] = 288;
        }else if(frame_size == 1){   //Full.
                dims[0] = 704;
                dims[1] = 576;
        }else{
                cerr << "Unsupported Frame Size chosen" << endl;
                cerr << "Choose HALF (352x288) or FULL (704x576) " << endl;
                abort();
        }

        //Open a video socket to the web server
        vs = videoSocket(axis_name);

        //Send a video stream request
        requestStream(vs);

        // default palette for this ImageSource is colour
        type      = Image::COLOUR;
}

/**
 * Default Constructer
 *
 * Initialise the AxisSource to produce 352x288 images from "iridemo2" 
 */                                                                 
AxisSource::AxisSource()
{
	vs = videoSocket("iridemo2");
        dims[0] = 352;
        dims[1] = 288;
        requestStream(vs);
        type      = Image::COLOUR;       
}

/**
 * AxisSource destructor
 *
 * Closes the connection to the web server.
 */
AxisSource::~AxisSource()
{
        //close videosocket.
        close(vs);
}

/**
 * Extract colour Image from stream from web server.
 *
 * @param img The colour Image to be extracted to.
 *  
 * source 'image' is RGBA unsigned chars, src_ptr is pointer to this image.
 */
ImageSource& AxisSource::operator >> (ImageRGB& img)
{
        unsigned char *image;
        readNextFrame(vs,image,dims);
        
        PixelRGB *img_ptr = img.data; 
        int y_cnt;
        int x_cnt;
        unsigned char* src_ptr = image + 4*dims[0]*dims[1];
        src_ptr += 4*dims[0];

        for(y_cnt=0 ; y_cnt< dims[1] ; y_cnt++){
          src_ptr -= 2*4*dims[0];
          for(x_cnt=0 ; x_cnt< dims[0] ; x_cnt++){
            PixelRGB pix((int) *(src_ptr++),
                         (int) *(src_ptr++),
                         (int) *(src_ptr++));
            *(img_ptr++) = pix ;
            src_ptr++;
          }
        }
        delete [] image;
        return *this;
}

/**
 * Extract a greyscale Image from stream from web server.
 *
 * @param img The greyscale Image to be extracted to.
 *
 * Note: NOT fast. Still decodes colour JPEG to RGBA then to greyscale. 
 */
ImageSource& AxisSource::operator >> (ImageGrey& img)
{
        unsigned char *image;
        readNextFrame(vs,image,dims);
 
        PixelGrey *img_ptr = img.brightness;
        int y_cnt;
        int x_cnt;
        unsigned char* src_ptr = image + 4*dims[0]*dims[1];
        src_ptr += 4*dims[0];
 
        for(y_cnt=0 ; y_cnt< dims[1] ; y_cnt++){
          src_ptr -= 2*4*dims[0];
          for(x_cnt=0 ; x_cnt< dims[0] ; x_cnt++){
            *(img_ptr++) = (PixelGrey)( (RED_COEF*(float)(*src_ptr++)) + 
                             (GREEN_COEF*(float)(*src_ptr++)) +
                             (BLUE_COEF*(float)(*src_ptr++)) );
            src_ptr++;
          }
        }
        delete [] image;
        return *this;                                   
}

/**
 * Extract a Image from stream from webserver.
 *
 * The Image could be colour or greyscale depending on the
 * default palette type for this class.
 *
 *
 * @param img The Image to be extracted to.
 */                                                           
ImageSource& AxisSource::operator >> (Image& img)
{
        (type == Image::COLOUR) ? *this >> (ImageRGB&)img
                                : *this >> (ImageGrey&)img;

        return *this;
}
                    

int AxisSource::videoSocket(char *hostname)
{
    int sockfd;  
    hostent *he;
    protoent *protoEntry;
    sockaddr_in their_addr; /* connector's address information */

    // Get the host info 
    if ((he = gethostbyname(hostname)) == NULL) 
    {  
        string msg("\'gethostbyname\' failed for ");
        msg += hostname;
	
        throw msg.c_str();
    }

    protoEntry = getprotobyname("tcp");
    short protocol = protoEntry->p_proto;

    // Open the socket
    if ((sockfd = socket(PF_INET, SOCK_STREAM, protocol)) == -1) 
    {
        throw "Failed to open socket";
    }

    int on=1;
    setsockopt(sockfd, protoEntry->p_proto, TCP_NODELAY, &on, sizeof(int));

    // Configure the socket
    their_addr.sin_family = AF_INET;    /* host byte order */
    their_addr.sin_port = htons(PORT);  /* short, network byte order */
    their_addr.sin_addr = *((struct in_addr *)he->h_addr);
    memset(&(their_addr.sin_zero), 0, 8); /* zero the rest of the struct */

    // Now try and connect to the server
    if (connect(sockfd, (sockaddr *) &their_addr, sizeof(sockaddr)) == -1) 
    {
        throw "Unable to connect to server..\n";
    }

    return sockfd;
}


void AxisSource::requestStream(int sockfd)
{
    // Formulate the request
    char req[1000] ;

    sprintf(req,
            "GET /cgi-bin/mjpg/video.cgi?showlength=1&resolution=%dx%d "
            "HTTP/1.0\n\n",
            dims[0],dims[1]) ;

    cout << "Request: " << req;

    // Send it to the server
    if (send(sockfd, req, strlen(req), 0) == -1) 
    {
        string msg("Unable to send following request to server: \n\n");
	msg += req;
	
	throw msg;
    }

    // Read and strip off the general header info
    unsigned char seqHeader[82];

    readSocket(sockfd, seqHeader, 81); 

    seqHeader[81]='\0';
    cout << "Received sequence header:\n" << seqHeader;
}


void AxisSource::readNextFrame(int sockfd, unsigned char* &image, int imgSize[2])
{
    int buffLength;
    int readCount=1;
    unsigned char *imgBuff;

    while (readCount==1)
    {
    	readCount = readFrame(sockfd, imgBuff, buffLength);
 	if (readCount==1) delete [] imgBuff;
    }

    decodeFrame(imgBuff, buffLength, image, imgSize);

    delete [] imgBuff;
}


int AxisSource::readFrame(int sockfd, unsigned char* &imgBuff, int &buffLength)
{
    int readCount;
    int imgLength;
    unsigned char *recvBuff;
    unsigned char imgHeader[128];

    // Read the boundary tag and image header
    readSocket(sockfd, imgHeader, 13);
    imgHeader[13]='\0';

    // Read the Content-Type header
    readSocket(sockfd, imgHeader, 25); 
    imgHeader[25]='\0';

    // Read the Content-Length
    readSocket(sockfd, imgHeader, 24); 
    imgHeader[24]='\0';

    imgLength = 0;
    char tmpBuff[128];
    for (int i = 0; i < 128; i++) tmpBuff[i] = imgHeader[i];
    sscanf(tmpBuff, "Content-Length: %d\n", &imgLength);

    if (imgLength < 10000)
    {
         recvBuff = new unsigned char[imgLength];
         recvBuff[0] = imgHeader[22];
         recvBuff[1] = imgHeader[23];
	 
         unsigned char *tmpHolder = &(recvBuff[2]);
         readCount = readSocket(sockfd, tmpHolder, imgLength-2);
    }
    else if(imgLength < 100000)
    {
         recvBuff = new unsigned char[imgLength];
         recvBuff[0] = imgHeader[23];
	 
         unsigned char *tmpHolder = &(recvBuff[1]);
         readCount = readSocket(sockfd, tmpHolder, imgLength-1);
    }
    else
    {
         // Now create a buffer and read the jpg image (length is imgLength)
         recvBuff = new unsigned char[imgLength];
         readCount = readSocket(sockfd, recvBuff, imgLength); 
    }

    imgBuff = recvBuff;
    buffLength = imgLength;

    // Strip off the trailing <CR> from the input stream
    unsigned char tmp[128];
    readSocket(sockfd, tmp, 2);

    return readCount;
}
    

int AxisSource::readSocket(int sockfd, unsigned char *buff, int buffLength)
{
    int count = 0, bytesRead = 0;

    while (count < buffLength)
    {
	bytesRead = recv(sockfd, buff+count, buffLength-count, 0);
        count += bytesRead;
    }

    return (bytesRead == count);
}

void AxisSource::decodeFrame(unsigned char* imgBuff, int buffLength,
                 unsigned char* &image,  int imgSize[2])
{
    struct jpeg_error_mgr jerr;
    jpeg_decompress_struct cinfo;
    cinfo.err = jpeg_std_error(&jerr);
 
    jpeg_create_decompress(&cinfo);
    jpeg_mem_src(&cinfo, imgBuff, buffLength);
    jpeg_read_header(&cinfo, TRUE);
 
    jpeg_start_decompress(&cinfo);
 
    int rowStride = cinfo.output_width * cinfo.num_components;
    int total = rowStride*cinfo.output_height;
 
    JSAMPLE *cdata = new JSAMPLE[total];
    JSAMPLE *base = cdata;
 
    int numread;
    while(cinfo.output_scanline < cinfo.output_height)
    {
        numread = jpeg_read_scanlines(&cinfo, &cdata, cinfo.rec_outbuf_height);
        cdata += numread*rowStride;
    }
 
    int ArowStride = cinfo.output_width * (cinfo.num_components+1);
    int Atotal = ArowStride*cinfo.output_height;
    JSAMPLE *idata = new JSAMPLE[Atotal];
 
    // GL expects the array to start at the bottom left,
    // but the decoded data starts at the top left
    for(int j=Atotal-ArowStride, i=0; j>=0; j-=2*ArowStride)
    {
        for (int k=0; k<rowStride; k+=3, i+=3, j+=4)
        {
        idata[j]   = base[i];
        idata[j+1] = base[i+1];
        idata[j+2] = base[i+2];
        idata[j+3] = 0;
        }
    }
    delete [] base;
    base = idata;              
                 
    // Image data now decompressed and stored in cdata
    image = base;
    imgSize[0] = cinfo.output_width;
    imgSize[1] = cinfo.output_height;
 
    jpeg_finish_decompress(&cinfo);
}
                               





