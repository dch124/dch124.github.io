/** @file ImageMagicKSource.h
 *
 * Header file for the class 'ImageMagicKSource'.
 *
 * The source code for this class can be found in ImageMagicKSource.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef IMAGE_MAGICK_SOURCE_H
#define IMAGE_MAGICK_SOURCE_H

#include "ImageSource.h"
#include "Image.h"

class ImageMagicKSource : public ImageSource
/**
 * A class which implements the ImageSource interface as a source
 * of Images from a file stored in any format supported by the ImageMagicK
 * library (see http://www.imagemagick.org). This includes PNG, GIF, JPEG, TIFF
 * etc etc etc.
 *
 * Each image that is extracted from the ImageMagicK class is
 * a copy of the original image.
 *
 */
{
private:
            unsigned int width ;
            unsigned int height ;
            void         *img ;
            bool         ok ;
public:
            ImageMagicKSource(char *filename) ;
            ~ImageMagicKSource() ;

            bool InitOK() { return ok ; }

            void get_size(unsigned int &w, unsigned int &h) ;
            virtual ImageSource& operator>> (Image &) ;
            virtual ImageSource& operator>> (ImageRGB &) ;
            virtual ImageSource& operator>> (ImageGrey &) ;
         
} ;

#endif
