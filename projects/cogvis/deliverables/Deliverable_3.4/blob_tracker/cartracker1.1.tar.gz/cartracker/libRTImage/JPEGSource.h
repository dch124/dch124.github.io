/** @file JPEGSource.h 
 * 
 * Header file for the class 'JPEGSource'. 
 *
 * The source code for this class can be found in JPEGSource.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage) 
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/
   
#ifndef JPEG_SOURCE_H
#define JPEG_SOURCE_H

#include "ImageSource.h"
#include "Image.h"

#include <stdio.h>
#include <stdlib.h>  
#include <stddef.h>
#include <unistd.h>

#include <iostream>
#include <string>
#include <strstream>   

extern "C" {
#include "jpeglib.h"
}                 

using namespace std;                    

class JPEGSource : public ImageSource
/**
 * A class which implements the ImageSource interface as a source
 * of Images from a file stored in the jpeg format.
 *
 * Each image that is extracted from the JPEGSource class is 
 * a copy of the original jpeg image.
 *
 */
{
private:
/* Private Members */

    int width, height;  ///< JPEG Dimensions    
    unsigned char* image;

public:
    /// Create an Image source from a file
    JPEGSource(char* jpeg_name);

    /* Extraction operators */

    virtual ImageSource& operator >> (ImageRGB&);
    virtual ImageSource& operator >> (ImageGrey&);
    virtual ImageSource& operator >> (Image&);

    void get_size(unsigned int &w, unsigned int &h) 
      { w = width; h = height; }
    int get_height(){ return height;}

private:
/* private functions */
    void loadJPEG(char* filename);
};


#endif  // JPEG_SOURCE_H
