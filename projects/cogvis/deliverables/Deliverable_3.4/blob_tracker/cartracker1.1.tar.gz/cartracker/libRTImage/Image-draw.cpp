/** @file Image-draw.cpp
 *
 * Source file for draw methods in the class 'Image, ImageRGB, ImageGrey'.
 * 
 * Header info in 'Image.h', 'ImageRGB.h', 'ImageGrey.h'.
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/
#include "Image.h"
#include <math.h>

/**
 * Method draws a straight line from point (x_start,y_start) to (x_end,y_end) of
 * intensity described by brightness in PixelGrey intensity.
 * The method returns false if either point is outside the imagei.
 */
bool Image::draw_line(int x_start,
                      int y_start,
                      int x_end,
                      int y_end,
                      PixelGrey intensity)
{
        return ImageGrey::draw_line(x_start, y_start, x_end, y_end, intensity);
}

/**
 * Method draws a straight line from point (x_start,y_start) to (x_end,y_end) of
 * colour described by PixelRGB pix.
 * The method returns false if either point is outside the image.
 */
bool Image::draw_line(int x_start,
                      int y_start,
                      int x_end,
                      int y_end,
                      PixelRGB pix)
{
	return ImageRGB::draw_line(x_start, y_start, x_end, y_end, pix);
}

bool ImageGrey::draw_line(int x_start,
                      int y_start,
                      int x_end,
                      int y_end,
                      PixelGrey intensity)
{
/**
 * Method draws a straight line from point (x_start,y_start) to (x_end,y_end) of
 * intensity described by brightness in PixelGrey intensity. 
 * The method returns false if either point is outside the imagei.
 */

    bool         ret_val = true;
    double       gradient;
    double       offset;
    int          cnt;
    int          lowest_x;
    int          highest_x;
    int          lowest_y;
    int          highest_y;
    int          plot_pnt;

    if( ((x_start>=(int) width || y_start>=(int) height || x_start<0 || y_start<0) &&
         (x_end>=(int) width || y_end>=(int) height || x_end<0 || y_end<0)) ){
        /* Invalid inputs */
        ret_val = false ;
    }
    else{
        /* Draw line */
        if(x_start>x_end){
            highest_x = x_start;
            lowest_x  = x_end;
        }
        else{
            highest_x = x_end;
            lowest_x  = x_start;
        }
        if(y_start>y_end){
            highest_y = y_start;
            lowest_y  = y_end;
        }
        else{
            highest_y = y_end;
            lowest_y  = y_start;
        }
        if(x_start-x_end != 0){
            gradient = ((double)y_start-(double)y_end) / 
                                   ((double)x_start-(double)x_end) ;
            offset = y_start - gradient*x_start;
            for(cnt=lowest_y; cnt<=highest_y ; cnt++){
                plot_pnt = (int)((cnt-offset)/gradient + 0.5) ;
                if(plot_pnt<(int) width && cnt<(int) height && plot_pnt>=0 && cnt>=0){
                    *(brightness+plot_pnt+(int) width*cnt) = intensity ;
                }
            }
            for(cnt=lowest_x; cnt<=highest_x ; cnt++){
                plot_pnt = (int)(gradient*cnt + offset + 0.5) ;
                if(plot_pnt<(int) height && cnt<(int) width && plot_pnt>=0 && cnt>=0){
                    *(brightness+cnt+(int) width*plot_pnt) = intensity ;
                }
            }
        }
        else{
        /* Gradient is infinite */
            for(cnt=lowest_y; cnt<=highest_y ; cnt++){
                if(cnt<(int) height && cnt>=0){
                    *(brightness+x_start+cnt*(int) width) = intensity ;
                }
            }
        }
    }
    return ret_val;
} 


bool ImageRGB::draw_line(int x_start,
                         int y_start,
                         int x_end,
                         int y_end,
                         PixelRGB pix)
{
/**
 * Method draws a straight line from point (x_start,y_start) to (x_end,y_end) of 
 * colour described by PixelRGB pix.
 * The method returns false if either point is outside the image.
 */

    bool         ret_val = true;
    double       gradient;
    double       offset;
    int          cnt;
    int          lowest_x;
    int          highest_x;
    int          lowest_y;
    int          highest_y;
    int          plot_pnt;

    if( ((x_start>=(int) width || y_start>=(int) height || x_start<0 || y_start<0) &&
         (x_end>=(int) width || y_end>=(int) height || x_end<0 || y_end<0)) ){
    /* Invalid inputs */
        ret_val = false ;
    }
    else{
    /* Draw line */
        if(x_start>x_end){
            highest_x = x_start;
            lowest_x  = x_end;
        }
        else{
            highest_x = x_end;
            lowest_x  = x_start;
        }

        if(y_start>y_end){
            highest_y = y_start;
            lowest_y  = y_end;
        }
        else{
            highest_y = y_end;
            lowest_y  = y_start;
        }

        if(x_start-x_end != 0){
            gradient = ((double)y_start-(double)y_end) / 
                                   ((double)x_start-(double)x_end) ;
            offset = y_start - gradient*x_start;
            for(cnt=lowest_y; cnt<=highest_y ; cnt++){
                plot_pnt = (int)((cnt-offset)/gradient + 0.5) ;
                if(plot_pnt<(int) width && cnt<(int) height && plot_pnt>=0 && cnt>=0){
                    set_pixel(plot_pnt,cnt,pix);
                }
            }
            for(cnt=lowest_x; cnt<=highest_x ; cnt++){
                plot_pnt = (int)(gradient*cnt + offset + 0.5) ;
                if(plot_pnt<(int) height && cnt<(int) width && plot_pnt>=0 && cnt>=0){
                    set_pixel(cnt,plot_pnt,pix);
                }
            }
        }
        else{
        /* Gradient is infinite */
            for(cnt=lowest_y; cnt<=highest_y ; cnt++){
                if(cnt<(int) height && cnt>=0){
                    set_pixel(x_start, cnt,pix);
                }
            }
        }
    }
    return ret_val;
} 

/**
 * Method draws a filled circle with centre at point (centre_x,centre_y) of
 * radius radius and brightness described by PixelGrey intensity.
 * The method returns false if any point is outside the image.
 */
bool Image::draw_filled_circle(unsigned int centre_x,
                                   unsigned int centre_y,
                                   unsigned int radius,
                                   PixelGrey intensity)
{
    return ImageGrey::draw_filled_circle(centre_x, centre_y, radius, intensity);
}

/**
 * Method draws a filled circle with centre at point (centre_x,centre_y) of
 * radius radius and colour described by PixelRGB pix.
 * The method returns false if any point is outside the image.
 */
bool Image::draw_filled_circle(unsigned int centre_x,
                                   unsigned int centre_y,
                                   unsigned int radius,
                                   PixelRGB pix)
{
    return ImageRGB::draw_filled_circle(centre_x, centre_y, radius, pix);
}


bool ImageGrey::draw_filled_circle(unsigned int centre_x,
                                   unsigned int centre_y,
                                   unsigned int radius, 
                                   PixelGrey intensity)
{
/**
 * Method draws a filled circle with centre at point (centre_x,centre_y) of
 * radius radius and brightness described by PixelGrey intensity.
 * The method returns false if any point is outside the image.
 */

    bool         ret_val = true ;
    int          cnt;
    unsigned int plot_pnt;

    if( centre_x>= width         ||
        centre_y>= height        ||
        radius>centre_x         ||
        radius>centre_y         ||
        radius+centre_x>= width  ||
        radius+centre_y>= height ){
    /* Inputs are invalid */
        ret_val = false ;
    }
    else{
    /* Draw circle */
        for(cnt=-(radius-1) ; cnt<(int)radius ; cnt++ ){
        /* For each x calculate y using r^2 = x^2 + y^2 */ 
        /* For each y calculate x using r^2 = x^2 + y^2 */ 
            plot_pnt = (unsigned int)(sqrt(radius*radius - cnt*cnt)+0.5);
            draw_line(centre_x+cnt,centre_y+plot_pnt,
                      centre_x-cnt,centre_y+plot_pnt,
                      intensity);
            draw_line(centre_x+cnt,centre_y-plot_pnt,
                      centre_x-cnt,centre_y-plot_pnt,
                      intensity);
            draw_line(centre_x+plot_pnt,centre_y+cnt,
                      centre_x-plot_pnt,centre_y+cnt,
                      intensity);
            draw_line(centre_x+plot_pnt,centre_y-cnt,
                      centre_x-plot_pnt,centre_y-cnt,
                      intensity);
        }
    }
    return ret_val;
}

bool ImageRGB::draw_filled_circle(unsigned int centre_x,
                                   unsigned int centre_y,
                                   unsigned int radius, 
                                   PixelRGB pix)
{
/**
 * Method draws a filled circle with centre at point (centre_x,centre_y) of
 * radius radius and colour described by PixelRGB pix.
 * The method returns false if any point is outside the image.
 */

    bool         ret_val = true ;
    int          cnt;
    unsigned int plot_pnt;

    if( centre_x>= width         ||
        centre_y>= height        ||
        radius>centre_x         ||
        radius>centre_y         ||
        radius+centre_x>= width  ||
        radius+centre_y>= height ){
    /* Inputs are invalid */
        ret_val = false ;
    }
    else{
    /* Draw circle */
        for(cnt=-(radius-1) ; cnt<(int)radius ; cnt++ ){
        /* For each x calculate y using r^2 = x^2 + y^2 */ 
        /* For each y calculate x using r^2 = x^2 + y^2 */ 
            plot_pnt = (unsigned int)(sqrt(radius*radius - cnt*cnt)+0.5);
            draw_line(centre_x+cnt,centre_y+plot_pnt,
                          centre_x-cnt,centre_y+plot_pnt,
                          pix);
            draw_line(centre_x+cnt,centre_y-plot_pnt,
                          centre_x-cnt,centre_y-plot_pnt,
                          pix);
            draw_line(centre_x+plot_pnt,centre_y+cnt,
                          centre_x-plot_pnt,centre_y+cnt,
                          pix);
            draw_line(centre_x+plot_pnt,centre_y-cnt,
                          centre_x-plot_pnt,centre_y-cnt,
                          pix);
        }
    }
    return ret_val;
}

