/** @file MPEGSource.h 
 * 
 * Header file for the class 'MPEGSource'. 
 *
 * The source code for this class can be found in MPEGSource.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage) 
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef MPEG_SOURCE_H
#define MPEG_SOURCE_H

#include "Image.h"
#include "ImageSource.h"
#include "libmpeg3.h"


class MPEGSource : public ImageSource
/**
 * A class which implements the ImageSource interface as a source
 * of MPEG movie Images.
 *
 * Each image that is extracted from the MPEGSource class is 
 * a frame of the MPEG movie.
 *
 * @note Assumes only one stream
 */
{
protected:
/* Protected Members */

	mpeg3_t*	file;		///< MPEG file handle

	unsigned char**	buff;		///< Buffer for decoded data

        char            *Y ;            ///< Buffer for decoded YUV Y data
        char            *U ;            ///< Buffer for decoded YUV U data
        char            *V ;            ///< Buffer for decoded YUV V data
	
	unsigned int	width;		///< MPEG width
	unsigned int	height;		///< MPEG height
	long 		frames;		///< Number of frames in movie
	float 		framerate;	///< Frame rate of the movie
public:
/* Public Methods */

	/// Initialise an MPEG movie source 
	MPEGSource(char* path);

	~MPEGSource();

	/* Extraction operators */
	
	virtual ImageSource& operator >> (ImageRGB&);
	virtual ImageSource& operator >> (ImageGrey&);
	virtual ImageSource& operator >> (Image&);

	/// Return the width and height of the MPEG
	void get_size(unsigned int&, unsigned int&);

        /// Seek to point in file
        int set_frame(long frame_no) ;
	/// Return the frame rate of the MPEG
	void get_framerate(float&);

	/// Test for end of file
	bool eof(void) const;
};

#endif	// MPEG_SOURCE_H
