/** @file RandomSource.cpp
 *
 * File containing methods for the 'RandomSource' class.
 *
 * The header for this class can be found in RandomSource.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following 
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/
 
#include <time.h>	// time()
#include <unistd.h>	// usleep()
#include <stdlib.h>	// rand()

#include "RandomSource.h"


RandomSource::RandomSource(unsigned int w, unsigned int h, unsigned int fps)
/**
 * Initialise the RandomSource to produce images of width w and height h
 * at a rate of fps Image's (frames) per second.
 *
 * @param w   The width of the Images to be produced.
 * @param h   The height of the Images to be produced.
 * @param fps The rate at which Images are produced.
 */
{
	// initialise random sunber generator
	srand(time(NULL));
	sleeptime = 1000000 / fps;

	// default palette for this ImageSource is colour
	type      = Image::COLOUR;
}


/**
 * Extract a randomly generated colour Image.
 *
 * The method sleeps for a short time so that images are not
 * created at too fast a rate.
 *
 * @param img The colour Image to be extracted to.
 */
ImageSource& RandomSource::operator >> (ImageRGB& img) 
{
	update(img);
	usleep(sleeptime);
	
	return *this;
}


/**
 * Extract a randomly generated greyscale Image.
 *
 * The method sleeps for a short time so that images are not
 * created at too fast a rate.
 *
 * @param img The greyscale Image to be extracted to.
 */
ImageSource& RandomSource::operator >> (ImageGrey& img) 
{
	update(img);
	usleep(sleeptime);
	
	return *this;
}


/**
 * Extract a randomly generated Image.
 *
 * The Image could be colour or greyscale depending on the 
 * default palette type for this class.
 * 
 * The method sleeps for a short time so that images are not
 * created at too fast a rate.
 *
 * @param img The Image to be extracted to.
 */
ImageSource& RandomSource::operator >> (Image& img) 
{
	(type == Image::COLOUR) ? update((ImageRGB&)  img) 
				: update((ImageGrey&) img);
	usleep(sleeptime);
	
	return *this;
}


/**
 * Create a random colour Image an store it in the data buffer of 
 * the img passed.
 *
 * Each pixel in the Image will have the same randomly generated 
 * red, green, and blue values.
 *
 * @param img The colour Image in which to generate the random Image
 */
void RandomSource::update(ImageRGB& img)
{
	int *d = img.data[0];
	unsigned int size = img.get_width() * img.get_height();
	
	// generate random values
	int r = rand() % 255;
	int g = rand() % 255;
	int b = rand() % 255;

	// set all the pixels in the Image
	for (unsigned int i = 0; i < size; i++, d+=3) {
			*d     = r;
			*(d+1) = g;
			*(d+2) = b;
	}
}


/**
 * Create a random greyscale Image an store it in the brightness 
 * buffer of the img passed.
 *
 * Each pixel in the Image will have the same randomly generated 
 * brightnesss values.
 *
 * @param img The colour Image in which to generate the random Image
 */
void RandomSource::update(ImageGrey& img)
{
	int *d = img.brightness;
	unsigned int size = img.get_width() * img.get_height();
	
	// generate the random value
	int b = rand() % 255;

	// set all the pixels in the image
	for (unsigned int i = 0; i < size; i++, d++) *d = b;
}

