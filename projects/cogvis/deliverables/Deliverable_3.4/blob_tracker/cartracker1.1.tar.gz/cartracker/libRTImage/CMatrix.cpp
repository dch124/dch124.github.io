/** @file CMatrix.cpp
 *
 * File containing methods for the 'CMatrix' class.
 *
 * The header for this class can be found in CMatrix.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following 
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#include <stdio.h>
#include <math.h>
#include <CMatrix.h>

CMatrix::CMatrix(unsigned int rows, unsigned int columns)
{
// Constructor for new object

    InitOk = true ;
    r = rows ;
    c = columns ;
    size = r*c ;

    if((data = new float[size])==NULL) InitOk = false ;
}

CMatrix::CMatrix(char *filename)
{
// Constructor to load from formated file

    FILE *fp ;
    unsigned int cnt ;
    float        f_in ;
    float        *d_ptr ; ;
    int          r_in, c_in ;

    InitOk = true ;

    if((fp=fopen(filename,"r"))==NULL) InitOk = false ;
    else if(fscanf(fp,"%d",&r_in)==EOF) InitOk = false ;
    else if(fscanf(fp,"%d",&c_in)==EOF) InitOk = false ;
    else if(r_in<1 || c_in<1) InitOk = false ;
    else if((data = new float[r_in*c_in])==NULL) InitOk = false ;
    else{
        r = r_in ;
        c = c_in ;
        size = r*c ;
    }
    
    for(cnt=0, d_ptr=data ; InitOk && cnt<size ; cnt++,d_ptr++){
        if(fscanf(fp,"%f",&f_in)==EOF) InitOk = false ;
        else                           *d_ptr = f_in ;
    }
}

CMatrix::CMatrix(char *filename, unsigned int rows, unsigned int columns)
{
// Constructor to load from unformated text file

    FILE *fp ;
    unsigned int cnt ;
    float        f_in ;
    float        *d_ptr ; ;

    InitOk = true ;
    r = rows ;
    c = columns ;
    size = r*c ;

    if((fp=fopen(filename,"r"))==NULL) InitOk = false ;
    else if((data = new float[r*c])==NULL) InitOk = false ;

    for(cnt=0, d_ptr=data ; InitOk && cnt<size ; cnt++,d_ptr++){
        if(fscanf(fp,"%f",&f_in)==EOF) InitOk = false ;
        else                           *d_ptr = f_in ;
    }
}

void CMatrix::set_element(unsigned int row,
                          unsigned int col,
                          double       val)
{
// Sets element x,y to val

    data[col + c*row] = val ;
}

float CMatrix::get_element(unsigned int row,
                           unsigned int col) 
{
// Returns element x,y 

    return data[col + c*row] ;
}

unsigned int CMatrix::get_no_rows() 
{
// Returns the no. of row in the matrix

    return r ;
}

unsigned int CMatrix::get_no_columns() 
{
// Returns the no. of columns in the matrix

    return c ;
}

bool CMatrix::save(char *filename)
{
// Saves matrix to a formatted file

    FILE         *fp ;
    unsigned int cntx ;
    unsigned int cnty ;
    bool         rv  = true ;
    float        *d_ptr ;

    if((fp = fopen(filename,"w"))==NULL) rv = false ;
    else if(fprintf(fp,"%d %d\n",r,c)==EOF) rv = false ;

    for(cnty=0,d_ptr=data ; rv && cnty<r ; cnty++){
        for(cntx=0 ; rv && cntx<c ; cntx++,d_ptr++){
            if(fprintf(fp,"%f ",*d_ptr)==EOF) rv = false ;
        }
        if(fprintf(fp,"\n")==EOF) rv = false ;
    }

    return rv ;
}

bool CMatrix::save_raw(char *filename)
{
// Saves matrix to a raw text file (suitable for Matlab etc.)

    FILE         *fp ;
    unsigned int cntx ;
    unsigned int cnty ;
    bool         rv  = true ;
    float        *d_ptr ;

    if((fp = fopen(filename,"w"))==NULL) rv = false ;

    for(cnty=0,d_ptr=data ; rv && cnty<r ; cnty++){
        for(cntx=0 ; rv && cntx<c ; cntx++,d_ptr++){
            if(fprintf(fp,"%f ",*d_ptr)==EOF) rv = false ;
        }
        if(fprintf(fp,"\n")==EOF) rv = false ;
    }

    return rv ;
}

float CMatrix::calc_max_kernel_val()
{
// Returns maximum value of kernel

    unsigned int cnt ;
    float        *ptr ;
    float        ret_val = -HUGE_VAL ;

    ptr = data ;
    for(cnt=0 ; cnt<size ; cnt++,ptr++){
        if(*ptr > ret_val) ret_val = *ptr ;
    }

    return ret_val ;
}

float CMatrix::calc_min_kernel_val()
{
// Returns maximum value of kernel

    unsigned int cnt ;
    float        *ptr ;
    float        ret_val = HUGE_VAL ;

    ptr = data ;
    for(cnt=0 ; cnt<size ; cnt++,ptr++){
        if(*ptr < ret_val) ret_val = *ptr ;
    }

    return ret_val ;
}
 

bool CMatrix::initialised_ok()
{
// Returns constructor sucess flag

    return InitOk ;
}    

