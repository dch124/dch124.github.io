/** @file Video4LinuxSource.h
 * 
 * Header file for the class 'Video4LinuxSource'. 
 *
 * The source code for this class can be found in Video4LinuxSource.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage) 
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef V4L_SOURCE_H
#define V4L_SOURCE_H

#include <linux/videodev.h>

#include "ImageSource.h"
#include "Image.h"


class Video4LinuxSource : public ImageSource
/**
 * A class which implements the ImageSource interface as a source
 * of Images supplied from a Video4Linux compatible device such
 * as webcams and tv cards.
 *
 * @bug Memory mapping is not yet functional.
 * 
 * @todo Needs to be expanded to add more of the Video4Linux API
 *       so that more devices can be supported 'out of the box'.
 */
{
protected:
/* Protected Members */
	
	int		fd;		///< device file handle
	
	// internal temporary buffer
	
	unsigned char*	buff;		///< temporary buffer
	unsigned int	buffsize;	///< size of temporary buffer
	int		currentBuffer;	///< number of current buffer
	int		numBuffers;	///< total number of buffers
	
	// source attributes
	
	unsigned int	width;		///< width of source image
	unsigned int	height;		///< height of source image
	unsigned int	size;		///< total size of source image
	
	video_mbuf	mbuf;		///< memory buffer structure
        video_mmap      vmmap;          ///< memory map structure     
	int 		palette;	///< palette to use for the device
	
	bool		capture;	/**< true if capture to memory is 
					     possible for this device. 
					     This is always false though
					     see constructor in Video4Linux.cpp
					 */
	
public:
/* Public Methods */
	
	/// Initialise a Video4Linux source
	Video4LinuxSource(char* device, bool sup_memory_map);

	virtual ~Video4LinuxSource();

	/* Extraction operators */
	
	virtual ImageSource& operator >> (ImageRGB&);
	virtual ImageSource& operator >> (ImageGrey&);
	virtual ImageSource& operator >> (Image&);
	
	/// Set the size of source Images
	void set_size(unsigned int, unsigned int);

	/// Set the rate of Image acquistion
	void set_framerate(unsigned int);

	/// Set the palette of the acquired Images
	void set_palette(int);

	/// Set the channel to use for image acquisition
	void set_channel(int);

	
	/// Get the size of the source Images
	void get_size(unsigned int&, unsigned int&);

	/// Get the rate of Image acquisition
	void get_framerate(unsigned int&);

	/// Get the palette used by acquired Images
	void get_palette(int&);
	
protected:
/* Protected Methods */

	// wrappers for ioctl set calls
	
	inline int set_capability(video_capability&);
	inline int set_frameBuffer(video_buffer&);
	inline int set_captureWindows(video_window&);
	inline int set_videoSource(int);
	inline int set_imageProperties(video_picture&);
	inline int set_tuning(video_tuner&);
	inline int set_memoryBuffer(video_mbuf&);

	// wrappers for ioctl get calls
	
	inline int get_capability(video_capability&);
	inline int get_frameBuffer(video_buffer&);
	inline int get_captureWindows(video_window&);
	inline int get_videoSource(video_channel&);
	inline int get_imageProperties(video_picture&);
	inline int get_tuning(video_tuner&);
	inline int get_memoryBuffer(video_mbuf&);
	
	// methods to display device information
	
	void print_capability(video_capability&);
	void print_frameBuffer(video_buffer&);
	void print_captureWindows(video_window&);
	void print_videoSource(video_channel&);
	void print_imageProperties(video_picture&);
	void print_tuning(video_tuner&);
	void print_memoryBuffer(video_mbuf&);

	// conversion function pointers
	
	/// conversion method for colour Images
	void (*convert_rgb)  (int width, int height, void*, void*);
	
	/// conversion method for greyscale Images
	void (*convert_grey) (int width, int height, void*, void*);
	
};

#define DEBUG_V4L_SOURCE
#endif	// V4L_SOURCE_H
