/** @file QTSource.h 
 * 
 * Header file for the class 'QTSource'. 
 *
 * The source code for this class can be found in QTSource.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage) 
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef QT_SOURCE_H
#define QT_SOURCE_H

#include "Image.h"
#include "ImageSource.h"
extern "C" {
#include <quicktime.h> 
}

class QTSource : public ImageSource
/**
 * A class which implements the ImageSource interface as a source
 * of QT movie Images.
 *
 * Each image that is extracted from the QTSource class is 
 * a frame of the QT movie.
 *
 * @note Assumes only one stream
 */
{
protected:
/* Protected Members */

	quicktime_t*	file;		///< QT file handle	
	char*		comp_type;	///< Compression Type

	unsigned char**	buff;		///< Buffer for decoded data
	
	unsigned int	width;		///< QT width
	unsigned int	height;		///< QT height
	long 		frames;		///< Number of frames in movie
	
public:
/* Public Methods */

	/// Initialise an QT movie source 
	QTSource(char* path);

	~QTSource();

	/* Extraction operators */
	
	virtual ImageSource& operator >> (ImageRGB&);
	virtual ImageSource& operator >> (ImageGrey&);
	virtual ImageSource& operator >> (Image&);

	/// Return the width and height of the QT
	void get_size(unsigned int&, unsigned int&);

        /// Seek to point in file
        int set_frame(long frame_no) ;
};

#endif	// QT_SOURCE_H
