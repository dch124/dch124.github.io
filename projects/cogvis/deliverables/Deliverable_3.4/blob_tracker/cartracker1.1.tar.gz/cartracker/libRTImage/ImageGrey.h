/** @file ImageGrey.h 
 * 
 * Header file for the class 'ImageGrey'. 
 *
 * The source code for this class can be found in ImageGrey.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef IMAGE_GREY_H
#define IMAGE_GREY_H

#include "ImageBase.h"
#include <CMatrix.h>
#include <Wavelet.h>
 
/// Single pixel constsisting of an int.
typedef int 	 PixelGrey;

	
class ImageGrey : virtual public ImageBase
/**
 * An image where each pixel consists of a varying level of grey.
 *
 * The image is stored as an array of ints, each pixel represented
 * as a single int.
 */
{
public:
	PixelGrey		*brightness;	///< Greyscale image data

public:
/* Public Methods */

	
	/// Create an image with the given dimensions
	ImageGrey(unsigned int width, unsigned int height);

	ImageGrey(ImageGrey&);	///< Copy constructor

        ImageGrey(ImageGrey&   img,
                  unsigned int min_x,
                  unsigned int min_y,
                  unsigned int max_x,
                  unsigned int max_y) ;


	~ImageGrey();

	/// Set the grey level value of a pixel specified by (x,y)
	void		set_pixel(unsigned int x, unsigned int y, 
				  PixelGrey level);
	
	/** 
	 * Return the value of the pixel specified by (x,y) in p.
	 */
	void		get_pixel(unsigned int x, unsigned int y, 
			          PixelGrey& p);

	/// Set to value (clear) all of the pixels in the image.
	ImageGrey&	clear(int = 0);

	/// Copy data from image data from img.
	ImageGrey&	copy(ImageGrey& img);

         /// Copy data from block of image data from img.
        ImageGrey&      copy(ImageGrey& img,
                             unsigned int min_x,
                             unsigned int min_y,
                             unsigned int max_x,
                             unsigned int max_y,
                             unsigned int start_x,
                             unsigned int start_y);

        /// Absolute value of brightness
        void            absolute() ;

        /// Threshold brightness
        void            threshold(int thresh) ;

        /// Save in graphics file format
        bool            save(char *, FileFormat) ;
	
	/* Operator overloading */
	
	/// Overload equals (=) operator for two images.
	ImageGrey&		operator = (ImageGrey& img)
	 { return this->copy(img); }

        /// Overload equals (-=) operator for two images.
        ImageGrey&              operator -= (ImageGrey& img) ;

        bool            draw_line(int x_start, int y_start,
                                  int x_end, int y_end,
                                  PixelGrey intensity);
        bool    	draw_filled_circle(unsigned int centre_x,
                                           unsigned int centre_y,
                                           unsigned int radius,
                                           PixelGrey intensity);
	void		scale_down(unsigned int min_x,
                       	           unsigned int min_y,
                                   unsigned int max_x,
                                   unsigned int max_y,
                                   unsigned int new_sx,
                                   unsigned int new_sy,
                                   float        *new_image);
        void            scale_down(unsigned int min_x,
                                   unsigned int min_y,
                                   unsigned int max_x,
                                   unsigned int max_y,
                                   unsigned int new_sx,
                                   unsigned int new_sy,
                                   double       *new_image);    
        void            quick_scale_down(unsigned int min_x,
                                         unsigned int min_y,
                                         unsigned int max_x,
                                         unsigned int max_y,
                                         unsigned int new_sx,
                                         unsigned int new_sy,
                                         double       *new_image);    
        
	// Convolution methods

        /**
	 * Convolve image with a kernel 	
	 */  
        float           convolve(unsigned int x,
                                 unsigned int y,
                                 CMatrix      *conv_matrix) ;
        void            plot_conv_kernel(unsigned int x,
                                         unsigned int y,
                                         CMatrix      *conv_matrix,
                                         float        scale_fact,
                                         float        offset) ;
        float           wavelet_convolve(unsigned int x,
                                         unsigned int y,
                                         Wavelet *wavelet,
                                         float        *real,
                                         float        *imag) ;

        // Edge detection
        bool            sobel_horizontal(ImageGrey &result) ;
        bool            sobel_vertical(ImageGrey &result) ;
        bool            sobel(ImageGrey &result) ;
};


#endif	// IMAGE_GREY_H
