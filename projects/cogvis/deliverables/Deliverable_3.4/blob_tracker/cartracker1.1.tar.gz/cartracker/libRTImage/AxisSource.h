/** @file AxisSource.h 
 * 
 * Header file for the class 'AxisSource'. 
 *
 * The source code for this class can be found in AxisSource.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage) 
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/
   
#ifndef AXIS_SOURCE_H
#define AXIS_SOURCE_H

#include "ImageSource.h"
#include "Image.h"

#include <stdio.h>
#include <stdlib.h>  
#include <stddef.h>
#include <unistd.h>
#include <errno.h>    

#include <string.h>
#ifndef __linux__
  #include <bstring.h>
#endif

#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>

#include <iostream>
#include <string>
#include <strstream>   

//#include "JPEG_Decoder.h"
extern "C" {
#include "jpeglib.h"
void jpeg_mem_src(j_decompress_ptr, unsigned char *, int);
}                 

using namespace std;                    

// Access the camera through the standard web server port
#define PORT 80                

/// Possible Frame Sizes
enum FrameSize { HALF, FULL }; 

class AxisSource : public ImageSource
/**
 * A class which implements the ImageSource interface as a source
 * of Images from the internet AxisCamera.
 *
 * Each image that is extracted from the AxisSource class is 
 * the next frame recieved from the webserver.
 *
 */
{
private:
/* Private Members */
	
	int	vs;		///< Video Socket to Web Server.
        int     dims[2];	///< Video dimensions. 
        unsigned char*	img_ptr;

public:
	/// Create an source of Images from the Internet Camera
	AxisSource(char* axis_name, FrameSize frame_size);
        AxisSource(); 
	~AxisSource();
		
	/* Extraction operators */
	
	virtual	ImageSource& operator >> (ImageRGB&);
	virtual	ImageSource& operator >> (ImageGrey&);
	virtual	ImageSource& operator >> (Image&);

        int get_width(){  return dims[0];}
        int get_height(){ return dims[1];}

private:
	int  	videoSocket(char*);
	void 	requestStream (int);
	int  	readFrame     (int, unsigned char* &, int&);
	void 	readNextFrame (int, unsigned char* &, int [2]);
	int  	readSocket    (int, unsigned char*, int);
        void    decodeFrame(unsigned char* imgBuff, int buffLength,
                                 unsigned char* &image,  int imgSize[2]);
};


#endif	// AXIS_SOURCE_H
