/** @file Video4LinuxSource.cpp
 *
 * File containing methods for the 'Video4LinuxSource' class.
 *
 * The header for this class can be found in Video4LinuxSource.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following 
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/
 
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>

#include "ccvt/conv.h"
#include "pwc-ioctl.h"

#include "Video4LinuxSource.h"

#include <string.h>

Video4LinuxSource::Video4LinuxSource(char* device, bool sup_memory_map)
/**
 * Open and initialise the specified device and use it
 * as a source of Images.
 *
 * @param device The Video4Linux compatible device.
 */
{
	video_capability cap;
        video_picture    grab_pic ; 

        capture = sup_memory_map ;

        get_capability(cap);

        if(capture){ 
        // Use memory mapping

            if ((fd = open("/dev/video0",O_RDWR)) == -1 ) {
                    exit(1);
            }

            if (ioctl(fd,VIDIOCGCAP,&cap) == -1) {
                    fprintf(stderr,"wrong device\n");
                    exit(1);
            }
            memset (&grab_pic, 0, sizeof(struct video_picture));
            if (ioctl (fd, VIDIOCGPICT, &grab_pic) == -1) {
                    fprintf (stderr, "no pict");
                    exit(1);
            }

	    get_size(width,height);

            vmmap.frame  = 0 ;
            vmmap.width  = width ;
            vmmap.height = height ;
            vmmap.format = VIDEO_PALETTE_RGB24;
            size = vmmap.width * vmmap.height *  (24/8) ; 

            buff = (unsigned char *)mmap(0,size,PROT_READ|PROT_WRITE,MAP_SHARED,
                                         fd,0);
        
            convert_rgb  = conv_bgr24_rgb96;
            convert_grey  = conv_rgb24_grey;
       }
       else{
       // Do not use memory mapping

	    // open the device
	    fd = open(device, O_RDWR);
	    if (fd == -1)
	 	throw "error opening device";
	
	    // retrieve the size of the Images to be acquired from the device
	    get_size(width,height);
	    size = width * height;
	
            buffsize = int(size * 1.5 + 0.5);
            buff     = new (unsigned char)[buffsize];

            // get and set palette to set the conversion routines correctly
	    get_palette(palette);
	    set_palette(palette);
	
        }	

 	// default palette type for this ImageSource is colour 
	type = Image::COLOUR;
}


Video4LinuxSource::~Video4LinuxSource()
/**
 * Close the device and unmap any mapped memory
 * or free up memory if necessary.
 */
{
	// unmap the memory map if capturing was supported
	if (capture)
		munmap(buff, buffsize);

	// XXX should buff be deleted if mmap created it?	
	delete [] buff; 
	
	close(fd);
}


void Video4LinuxSource::set_size(unsigned int w, unsigned int h)
/**
 * Use the ioctl wrappers to set the size of the Images to be read
 * from the Video4Linux device.
 *
 * @note
 * Although the device is issued with the instruction to change 
 * size it may not be changed in the device itself. Sometimes this
 * is necessary so that incorect values cannot be set.
 *
 * @param w The width of the Image.
 * @param h The height of the Image.
 */
{
	video_window  win;

	// first get the existing video_window values.
	get_captureWindows(win);
	
	win.width  = w;
	win.height = h;
	
	set_captureWindows(win);
	get_captureWindows(win);


        if(capture){
        // Re set up memory map
	    width = w; height = h;

            vmmap.width  = width ;
            vmmap.height = height ;
            vmmap.format = VIDEO_PALETTE_RGB24;
            size = vmmap.width * vmmap.height *  (24/8) ;
//            ioctl(fd,VIDIOCGMBUF,mbuf) ;
            ioctl(fd,VIDIOCGMBUF,&mbuf) ;

//            buff = (unsigned char *)mmap(0,size,PROT_READ|PROT_WRITE,MAP_SHARED,
            buff = (unsigned char *)mmap(0,mbuf.size,PROT_READ|PROT_WRITE,MAP_SHARED,
                                         fd,0);

        }
        else if(width !=win.width || height != win.height){
	    width = w; height = h;

	    delete [] buff;
	
	    size     = win.width * win.height;
	    buffsize = int(size * 1.5 + 0.5);
	    buff     = new (unsigned char)[buffsize];
	    cerr << "size: " << size << endl;	
	    cerr << "buffsize: " << buffsize << endl;	
        }
}


void Video4LinuxSource::set_framerate(unsigned int fps)
/**
 * Use the ioctl wrappers to set the rate of acquistion of the
 * Images to be read from the Video4Linux device.
 *
 * @note
 * Although the device is issued with the instruction to change 
 * framerate it may not be changed in the device itself. Sometimes this
 * is necessary so that incorect values cannot be set.
 *
 * @param fps The framerate to use.
 */
{
	video_window  win;
	
	// first get the existing video_window values.
	get_captureWindows(win);
	
	win.flags &= ~PWC_FPS_FRMASK;
	win.flags |= (fps << PWC_FPS_SHIFT);
	
	set_captureWindows(win);
}


void Video4LinuxSource::set_palette(int pal)
/**
 * Use the ioctl wrappers to set the palette of the acquired Images 
 * to be read from the Video4Linux device.
 *
 * @note
 * Although the device is issued with the instruction to change 
 * palette it may not be changed in the device itself. Normally this
 * will be because the selected palette is not supported.
 *
 * @param pal The palette to use.
 */
{
	video_picture pic;
	
	// get existing video_picture properties
	get_imageProperties(pic);
	
	pic.palette = pal;

pic.depth = 24 ;
	
	set_imageProperties(pic);
	get_imageProperties(pic);

cerr << "Setting pallette " << pal << " " << pic.palette << " " << pic.depth << endl ; 

	// select conversion routines for new palette
	switch (pic.palette) {
	case VIDEO_PALETTE_RGB32:
		convert_rgb  = conv_rgb32_rgb96;
		convert_grey = conv_rgb32_grey;
		break;
	case VIDEO_PALETTE_YUV420P:
	default:
		convert_rgb  = conv_420p_rgb96;
		convert_grey = conv_420p_grey;
		break;
	};
}


void Video4LinuxSource::set_channel(int channel)
/**
 * Use the ioctl wrappers to set the channel of the Video4Linux 
 * device to read the Images from.
 *
 * @param channel The channel to use.
 */
{
	set_videoSource(channel);
}


void Video4LinuxSource::get_size(unsigned int& w, unsigned int& h)
{
    if(capture){
        w = width ;
        h = height ;
    }
    else{
	video_window  win;
	get_captureWindows(win);
	
	w = win.width;
	h = win.height;
    }
}


void Video4LinuxSource::get_framerate(unsigned int& fps)
{
	video_window  win;
	get_captureWindows(win);
	fps = (win.flags & PWC_FPS_FRMASK) >> PWC_FPS_SHIFT;
}


void Video4LinuxSource::get_palette(int& pal)
{
	video_picture pic;
	get_imageProperties(pic);
	pal =  pic.palette;
}


ImageSource& Video4LinuxSource::operator >> (ImageRGB& img)
{
	unsigned char* src = buff;

	if (capture) {

                ioctl(fd,VIDIOCMCAPTURE,&vmmap)  ;
                src += mbuf.offsets[currentBuffer];

                if(!currentBuffer) currentBuffer++ ;
                else              currentBuffer=0 ; 

                vmmap.frame = currentBuffer ;
        } 
        else{
		read(fd, src, buffsize);
        }

	convert_rgb(width, height, src, (int *)img.data);

        if(capture){
        // Free buffer to be used next
                ioctl(fd,VIDIOCSYNC,&currentBuffer) ;
        }

	return *this;
}


ImageSource& Video4LinuxSource::operator >> (ImageGrey& img)
{
	unsigned char* src = buff;

	if (capture) {
                ioctl(fd,VIDIOCMCAPTURE,&vmmap)  ;
                src += mbuf.offsets[currentBuffer];

                if(!currentBuffer) currentBuffer++ ;
                else              currentBuffer=0 ;

                vmmap.frame = currentBuffer ;
	} else
		read(fd, src, buffsize);
	
	convert_grey(width, height, src, img.brightness);

        if(capture){
        // Free buffer to be used next
                ioctl(fd,VIDIOCSYNC,&currentBuffer) ;
        }

	
	return *this;
}


ImageSource& Video4LinuxSource::operator >> (Image& img)
{
	unsigned char* src = buff;
	
	if (capture) {
                ioctl(fd,VIDIOCMCAPTURE,&vmmap)  ;
                src += mbuf.offsets[currentBuffer];

                if(!currentBuffer) currentBuffer++ ;
                else              currentBuffer=0 ;

                vmmap.frame = currentBuffer ;

	} else
		read(fd, src, buffsize);
	
	if (type == Image::COLOUR)
		convert_rgb(width, height, src, img.data[0]);
	else {
		convert_grey(width, height, src, img.brightness);
	}

        if(capture){
        // Free buffer to be used next
                ioctl(fd,VIDIOCSYNC,&currentBuffer) ;
        }

	
	return *this;
}

/* set ioctl methods */

int Video4LinuxSource::set_frameBuffer(video_buffer& fbuf)
/// ioctl wrapper for VIDIOCSFBUF
{ return ioctl(fd, VIDIOCSFBUF, &fbuf); }

int Video4LinuxSource::set_captureWindows(video_window& win)
/// ioctl wrapper for VIDIOCSWIN
{ return ioctl(fd, VIDIOCSWIN, &win); }

int Video4LinuxSource::set_videoSource(int chan)
/// ioctl wrapper for VIDIOCSCHAN
{ return ioctl(fd, VIDIOCSCHAN, chan); }

int Video4LinuxSource::set_imageProperties(video_picture& pic)
/// ioctl wrapper for VIDIOCSPICT
{ return ioctl(fd, VIDIOCSPICT, &pic); }

int Video4LinuxSource::set_tuning(video_tuner& tuner)
/// ioctl wrapper for VIDIOCSTUNER
{ return ioctl(fd, VIDIOCSTUNER, &tuner); }


/* get ioctl methods */

int Video4LinuxSource::get_capability(video_capability& cap)
/// ioctl wrapper for VIDIOCGCAP
{ return ioctl(fd, VIDIOCGCAP, &cap); }

int Video4LinuxSource::get_frameBuffer(video_buffer& fbuf)
/// ioctl wrapper for VIDIOCGFBUF
{ return ioctl(fd, VIDIOCGFBUF, &fbuf); }

int Video4LinuxSource::get_captureWindows(video_window& win)
/// ioctl wrapper for VIDIOCGWIN
{ return ioctl(fd, VIDIOCGWIN, &win); }

int Video4LinuxSource::get_videoSource(video_channel& chan)
/// ioctl wrapper for VIDIOCGCHAN
{ return ioctl(fd, VIDIOCGCHAN, &chan); }

int Video4LinuxSource::get_imageProperties(video_picture& pic)
/// ioctl wrapper for VIDIOCGPICT
{ return ioctl(fd, VIDIOCGPICT, &pic); }

int Video4LinuxSource::get_tuning(video_tuner& tuner)
/// ioctl wrapper for VIDIOCGTUNER
{ return ioctl(fd, VIDIOCGTUNER, &tuner); }

int Video4LinuxSource::get_memoryBuffer(video_mbuf& mbuf)
/// ioctl wrapper for VIDIOCGMBUF
{ return ioctl(fd, VIDIOCGMBUF, &mbuf); }


/* print methods for ioctl structs */

void Video4LinuxSource::print_capability(video_capability& cap)
{
	cerr << "name: " << cap.name << endl;
	
	cerr << " [ can capture to memory:\t\t\t| " 
	     << ((cap.type & VID_TYPE_CAPTURE)?    "X" : " ") << " ]" << endl;
	cerr << " [ has a tuner of some form:\t\t\t| " 
	     << ((cap.type & VID_TYPE_TUNER)?      "X" : " ") << " ]" << endl;
	cerr << " [ has teletext capability:\t\t\t| " 
	     << ((cap.type & VID_TYPE_TELETEXT)?   "X" : " ") << " ]" << endl;
	cerr << " [ can overlay images onto frame buffer:\t| " 
	     << ((cap.type & VID_TYPE_OVERLAY)?    "X" : " ") << " ]" << endl;
	cerr << " [ overlay is chromakeyed:\t\t\t| " 
	     << ((cap.type & VID_TYPE_CHROMAKEY)?  "X" : " ") << " ]" << endl;
	cerr << " [ overlay clipping is supported:\t\t| " 
	     << ((cap.type & VID_TYPE_CLIPPING)?   "X" : " ") << " ]" << endl;
	cerr << " [ overlay overwrites frame buffer memory:\t| " 
	     << ((cap.type & VID_TYPE_FRAMERAM)?   "X" : " ") << " ]" << endl;
	cerr << " [ hardware supports image scaling:\t\t| " 
	     << ((cap.type & VID_TYPE_SCALES)?     "X" : " ") << " ]" << endl;
	cerr << " [ image capture is greyscale only:\t\t| " 
	     << ((cap.type & VID_TYPE_MONOCHROME)? "X" : " ") << " ]" << endl;
	cerr << " [ capture can be of only part of the image:\t| " 
	     << ((cap.type & VID_TYPE_SUBCAPTURE)? "X" : " ") << " ]" << endl;

	cerr << "channels: "  << cap.channels  << endl;
	cerr << "audios: "    << cap.channels  << endl;
	cerr << "maxwidth: "  << cap.maxwidth  << endl;
	cerr << "maxheight: " << cap.maxheight << endl;
	cerr << "minwidth: "  << cap.minwidth  << endl;
	cerr << "minheight: " << cap.minheight << endl;
}


void Video4LinuxSource::print_captureWindows(video_window& win)
{
	cerr << "x co-ord: "  << win.x         << endl;
	cerr << "y co-ord: "  << win.y         << endl;
	cerr << "width: "     << win.width     << endl;
	cerr << "height: "    << win.height    << endl;
	cerr << "chromakey: " << win.chromakey << endl;
	__u32 mask = 0x1 << sizeof(mask)*8 - 1;
	cerr << "flags: ";
		for (unsigned int b = 0; b < sizeof(mask)*8; b++, mask >>= 1)
			cerr << (win.flags & mask ? "1" : "0");
	cerr << endl;
}


void Video4LinuxSource::print_videoSource(video_channel& chan)
{
	cerr << "number: " << chan.channel << endl;
	cerr << "name: "   << chan.name    << endl;
	cerr << "tuners: " << chan.tuners  << endl;
	cerr << "flags: "  << endl;
	cerr << " [ channel has tuners:\t\t\t| " 
	     << ((chan.flags & VIDEO_VC_TUNER)? "X" : " ") << " ]" << endl;
	cerr << " [ channel has audio:\t\t\t| " 
	     << ((chan.flags & VIDEO_VC_AUDIO)? "X" : " ") << " ]" << endl;
// XXX not in header
//	cerr << " [ channel has norm setting:\t\t| " 
//	     << ((chan.flags & VIDEO_VC_NORM)? "X" : " ") << " ]" << endl;
	cerr << "type: "   << endl;
	cerr << " [ input is a tv input:\t\t\t| " 
	     << ((chan.flags & VIDEO_TYPE_TV)? "X" : " ") << " ]" << endl;
	cerr << " [ input is a camera:\t\t\t| " 
	     << ((chan.flags & VIDEO_TYPE_CAMERA)? "X" : " ") << " ]" << endl;
	cerr << "norm: "   << chan.norm << endl;
}


void Video4LinuxSource::print_memoryBuffer(video_mbuf& mbuf)
{
	cerr << "size: "   << mbuf.size       << endl;
	cerr << "frames: " << mbuf.frames     << endl;
	cerr << "offset: " << mbuf.offsets[1] << endl;
}

