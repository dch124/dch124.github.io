/** @file RandomSource.h 
 * 
 * Header file for the class 'RandomSource'. 
 *
 * The source code for this class can be found in RandomSource.cpp
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage) 
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/
 
#ifndef RANDOM_SOURCE_H
#define RANDOM_SOURCE_H

#include "ImageSource.h"
#include "Image.h"


class RandomSource : public ImageSource
/**
 * A class which implements the ImageSource interface as a source
 * of Randomly generated Images.
 *
 * Each image that is extracted from the RandomSource class is 
 * a plain one colour image whose colour values are calculated
 * at random when an Image is called to be extracted.
 *
 * The images will be created at a rate specified to the constructor
 * when an instance of this class is created.
 */
{
private:
/* Private Members */
	
	unsigned int	sleeptime;	///< Time between frames.

public:
	/// Create an source of Random Images
	RandomSource(unsigned int w, unsigned int h, unsigned int fps);
		
	/* Extraction operators */
	
	virtual	ImageSource& operator >> (ImageRGB&);
	virtual	ImageSource& operator >> (ImageGrey&);
	virtual	ImageSource& operator >> (Image&);
		
	// Update the specified colour image with a random colour.
	void update(ImageRGB&);

	// Update the specified greyscale image with a random grey value;
        void update(ImageGrey&);
};


#endif	// RANDOM_SOURCE_H
