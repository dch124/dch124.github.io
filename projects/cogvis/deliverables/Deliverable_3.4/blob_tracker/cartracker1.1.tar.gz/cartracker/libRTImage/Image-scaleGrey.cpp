#include "Image.h"
#include <math.h>

void ImageGrey::scale_down(unsigned int min_x,
                       unsigned int min_y,
                       unsigned int max_x,
                       unsigned int max_y,
                       unsigned int new_sx,
                       unsigned int new_sy,
                       float        *new_image)
{
/** 
 * Scales a section of the image (min_x,min_y -> max_x,max_y) to a new buffer
 * (new_image) of size new_sx*new_sy
 * Scales by calculating the centre of scaled down point in original frame of 
 * reference and using a gaussian window 
**/
    unsigned int cnt_x ;
    unsigned int cnt_y ;
    unsigned int cnt_x2 ;
    unsigned int cnt_y2 ;
    unsigned int x_range ;
    unsigned int y_range ;
    int          x_start ;
    unsigned int x_end ;
    int          y_start ;
    unsigned int y_end ;
    float        x_div ;
    float        y_div ;
    float        *out_ptr ;
    float        x_cent ;
    float        y_cent ;
    float        tot_w ;
    float        dx ;
    float        dy ;
    float        x_sd ;
    float        y_sd ;
    float        x_var ;
    float        y_var ;
    float        w ;
    float        denom ;

    out_ptr = new_image ;
    x_range = max_x - min_x + 1 ;
    y_range = max_y - min_y + 1 ;
    x_div = (float)x_range / (float)new_sx ; 
    y_div = (float)y_range / (float)new_sy ; 
    x_sd = x_div / 2.0 ;
    y_sd = y_div / 2.0 ;
    x_var = x_sd*x_sd ;
    y_var = y_sd*y_sd ;

    denom = 2*M_PI * sqrt(x_var*y_var) ;

    y_cent = y_sd ;
    for(cnt_y=0 ; cnt_y<new_sy ; cnt_y++, y_cent+=y_div){
        x_cent = x_sd ;
        for(cnt_x=0 ; cnt_x<new_sx ; cnt_x++, out_ptr++,x_cent+=x_div){
        // Loop through all output values

            *out_ptr = 0 ;
            tot_w = 0 ;
            x_start = (int)(x_cent - 2*x_sd) ;
            if(x_start<0) x_start = 0 ;
            x_end = (unsigned int)(x_cent + 2*x_sd + 0.5) ;
            if(x_end>x_range-1) x_end = x_range-1 ;

            y_start = (int)(y_cent - 2*y_sd) ;
            if(y_start<0) y_start = 0 ;
            y_end = (unsigned int)(y_cent + 2*y_sd + 0.5) ;
            if(y_end>y_range-1) y_end = y_range-1 ;


            for(cnt_y2=y_start ; cnt_y2<=y_end ; cnt_y2++){
                for(cnt_x2=x_start ; cnt_x2<=x_end ; cnt_x2++){
                // Loop through image area to be scaled down
                // (For a more efficient implementation limit the range - 
                // now done!)

                    // Calculate dist from x_cent,y_cent
                    dx = x_cent - (float)cnt_x2 ;
                    dx *= dx / x_var ;
                    dy = y_cent - (float)cnt_y2 ;
                    dy *= dy / y_var ;
                    w = exp(-0.5*(dx+dy)) / denom ;
                    tot_w += w ;
                    *out_ptr += brightness[cnt_x2+min_x +
                                             (cnt_y2+min_y) * width] *
                                w ;
                }
            }
            *out_ptr /= tot_w ;
        }
    }
}

void ImageGrey::scale_down(unsigned int min_x,
                       unsigned int min_y,
                       unsigned int max_x,
                       unsigned int max_y,
                       unsigned int new_sx,
                       unsigned int new_sy,
                       double       *new_image)
{
/**
 * Scales a section of the image (min_x,min_y -> max_x,max_y) to a new buffer
 * (new_image) of size new_sx*new_sy
 * Scales by calculating the centre of scaled down point in original frame of
 * reference and using a gaussian window
**/
    unsigned int cnt_x ;
    unsigned int cnt_y ;
    unsigned int cnt_x2 ;
    unsigned int cnt_y2 ;
    unsigned int x_range ;
    unsigned int y_range ;
    int          x_start ;
    unsigned int x_end ;
    int          y_start ;
    unsigned int y_end ;
    double       x_div ;
    double       y_div ;
    double       *out_ptr ;
    double       x_cent ;
    double       y_cent ;
    double       tot_w ;
    double       dx ;
    double       dy ;
    double       x_sd ;
    double       y_sd ;
    double       x_var ;
    double       y_var ;
    double       w ;
    double       denom ;

    out_ptr = new_image ;
    x_range = max_x - min_x + 1 ;
    y_range = max_y - min_y + 1 ;
    x_div = (double)x_range / (double)new_sx ;
    y_div = (double)y_range / (double)new_sy ;
    x_sd = x_div / 2.0 ;
    y_sd = y_div / 2.0 ;
    x_var = x_sd*x_sd ;
    y_var = y_sd*y_sd ;


    denom = 2*M_PI * sqrt(x_var*y_var) ;

    y_cent = y_sd ;
    for(cnt_y=0 ; cnt_y<new_sy ; cnt_y++, y_cent+=y_div){
        x_cent = x_sd ;
        for(cnt_x=0 ; cnt_x<new_sx ; cnt_x++, out_ptr++,x_cent+=x_div){
        // Loop through all output values

            *out_ptr = 0 ;
            tot_w = 0 ;
            x_start = (int)(x_cent - 2*x_sd) ;
            if(x_start<0) x_start = 0 ;
            x_end = (unsigned int)(x_cent + 2*x_sd + 0.5) ;
            if(x_end>x_range-1) x_end = x_range-1 ;

            y_start = (int)(y_cent - 2*y_sd) ;
            if(y_start<0) y_start = 0 ;
            y_end = (unsigned int)(y_cent + 2*y_sd + 0.5) ;
            if(y_end>y_range-1) y_end = y_range-1 ;


            for(cnt_y2=y_start ; cnt_y2<=y_end ; cnt_y2++){
                for(cnt_x2=x_start ; cnt_x2<=x_end ; cnt_x2++){
                // Loop through image area to be scaled down
                // (For a more efficient implementation limit the range -
                // now done!)

                    // Calculate dist from x_cent,y_cent
                    dx = x_cent - (double)cnt_x2 ;
                    dx *= dx / x_var ;
                    dy = y_cent - (double)cnt_y2 ;
                    dy *= dy / y_var ;
                    w = exp(-0.5*(dx+dy)) / denom ;
                    tot_w += w ;
                    *out_ptr += brightness[cnt_x2+min_x +
                                             (cnt_y2+min_y) * width] *
                                w ;
                }
            }
            *out_ptr /= tot_w ;
        }
    }
}

void ImageGrey::quick_scale_down(unsigned int min_x,
                       unsigned int min_y,
                       unsigned int max_x,
                       unsigned int max_y,
                       unsigned int new_sx,
                       unsigned int new_sy,
                       double       *new_image)
{
    unsigned int cnt_x ;
    unsigned int cnt_y ;
    double       *out_ptr = new_image;
    double       dx ;
    double       dy ;

    dx = (max_x - min_x)/ (double) new_sx ;
    dy = (max_y - min_y)/ (double) new_sy ;
    
    for(cnt_y=0 ; cnt_y<new_sy ; cnt_y++){
        for(cnt_x=0 ; cnt_x<new_sx ; cnt_x++, out_ptr++){
            *out_ptr = brightness[(int)(min_x - 0.5 + cnt_x*dx) +
				      ((int)(min_y - 0.5 + cnt_y*dy))*width];
        }
    }
}


