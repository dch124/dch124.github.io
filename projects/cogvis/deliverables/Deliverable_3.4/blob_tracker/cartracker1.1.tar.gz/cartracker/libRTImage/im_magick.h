/** @file m_magick.h
 *
 * Header file for Image Magic C interface code.
 *
 * The source code can be found in im_magick.cpp 
 *
 *//*************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified
 * and distributed within the University of Leeds subject to the following
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the authors where
 *   appropriate (including demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#ifndef IM_MAGICK_H
#define IM_MAGICK_H

void* im_load(char *filename, unsigned int &w, unsigned int &h) ;
void im_get_data(void *image, int *rgb) ;
void im_get_data_grey(void *image, int *d) ;
void im_free(void *img) ;

#endif
