/** @file ImageGrey.cpp
 *
 * File containing methods for the 'ImageGrey' class.
 *
 * The header for this class can be found in ImageGrey.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following 
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#include <new>		// bad_alloc exception
#include <string.h>	// memcpy
#include <MicrosoftBMP_RT.h>
#include <math.h>
 
#include "ImageGrey.h"


ImageGrey::ImageGrey(ImageGrey& img) : ImageBase(img)
/**
 * Initialise to a new greyscale image identical to the specified image
 *
 * @param img The image to copy
 */
{
	unsigned int array_size = img.width * img.height;
	brightness = new PixelGrey[array_size];

	*this = img;
}


ImageGrey::ImageGrey(unsigned int w, unsigned int h) : ImageBase(w,h)
/**
 * Allocates an array of size width*height for storage of brightness. 
 *
 * @param w The width  of the image.
 * @param h The height of the image.
 */
{
	unsigned int array_size = width * height;
	brightness = new PixelGrey[array_size];

//	clear();
}

ImageGrey::ImageGrey(ImageGrey&    img,
                     unsigned int min_x,
                     unsigned int min_y,
                     unsigned int max_x,
                     unsigned int max_y) : 
                                        ImageBase(max_x-min_x+1, max_y-min_y+1)
/**
 * Initialise to a new Image and copy over an area of img.
 * @param img The Image to copy
 * @param min_x Minimum extent of block to copy (X)
 * @param min_y Minimum extent of block to copy (Y)
 * @param max_x Maximum extent of block to copy (X)
 * @param max_y Maximum extent of block to copy (Y)
 */
{
        brightness = new int[width*height];
        copy(img, min_x, min_y, max_x, max_y, 0, 0) ;
}


ImageGrey::~ImageGrey()
/**
 * Destructor for ImageGrey class. Frees memory allocated to array:
 */
{
    delete [] brightness;
}


void ImageGrey::set_pixel(unsigned int x, unsigned int y, PixelGrey level)
/**
 * Method sets the brighness of a pixel specified by (x,y).
 * Throws an exception if coordinates are not valid.
 *
 * @param x,y   The coordinates of the pixel
 * @param level The brightness of the pixel
 */
{
	// Check that co-ords are valid. 
	if (x > width || y > height)
		throw "Invalid Coordinates in method set_rgb";

	unsigned int offset = y * width + x;
	brightness[offset]  = level;
}


void ImageGrey::get_pixel(unsigned int x, unsigned int y, PixelGrey& p)
/**
 * Method to return the brightness for pixel (x,y). 
 * \note No check is made that x and y are in range.
 *
 * @param x,y The coordinates of the pixel.
 * @param p   Reference to the Pixel to store the pixels value in.
 */
{
	p = brightness[y * width + x];
}



ImageGrey& ImageGrey::clear(int k)
/**
 * Method sets the value of the brightness field to the specified intensity. 
 *
 * @param k Value to clear the field to.
 */
{
	int *start = brightness;
	int *end   = start + width * height;
		
	for (int *d = start; d < end; d++) *d = k;

	return *this;
}


ImageGrey& ImageGrey::copy(ImageGrey& img)
/**
 * Copies all pixel brightness to img.
 * Throws an exception if images are of different size.
 *
 * @param img The image to copy the brightness from.
 */
{	
	/* check we're not trying to copy ourself */
	if (this == &img)
		throw "Source and Destination are same Image";
	
	/* First check images are the same size and valid */
	if (width  != img.width || height != img.height) 
		throw "Difference in image dimensions";	
	
	/* Perform copy */
	memcpy(brightness, img.brightness, width * height * sizeof(int));

	return *this;
}

ImageGrey& ImageGrey::copy(ImageGrey&    img,
                           unsigned int min_x,
                           unsigned int min_y,
                           unsigned int max_x,
                           unsigned int max_y,
                           unsigned int start_x,
                           unsigned int start_y)
/**
 * Copies block of pixel data from img.
 * Throws an exception if img is of incorrect size.
 *
 * @param img The image to copy the data from.
 * @param min_x Minimum extent of block to copy (X)
 * @param min_y Minimum extent of block to copy (Y)
 * @param max_x Maximum extent of block to copy (X)
 * @param max_y Maximum extent of block to copy (Y)
 * @param start_x Start location (top left) for destination (X)
 * @param start_y Start location (top left) for destination (Y)
 */
{
        unsigned int sx ;
        unsigned int sy ;
        unsigned int cntx ;
        unsigned int cnty ;
        int          *s_ptr ;
        int          *d_ptr ;
        unsigned int s_width ;

        s_width = img.get_width() ;

        /* check we're not trying to copy ourself */
        if (this == &img)
                throw "Source and Destination are same Image";

        /* check sanity */
        if(min_x > max_x || min_y > max_y)
                throw "Invalid arguments to ImageRGB::copy()" ;

        /* Check images are big enough */
        sx = max_x - min_x + 1 ;
        sy = max_y - min_y + 1 ;

        if(sx+start_x > width ||
           sy+start_y > height)
                throw "Dest. image is not big enough" ;

         if(max_x > s_width ||
            max_y > img.get_height() )
                throw "Source images is not big enough" ;

         for(cnty=0 ; cnty<sy ; cnty++){

                 s_ptr = (int*)img.brightness + (min_x + (min_y+cnty)*s_width) ;
                 d_ptr = (int*)brightness + (start_x + (start_y+cnty)*width) ;

                 for(cntx=0 ; cntx<sx ; cntx++){
                                     
                         *(d_ptr++) = *(s_ptr++) ;
                 }
         }

         return *this;
}


ImageGrey& ImageGrey::operator -= (ImageGrey& img) 
/**
 * Subtracts img.brightness from brightness array
 *
 * @param img The image to be subtracted
 */
{
    unsigned int cnt ;
    unsigned int sz ;
    int          *p1 ;
    int          *p2 ;

    sz = width * height ;
    p1 = brightness ;
    p2 = img.brightness ;

    for(cnt=0 ; cnt<sz ; cnt++, p1++, p2++){
        *p1 -= *p2 ;
    } 

    return *this;
}

void ImageGrey::absolute()
/**
 * Calculates absolute values of brightness array 
 *
 */
{
    unsigned int cnt ; 
    unsigned int sz ;
    int          *p1 ;

    p1 = brightness ;
    sz = width * height ;

    for(cnt=0 ; cnt<sz ; cnt++, p1++){
        if(*p1<0) *p1 = -(*p1) ;
    }

    return ;
}

void ImageGrey::threshold(int thresh)
/**
 * Sets values below threshold to zero and those equal or above to 255 
 *
 * @param thresh Threshold value
 */
{
    unsigned int cnt ;
    unsigned int sz ;
    int          *p1 ;

    p1 = brightness ;
    sz = width * height ;

    for(cnt=0 ; cnt<sz ; cnt++, p1++){
        if(*p1<thresh) *p1 = 0 ;
        else           *p1 = 255 ;
    }

    return ;
}

bool ImageGrey::save(char *filename, FileFormat format)
/**
 * Saves data to a graphics file
 *
 * @param filename filname of the file to be created
 * @param format format of file to be created 
 */
{
 
    bool            ret_val = true ;
    MicrosoftBMP_RT *btmp;

    if(format == FORMAT_BMP_24){
    // 24 Bit (full colour) bitmap
        btmp = new MicrosoftBMP_RT(filename);
        if(btmp==NULL) ret_val = false ;
        else if(!btmp->set_size(width,height)) ret_val = false ;
        else{
            btmp->put_data_grey((int *)brightness) ;
            ret_val = btmp->write();
        }
	delete btmp ;
    }
    
    return ret_val ;
}

bool ImageGrey::sobel_horizontal(ImageGrey &result)
/**
 * Performs a horizontal sobel edge detection.
 * N.B. Result is normalised by dividing by 8
 *
 * @param result ImageGrey object that result is to be stored in.
 */
{
    bool     ret_val = true ;
    int      *ob_ptr ;
    int      *rs_ptr ;
    int      *tl_ptr ;
    int      *tr_ptr ;
    int      *b_ptr ;
    int      *t_ptr ;
    int      *bl_ptr ;
    int      *br_ptr ;
    unsigned int cnt_x ;
    unsigned int cnt_y ;
    register int pix_val ;

    if(result.get_width() != width   ||
       result.get_height() != height ){
        ret_val = false ;
    }
    else{
        ob_ptr = brightness ;
        rs_ptr = result.brightness ;
        tl_ptr = ob_ptr - width - 1 ;
        tr_ptr = ob_ptr - width + 1 ;
        t_ptr  = ob_ptr - width ;
        b_ptr  = ob_ptr + width ;
        bl_ptr = ob_ptr + width - 1 ;
        br_ptr = ob_ptr + width + 1 ;
        for(cnt_y=0 ; cnt_y<height ; cnt_y++){
            for(cnt_x=0 ; cnt_x<width ; cnt_x++, ob_ptr++, rs_ptr++, tl_ptr++,
                tr_ptr++,b_ptr++,t_ptr++,bl_ptr++,br_ptr++){
                if(cnt_y>0 &&
                   cnt_x>0 &&
                   cnt_y<height-1 &&
                   cnt_x<width-1 ){
                    pix_val = -1 * (*tl_ptr) +
                              -2 * (*t_ptr)  +
                              -1 * (*tr_ptr) +
                               1 * (*bl_ptr) +
                               2 * (*b_ptr)  +
                               1 * (*br_ptr)  ;
                    *rs_ptr = pix_val / 8 ;
                }
                else{
                    *rs_ptr = 0 ;
                }
            }
        }
    }

    return ret_val ;
 
}

bool ImageGrey::sobel_vertical(ImageGrey &result)
/**
 * Performs a vertical sobel edge detection.
 * N.B. Result is normalised by dividing by 8
 *
 * @param result ImageGrey object that result is to be stored in.
 */
{
    bool     ret_val = true ;
    int      *ob_ptr ;
    int      *rs_ptr ;
    int      *tl_ptr ;
    int      *tr_ptr ;
    int      *l_ptr ;
    int      *r_ptr ;
    int      *bl_ptr ;
    int      *br_ptr ;
    unsigned int cnt_x ;
    unsigned int cnt_y ;
    register int pix_val ;

    if(result.get_width() != width   ||
       result.get_height() != height ){
        ret_val = false ;
    }
    else{
        ob_ptr = brightness ;
        rs_ptr = result.brightness ;
        l_ptr = ob_ptr - 1 ;
        r_ptr = ob_ptr + 1 ;
        tl_ptr = ob_ptr - width - 1 ;
        tr_ptr = ob_ptr - width + 1 ;
        bl_ptr = ob_ptr + width - 1 ;
        br_ptr = ob_ptr + width + 1 ;
        for(cnt_y=0 ; cnt_y<height ; cnt_y++){
            for(cnt_x=0 ; cnt_x<width ; cnt_x++, ob_ptr++, rs_ptr++, tl_ptr++,
                tr_ptr++,l_ptr++,r_ptr++,bl_ptr++,br_ptr++){
               if(cnt_y>0 &&
                   cnt_x>0 &&
                   cnt_y<height-1 &&
                   cnt_x<width-1 ){

                    pix_val = -1 * *tl_ptr +
                              -2 * *l_ptr  +
                              -1 * *bl_ptr +
                               1 * *tr_ptr +
                               2 * *r_ptr  +
                               1 * *br_ptr ;
                    *rs_ptr = pix_val / 8 ;
                }
                else{
                    *rs_ptr = 0 ;
                }
            }
        }
    }

    return ret_val ;
}

bool ImageGrey::sobel(ImageGrey &result)
/**
 * Performs a sobel (horizontal and vertical) edge detection.
 * N.B. Result is normalised by dividing horizontal + vertical outputs by 8
 *
 * @param result ImageGrey object that result is to be stored in.
 */
{
    bool     ret_val = true ;
    int      *ob_ptr ;
    int      *rs_ptr ;
    int      *tl_ptr ;
    int      *tr_ptr ;
    int      *l_ptr ;
    int      *r_ptr ;
    int      *t_ptr ;
    int      *b_ptr ;
    int      *bl_ptr ;
    int      *br_ptr ;
    unsigned int cnt_x ;
    unsigned int cnt_y ;
    register int pix_val_h ;
    register int pix_val_v ;

    if(result.get_width() != width   ||
       result.get_height() != height ){
        ret_val = false ;
    }
    else{
        ob_ptr = brightness ;
        rs_ptr = result.brightness ;
        l_ptr = ob_ptr - 1 ;
        r_ptr = ob_ptr + 1 ;
        t_ptr  = ob_ptr - width ;
        b_ptr  = ob_ptr + width ;
        tl_ptr = ob_ptr - width - 1 ;
        tr_ptr = ob_ptr - width + 1 ;
        bl_ptr = ob_ptr + width - 1 ;
        br_ptr = ob_ptr + width + 1 ;
        for(cnt_y=0 ; cnt_y<height ; cnt_y++){
            for(cnt_x=0 ; cnt_x<width ; cnt_x++, ob_ptr++, rs_ptr++, tl_ptr++,
                tr_ptr++,l_ptr++,r_ptr++,bl_ptr++,br_ptr++, t_ptr++, b_ptr++){
               if(cnt_y>0 &&
                   cnt_x>0 &&
                   cnt_y<height-1 &&
                   cnt_x<width-1 ){

                    pix_val_h = -1 * (*tl_ptr) +
                                -2 * (*t_ptr)  +
                                -1 * (*tr_ptr) +
                                 1 * (*bl_ptr) +
                                 2 * (*b_ptr)  +
                                 1 * (*br_ptr)  ;

                    pix_val_v = -1 * *tl_ptr +
                                -2 * *l_ptr  +
                                -1 * *bl_ptr +
                                 1 * *tr_ptr +
                                 2 * *r_ptr  +
                                 1 * *br_ptr ;

                    *rs_ptr = (int)sqrt(pix_val_h*pix_val_h + 
                                        pix_val_v*pix_val_v) ;
                }
                else{
                    *rs_ptr = 0 ;
                }
            }
        }
    }

    return ret_val ;
}

