/** @file ImageRGB.cpp
 *
 * File containing methods for the 'ImageRGB' class.
 *
 * The header for this class can be found in ImageRGB.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following 
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#include <new>		// bad_alloc exception
#include <string.h>	// memcpy
#include <MicrosoftBMP_RT.h>
 
#include "ImageRGB.h"


ImageRGB::ImageRGB(ImageRGB& img) : ImageBase(img)
/**
 * Initialise to a new RGBImage identical to the specified image
 *
 * @param img The RGBImage to copy
 */
{
	unsigned int array_size = img.width * img.height;
	data = new PixelRGB[array_size];

	*this = img;
}

ImageRGB::ImageRGB(ImageRGB&    img,  
                   unsigned int min_x,
                   unsigned int min_y,
                   unsigned int max_x,
                   unsigned int max_y) : ImageBase(max_x-min_x+1, max_y-min_y+1)
/**
 * Initialise to a new RGBImage and copy over an area of img.
 * @param img The RGBImage to copy
 * @param min_x Minimum extent of block to copy (X)
 * @param min_y Minimum extent of block to copy (Y)
 * @param max_x Maximum extent of block to copy (X)
 * @param max_y Maximum extent of block to copy (Y)
 */
{
        data = new PixelRGB[width*height];
        copy(img, min_x, min_y, max_x, max_y, 0, 0) ;
}

ImageRGB::ImageRGB(unsigned int w, unsigned int h) : ImageBase(w,h)
/**
 * Allocates an array of size width*height for storage of red, green and
 * blue data. 
 * Sets the parameters Width and Height to the inputs width and height.
 *
 * @param w The Width  of the image.
 * @param h The Height of the image.
 */
{
	unsigned int array_size = width * height;
	data = new PixelRGB[array_size];

//	clear();
}

ImageRGB::ImageRGB(char *filename, FileFormat format)
/**
 * Allocates an array of size taken from file for storage of red, green and
 * blue data and fills it with data taken from file.
 * Sets the parameters Width and Height to the inputs width and height.
 *
 * @param filename The name of the image file.
 * @param FileFormat The format of the image file.
 */
{

    if(format == FORMAT_BMP_24){
        MicrosoftBMP_RT bmp(filename) ;

        if(!bmp.read()) throw("Invalid Bitmap file specified") ;

        width = bmp.ImageWidth ;
        height = bmp.ImageHeight ;

        data = new PixelRGB[width*height] ;

        bmp.extract_data((int *)data) ;
    }

}

ImageRGB::~ImageRGB()
/**
 * Destructor for ImageRGB class. Frees memory allocated to array:
 */
{
    delete data;
}


void ImageRGB::set_pixel(unsigned int x, unsigned int y, PixelRGB p)
/**
 * Method sets the pixel at (x,y) from the Pixel specified.
 *
 * @param x,y The coordinates of the pixel
 * @param p   The Pixel with values red, green and blue
 */
{
	// Check that co-ords are valid. 
	if (x > width || y > height)
		throw "Invalid Coordinates in method set_rgb";
	
	data[y * width + x] = p;
}


void ImageRGB::set_rgb(unsigned int x, unsigned int y, 
		    int red, int green, int blue)
/**
 * Method sets the red, green and blue values of a pixel specified by (x,y).
 * Throws an exception if coordinates are not valid.
 *
 * @param x,y   The coordinates of the pixel
 * @param red   The value of the RED field
 * @param green The value of the GREEN field
 * @param blue  The value of the BLUE field
 */
{
	// Check that co-ords are valid. 
	if (x > width || y > height)
		throw "Invalid Coordinates in method set_rgb";
	
	unsigned int offset = y * width + x; 

	data[offset][RED]   = red;
	data[offset][GREEN] = green;
	data[offset][BLUE]  = blue;
}


void ImageRGB::set_field(unsigned int x, unsigned int y, 
		      FieldSelector fs, int value)
/**
 * Method sets the selected fields value of a pixel specified by (x,y).
 * Throws an exception if coordinates are not valid.
 *
 * @param x,y   The coordinates of the pixel.
 * @param fs    The selected Field.
 * @param value The value to set the field to.
 */
{
	// Check that co-ords are valid.
	if (x > width || y > height)
		throw "Invalid Coordinates in method set_field";

	unsigned int offset = y * width + x;
	data[offset][fs] = value;   
}


void ImageRGB::get_pixel(unsigned int x, unsigned int y, PixelRGB& p)
/**
 * Method to return values for pixel (x,y) in RGB Pixel p. 
 *
 * @note No check is made that x and y are in range.
 *
 * @param x,y The coordinates of the pixel.
 * @param p   A Reference to the pixel to store the values in.
 */
{
	unsigned int offset = y * width + x;

	p[ RED ] = data[offset][RED];
	p[GREEN] = data[offset][GREEN];
	p[ BLUE] = data[offset][BLUE];
}


int ImageRGB::get_field(unsigned int x, unsigned int y, FieldSelector fs)
/**
 * Method to return slected fields value for pixel (x,y). 
 * \note No check is made that x and y are in range.
 * 
 * @param x,y The coordinates of the pixel.
 * 
 * @return The selected fields value.
 */
{
	unsigned int offset = y * width + x;
	return data[offset][fs];
}


ImageRGB& ImageRGB::clear(int k)
/**
 * Method sets values of all three colour fields to the specified colour.
 *
 * @param k Value to clear the field to.
 */
{
	int *start = data[0];
	int *end   = start + width * height * 3;
		
	for (int *d = start; d < end; d++) *d = k;

	return *this;
}


ImageRGB& ImageRGB::clear(PixelRGB& p)
/**
 * Method sets all pixels to the specified pixel.
 *
 * @param p Pixel to set to.
 */
{
	int *start = data[0];
	int *end   = start + width * height * 3;
		
	for (int *d = start; d < end; d += 3) {
		d[ RED ] = p[ RED ];
		d[GREEN] = p[GREEN];
		d[ BLUE] = p[ BLUE];
	}
	
	return *this;
}


ImageRGB& ImageRGB::clear_field(FieldSelector fs, int k)
/**
 * Method sets all pixels of currently selected field to specified colour
 *
 * @param k  Value to clear the field to.
 * @param fs The field so clear, one of (RED, GREEN, BLUE).
 */
{
	int *start = data[0];
	int *end   = start + width * height * 3;
		
	for (int *d = start + fs; d < end; d += 3) *d = k;
	
	return *this;
}
    

ImageRGB& ImageRGB::copy(ImageRGB& img)
/**
 * Copies all pixel data from img.
 * Throws an exception if images are of different size.
 *
 * @param img The image to copy the data from.
 */
{
	/* check we're not trying to copy ourself */
	if (this == &img)
		throw "Source and Destination are same Image";
	
	/* First check images are the same size and valid */
	if (width != img.width || height != img.height) 
		throw "Difference in ImageRGB Dimensions";	
	
	/* Perform copy */
	memcpy(data, img.data, width * height * 3 * sizeof(int));

	return *this;
}

ImageRGB& ImageRGB::copy(ImageRGB&    img,
                         unsigned int min_x,
                         unsigned int min_y,
                         unsigned int max_x, 
                         unsigned int max_y,
                         unsigned int start_x,
                         unsigned int start_y)
/**
 * Copies block of pixel data from img.
 * Throws an exception if img is of incorrect size.
 *
 * @param img The image to copy the data from.
 * @param min_x Minimum extent of block to copy (X)
 * @param min_y Minimum extent of block to copy (Y)
 * @param max_x Maximum extent of block to copy (X)
 * @param max_y Maximum extent of block to copy (Y)
 * @param start_x Start location (top left) for destination (X)
 * @param start_y Start location (top left) for destination (Y)
 */
{
        unsigned int sx ;
        unsigned int sy ;
        unsigned int cntx ;
        unsigned int cnty ;
        int          *s_ptr ;
        int          *d_ptr ;
        unsigned int s_width ;

        s_width = img.get_width() ;

        /* check we're not trying to copy ourself */
        if (this == &img)
                throw "Source and Destination are same Image";

        /* check sanity */
        if(min_x > max_x || min_y > max_y)
                throw "Invalid arguments to ImageRGB::copy()" ;

        /* Check images are big enough */
        sx = max_x - min_x + 1 ;
        sy = max_y - min_y + 1 ;

        if(sx+start_x > width || 
           sy+start_y > height)
                throw "Dest. image is not big enough" ;

         if(max_x > s_width ||
            max_y > img.get_height() )
                throw "Source images is not big enough" ;

         for(cnty=0 ; cnty<sy ; cnty++){

                 s_ptr = (int*)img.data + (min_x + (min_y+cnty)*s_width)*3 ;
                 d_ptr = (int*)data + (start_x + (start_y+cnty)*width)*3 ;

                 for(cntx=0 ; cntx<sx ; cntx++){ 

                         *(d_ptr++) = *(s_ptr++) ;
                         *(d_ptr++) = *(s_ptr++) ;
                         *(d_ptr++) = *(s_ptr++) ;
                 }
         }

         return *this; 
}

bool ImageRGB::save(char *filename, FileFormat format)
/**
 * Saves data to a graphics file
 *
 * @param filename filname of the file to be created
 * @param format format of file to be created 
 */
{
 
    bool            ret_val = true ;
    MicrosoftBMP_RT *btmp;

    if(format == FORMAT_BMP_24){
    // 24 Bit (full colour) bitmap
        btmp = new MicrosoftBMP_RT(filename);
        if(btmp==NULL) ret_val = false ;
        else if(!btmp->set_size(width,height)) ret_val = false ;
        else{
            btmp->put_data((int *)data) ;
            ret_val = btmp->write();
        }
	delete btmp ;
    }
    
    return ret_val ;
}

bool ImageRGB::enhance_contrast()
/**
 * Enhances contrast in image by stretching RGB to full range using a linear
 * multiplier.
 */
{
    unsigned int cnt ;
    int          max_val = 0 ;
    int          *ptr ;
    float        fact ;

    ptr = (int*)data ; 
    for(cnt=0 ; cnt<width*height*3 ; cnt++, ptr++){
        if(*ptr > max_val) max_val = *ptr ;
    }
   
    fact = 255.0 / (float)max_val ;

    ptr = (int*)data ;
    for(cnt=0 ; cnt<width*height*3 ; cnt++, ptr++){
        *ptr = (int)((float)(*ptr) * fact) ;
    }

    return true ;
} 
     

/****************************************************************************\
 *       Extra doxygen comments and information relating to this file       *
\****************************************************************************/
 
/** @enum ImageRGB::FieldSelector
 *
 * The FieldSelector selects the field (one of red, green and blue) for
 * the operation to be performed on.
 * 
 *//** @var ImageRGB::FieldSelector ImageRGB::RED
 * Select the red field so the operation is only performed on the red
 * values of the image data.
 * 
 *//** @var ImageRGB::FieldSelector ImageRGB::GREEN
 * Select the green field so the opertion is only performed on the green
 * values of the image data.
 * 
 *//** @var ImageRGB::FieldSelector ImageRGB::BLUE
 * Select the blue field so the operation is only performed on the blue
 * values of the image data
 * 
 */

