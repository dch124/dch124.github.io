/* conversion routines */

void conv_420p_rgb96 (int width, int height, void *src, void *dst);
void conv_420p_grey  (int width, int height, void *src, void *dst);
void conv_rgb24_rgb96(int width, int height, void *src, void *dst);
void conv_rgb24_grey(int width, int height, void *src, void *dst);
void conv_rgb32_rgb96(int width, int height, void *src, void *dst);
void conv_rgb32_grey (int width, int height, void *src, void *dst);

void conv_bgr24_rgb96(int width, int height, void *src, void *dst);

