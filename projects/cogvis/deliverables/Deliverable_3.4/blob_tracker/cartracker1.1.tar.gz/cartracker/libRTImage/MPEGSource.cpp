/** @file MPEGSource.cpp
 *
 * File containing methods for the 'MPEGSource' class.
 *
 * The header for this class can be found in MPEGSource.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following 
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/
 
#define ORIGINAL_VER
 
#include "ccvt/conv.h"
#include "MPEGSource.h"

//char *Y, *U, *V ; // commented out by cjn 14-09-01
                    // already declared in class MPEGSource

MPEGSource::MPEGSource(char* path)
/**
 * Open the Speicifed MPEG file and use it as a source of Images.
 *
 * @param path The path and filename of the MPEG file to use.
 */
{
	// check the files signature is valid
	if (!mpeg3_check_sig(path))
		throw "incompatible mpeg file";
	
	// open the MPEG file
	file = mpeg3_open(path);
	if (file == NULL)
		throw "error opening mpeg file";

	// check that it is a video MPEG file
	if (!mpeg3_has_video(file))
		throw "non-video MPEG file";
			
	
	width  = mpeg3_video_width(file, 0);
	height = mpeg3_video_height(file, 0);
	frames = mpeg3_video_frames(file, 0);
	framerate = mpeg3_frame_rate(file, 0);

	// allocate memory for rgb rows
	buff = new (unsigned char*)[height];
	for (unsigned int i = 0; i < height - 1; i++)
		buff[i] = new (unsigned char)[width*3];
	
	// last row need space for mmx scratch area
	buff[height - 1] = new (unsigned char)[width*3 + 4];

        // Allocate memory for YUV data
        Y = new char[width*height] ;
        U = new char[width*height/4] ;
        V = new char[width*height/4] ;
	
	// default palette type for this ImageSource is colour 
	type = Image::COLOUR;
}


MPEGSource::~MPEGSource()
/**
 * Close MPEG file and free up the memory
 */
{
	mpeg3_close(file);

	// free the memory for each of the rows
	for (unsigned int i = 0; i < height; i++)
		delete [] buff[i];
	
	// free the rest of the memory
	delete [] buff;
}


ImageSource& MPEGSource::operator >> (ImageRGB& img) 
/**
 * Extract a frame of the MPEG movie to the colour Images data buffer.
 *
 * @param img The colour Image to be extracted to.
 */
{
	// read the frame to a temporary buffer
	mpeg3_read_frame(file, buff, 
			 0, 0,
			 width, height,
			 width, height,
			 MPEG3_RGB888, 0);

	// convert the frame to rgb96
	conv_rgb24_rgb96(width, height, buff, img.data[0]);

	return *this;
}


ImageSource& MPEGSource::operator >> (ImageGrey& img)
/**
 * Extract a frame of the MPEG movie to the greyscale 
 * Images brightness buffer.
 *
 * @param img The greyscale Image to be extracted to.
 */
{
        // No longer needed
	// char *Y, *U, *V;	// temp pointers for yuv frame information

	// set the pointers to point to y, u, and v buffers
        // Originally used the faster:
	// mpeg3_read_yuvframe_ptr(file, &Y, &U, &V, 0);
        // But this doesn't seem to work

 
        mpeg3_read_yuvframe(file,
                            Y,U,V,
                            0, 0,
                            width, height,
                            0);

	// convert the Y (luminance) information to 32bit greyscale
        // Originally 
	conv_420p_grey(width, height, Y, img.brightness);


	return *this;
}


ImageSource& MPEGSource::operator >> (Image& img) 
/**
 * Extract a frame of the MPEG movie.
 *
 * The Image could be colour or greyscale depending on the
 * default palette type for this class.
 *
 * @param img The Image to be extracted to.
 */
{
	(type == Image::COLOUR) ? *this >> (ImageRGB&)img
				: *this >> (ImageGrey&)img;
		
	return *this;
}


void MPEGSource::get_size(unsigned int& w, unsigned int& h)
/**
 * Sets the output parameters values to the size of an MPEG frame
 *
 * @param w The width of the MPEG frame.
 * @param h The height of the MPEG frame.
 */
{
	w = width; 
	h = height;
}

int MPEGSource::set_frame(long frame_no)
/**
 * Sets file pointer to frame frame_no. Returns 0 if OK and -1 otherwise. 
 *
 * @param frame_no frame number to set file pointer to 
 */
{
    return mpeg3_set_frame(file, frame_no, 0) ;
}

void MPEGSource::get_framerate(float& fr_rate)
/**
 * Sets the frame rate parameter for future reference of an MPEG frame
 *
 * @param framerate The framerate of the MPEG.
 */
{
    fr_rate = framerate;
}

bool MPEGSource::eof() const
/**
 * Tests for end of file.
 * Returns 1 if end of file, 0 otherwise.
 */
{
    return (bool)(mpeg3_end_of_video(file, 0));
}

