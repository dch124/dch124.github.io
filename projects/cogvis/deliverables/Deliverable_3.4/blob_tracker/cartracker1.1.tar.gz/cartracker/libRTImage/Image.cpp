/** @file Image.cpp
 *
 * File containing methods for the 'Image' class.
 *
 * The header for this class can be found in Image.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following 
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/

#include <new>		// bad_alloc exception
 
#include "Image.h"


Image::Image(Image& img) : ImageBase(img), ImageRGB(img), ImageGrey(img)
/**
 * Initialise to a new image identical to the specified image
 *
 * @param img The image to copy
 */
{
}


Image::Image(unsigned int w, unsigned int h)
 : ImageBase(w,h), ImageRGB(w,h), ImageGrey(w,h)
/**
 * Allocates rgb image and the grey image class. 
 *
 * @param w The width  of the image.
 * @param h The height of the image.
 */
{
}


Image::~Image()
/**
 * Destructor for Image class. Frees memory allocated to array:
 */
{
}


void Image::set_rgb(unsigned int x, unsigned int y, PixelRGB& p)
/**
 * Method sets the red, green and blue values of the pixel specified by (x,y).>  * Throws an exception if coordinates are not valid.
 *
 * @param x,y   The coordinates of the pixel.
 * @param p The rgb values to set the pixel to.
 */
{
	ImageRGB::set_pixel(x,y,p);
}


void Image::set_brightness(unsigned int x, unsigned int y, PixelGrey& level)
/**
 * Method sets the brightness of the pixel specified by (x,y).
 * Throws an exception if coordinates are not valid.
 *
 * @param x,y   The coordinates of the pixel.
 * @param level The value to set the field to.
 */
{
	ImageGrey::set_pixel(x,y,level);
}


void Image::get_rgb(unsigned int x, unsigned int y, PixelRGB& p)
/**
 * Method to return value for pixel (x,y) in p. 
 * \note No check is made that x and y are in range.
 *
 * @param x,y The coordinates of the pixel.
 * @param p   A Reference to the pixel to store the values in.
 */
{
	ImageRGB::get_pixel(x, y, p);
}


void Image::get_brightness(unsigned int x, unsigned int y, PixelGrey& p)
/**
 * Method to return brightness level for pixel (x,y). 
 * \note No check is made that x and y are in range.
 * 
 * @param x,y The coordinates of the pixel.
 * @param p   A Reference to the Pixel to store the level of brightness in.
 */
{
	ImageGrey::get_pixel(x,y, p);
}


Image& Image::clear_rgb(int k)
/**
 * Method sets values of all three colour fields to the specified colour.
 *
 * @param k Value to clear the field to.
 */
{
	ImageRGB::clear(k);
	return *this;
}


Image& Image::clear_rgb(PixelRGB& p)
/**
 * Method sets values of all three colour fields to the specified colour.
 *
 * @param k Value to clear the field to.
 */
{
	ImageRGB::clear(p);
	return *this;
}


Image& Image::clear_brightness(int k)
/**
 * Method sets all brightness values to the specified colour.
 *
 * @param k Value to clear the field to.
 */
{
	ImageGrey::clear(k);
	return *this;
}


Image& Image::copy(Image& img)
/**
 * Copies all rgb and greyscale pixel data to img.
 * Throws an exception if images are of different size.
 *
 * @param img The image to copy the data from.
 */
{
	ImageRGB::copy(img);
	ImageGrey::copy(img);
	return *this;
}

 
Image& Image::operator = (Image& img)
/**
 * Method to overload equals (=) operator for two images.
 * Calls the copy method on img passing this as its argument.
 *
 * @param img The image to copy the data from
 */
{
	this->ImageRGB::copy(img);
	this->ImageGrey::copy(img);
	return *this ;
}

void Image::update_brightness()
/**
 * Method to update the brightness field from the RGB data.
**/
{
	unsigned int y_cnt;
	unsigned int x_cnt;
	PixelGrey *bri_ptr = brightness;
	PixelRGB* rgb_ptr = data;

	for(y_cnt=0 ; y_cnt< height ; y_cnt++){
	    for(x_cnt=0 ; x_cnt< width ; x_cnt++){
		*(bri_ptr++) = (PixelGrey)( (RED_COEF*(float)(*rgb_ptr)[0]) +
	 				(GREEN_COEF*(float)(*rgb_ptr)[1]) +
					(BLUE_COEF*(float)(*rgb_ptr)[2]) );
		rgb_ptr++;
	    } 
	}
}

/****************************************************************************\
 *       Extra doxygen comments and information relating to this file       *
\****************************************************************************/
 
/** @enum Image::Type
 *
 * The palette type of the Image, corresponding to the two classes 
 * from which the Image class is derived.
 * 
 *//** @var Image::Type Image::COLOUR
 * Specifies a palette consisting of red, green, and blue components
 * each occupying 32 bits.
 * 
 *//** @var Image::Type Image::GREYSCALE
 * Specifies a palette consisting of a single luminance component 
 * occupying 32 bits.
 * 
 */

