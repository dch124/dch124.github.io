/** @file QTSource.cpp
 *
 * File containing methods for the 'QTSource' class.
 *
 * The header for this class can be found in QTSource.h
 *
 *//**************************************************************************
 *
 * Source code for Real Time Image Library (libRTImage)
 *
 * Leeds Vision Group give permission for this code to be copied, modified 
 * and distributed within the University of Leeds subject to the following 
 * conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 ****************************************************************************/
 
#define ORIGINAL_VER
 
#include "ccvt/conv.h"
#include "QTSource.h"

QTSource::QTSource(char* path)
/**
 * Open the Speicifed QT file and use it as a source of Images.
 *
 * @param path The path and filename of the QT file to use.
 */
{
	// check the files signature is valid
	if (!quicktime_check_sig(path))
		throw "incompatible quicktime file";
	
	// open the QT file
	file = quicktime_open(path,1,0); //read access only!
	if (file == NULL)
		throw "error opening quicktime file";

	// check that it is a video QT file, with one track
	if (quicktime_video_tracks(file) != 1)
		throw "QT file does not only have one video track";
//        if (quicktime_audio_tracks(file) != 0)
//                throw "QT file has audio tracks";

	width  = quicktime_video_width(file, 0);
	height = quicktime_video_height(file, 0);
	//frames = quicktime_video_frames(file, 0);

        //Check Depth: Only RGB allowed, RGBA not supported
        //Could be, but requires extra processing in this file
	if(quicktime_video_depth(file, 0) != 24)
		throw "Depth not 24 ie not RGBRGBRGB encoded QT";

	comp_type = quicktime_video_compressor(file, 0);
	if (!quicktime_supported_video(file, 0))
		throw "QT data cannot be decoded";

	// allocate memory for rgb rows
	buff = new (unsigned char*)[height];
	for (unsigned int i = 0; i < height ; i++)
		buff[i] = new (unsigned char)[width*3];

	// default palette type for this ImageSource is colour 
	type = Image::COLOUR;
}


QTSource::~QTSource()
/**
 * Close QT file and free up the memory
 */
{
	quicktime_close(file);

	// free the memory for each of the rows
	for (unsigned int i = 0; i < height; i++)
		delete [] buff[i];
	
	delete [] buff;
}


ImageSource& QTSource::operator >> (ImageRGB& img) 
/**
 * Extract a frame of the QT movie to the colour Images data buffer.
 *
 * @param img The colour Image to be extracted to.
 */
{
	// read the frame to a temporary buffer
	quicktime_decode_video(file,buff,0);

	// convert the frame to rgb96
	conv_rgb24_rgb96(width, height, buff, img.data[0]);

	return *this;
}

ImageSource& QTSource::operator >> (ImageGrey& img)
/**
 * Extract a frame of the QT movie to the greyscale 
 * Images brightness buffer.
 *
 * @param img The greyscale Image to be extracted to.
 */
{
 
	quicktime_decode_video(file,buff,0);
  
        unsigned int y_cnt;
        unsigned int x_cnt;
        PixelGrey *bri_ptr = img.brightness;
        unsigned char* rgb_ptr = buff[0];

        for(y_cnt=0 ; y_cnt< img.get_height() ; y_cnt++){
          rgb_ptr = buff[y_cnt];
          for(x_cnt=0 ; x_cnt< img.get_width() ; x_cnt++){
            *(bri_ptr++) = (PixelGrey)( (RED_COEF*(float)*rgb_ptr++) +
                             (GREEN_COEF*(float)*rgb_ptr++) +
                             (BLUE_COEF*(float)*rgb_ptr++ ) );
          }
        }
	return *this;
}

ImageSource& QTSource::operator >> (Image& img) 
/**
 * Extract a frame of the QT movie.
 *
 * The Image could be colour or greyscale depending on the
 * default palette type for this class.
 *
 * @param img The Image to be extracted to.
 */
{
	(type == Image::COLOUR) ? *this >> (ImageRGB&)img 
				: *this >> (ImageGrey&)img;
	return *this;
}


void QTSource::get_size(unsigned int& w, unsigned int& h)
/**
 * Sets the output parameters values to the size of an QT frame
 *
 * @param w The width of the QT frame.
 * @param h The height of the QT frame.
 */
{
	w = width; 
	h = height;
}

int QTSource::set_frame(long frame_no)
/**
 * Sets file pointer to frame frame_no. Returns 0 if OK and -1 otherwise.
 *
 * @param frame_no frame number to set file pointer to
 */
{
    return quicktime_set_video_position(file, frame_no, 0) ;
}

