/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define if you have a working `mmap' system call.  */
#define HAVE_MMAP 1

/* Define as __inline if that's what the C compiler calls it.  */
/* #undef inline */

/* Define to `long' if <sys/types.h> doesn't define.  */
/* #undef off_t */

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define as 1 if you have libglib */
#define HAVE_GLIB 1

/* Define as 1 if you have libgtk */
#define HAVE_GTK 1

/* Define as 1 if you have libsdl */
#define HAVE_SDL 0

/* Define as 1 if host is an IA32 */
#define ARCH_X86 0

/* See glibc documentation.  This gives us large file support (LFS) */
#define _GNU_SOURCE 1

/* Define to indicate DEBUGGING is enabled possibly with a level */
#define DEBUG 1

/* Define to decide which YUV format to use for 420 blocks in IEC PAL */
#define YUV_420_USE_YV12 0

/* Define if you have the getpagesize function.  */
#define HAVE_GETPAGESIZE 1

/* Define if you have the gettimeofday function.  */
#define HAVE_GETTIMEOFDAY 1

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the Xv library (-lXv).  */
#define HAVE_LIBXV 1

/* Define if you have the m library (-lm).  */
#define HAVE_LIBM 1

/* Define if you have the popt library (-lpopt).  */
/* #undef HAVE_LIBPOPT */

/* Name of package */
#define PACKAGE "libdv"

/* Version number of package */
#define VERSION "0.7"

/* whether byteorder is bigendian */
/* #undef WORDS_BIGENDIAN */

/* 1234 = LIL_ENDIAN, 4321 = BIGENDIAN */
#define BYTEORDER 1234

