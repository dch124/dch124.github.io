/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* The number of bytes in a void *.  */
#define SIZEOF_VOID_P 4

/* Name of package */
#define PACKAGE "libraw1394"

/* Version number of package */
#define VERSION "0.8.2"

