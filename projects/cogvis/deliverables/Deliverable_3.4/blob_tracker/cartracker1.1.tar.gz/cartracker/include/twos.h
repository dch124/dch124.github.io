#ifndef QUICKTIME_TWOS_H
#define QUICKTIME_TWOS_H

#include "quicktime.h"

typedef struct
{
	char *work_buffer;
	long buffer_size;
} quicktime_twos_codec_t;


#endif
