#ifndef QUICKTIME_RAWAUDIO_H
#define QUICKTIME_RAWAUDIO_H

#include "quicktime.h"

typedef struct
{
	char *work_buffer;
	long buffer_size;
} quicktime_rawaudio_codec_t;


#endif
