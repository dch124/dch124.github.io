#ifndef WORKAROUNDS_H
#define WORKAROUNDS_H

// Work around gcc bugs by forcing external linkage

longest quicktime_add(longest a, longest b);
longest quicktime_add3(longest a, longest b, longest c);

#endif
