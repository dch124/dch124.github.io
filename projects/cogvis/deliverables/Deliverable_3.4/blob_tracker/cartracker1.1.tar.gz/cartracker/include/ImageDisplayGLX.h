/*****************************************************************************
 *
 * File :       ImageDisplayGLX.h
 *
 * Module :     ImageLib.a
 *
 * Author :     Derek Magee, School of Computer Science, Leeds University.
 *
 * Created :    5 October 2001 
 *
 *****************************************************************************
 *
 * Source code for Image Library MkII
 *
 * The author, Derek Magee, gives permission for this code to be copied,
 * modified and distributed within the University of Leeds subject to the
 * following conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 *****************************************************************************
 *
 * Description:
 *
 * Open GL version of ImageDisplay class.
 *
 *****************************************************************************
 *
 * Revision History:
 *
 * Date         By              Revision
 *
 * 06/05/98     DRM             Created.
 *
 ****************************************************************************/
 
#ifndef IMAGEDISPLAYGLX_H
#define IMAGEDISPLAYGLX_H

#include "Image.h"
#include "event.h"

#ifdef LINUX_VERSION
#include <gl.h>	
#include <glx.h>	
#else
#include <GL/glx.h>
#endif

#include <X11/Xlib.h>
#include <X11/Xutil.h>

/*
 * Definition of top 'ImageDisplayGL' class. See ImageDisplayGL.cc,
 * for methods associated with
 * this class. 
 */

class ImageDisplayGLX{

private:
    
    unsigned char           *RGBData;
    Window                  win;
    GLXContext              cx;
    Display                 *dpy;
    bool                    DisplayInitOK;    
    unsigned int            width ;
    unsigned int            height ;
    unsigned int            size ;

public:

    ImageDisplayGLX(unsigned int w, unsigned int h, char *);
    ~ImageDisplayGLX();

    bool                    update_display(Image &, Image::Type);
    void                    refresh_display();
    void                    refresh_display(EventType *event, int *, int *);
    void                    operator << (ImageRGB&);
    void                    operator << (ImageGrey&);
    void                    operator << (Image&);

    bool                    init_ok();

private:
    void                    initialise_display(unsigned int, unsigned int,
                                               char *);

};

#endif



 
