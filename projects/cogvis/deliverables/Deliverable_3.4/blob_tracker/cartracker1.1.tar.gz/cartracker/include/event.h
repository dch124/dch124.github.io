/*****************************************************************************
 *
 * File :       event.h 
 *
 * Module :     libImage.a
 *
 * Author :     Derek Magee, School of Computer Science, Leeds University.
 *
 * Created :    10 November 1997
 *
 *****************************************************************************
 *
 * Source code for Image Library MkII
 *
 * The author, Derek Magee, gives permission for this code to be copied,
 * modified and distributed within the University of Leeds subject to the
 * following conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 *****************************************************************************
 *
 * Description:
 *
 * Common definitions for event functionality.
 *
 *****************************************************************************
 *
 * Revision History:
 *
 * Date         By              Revision
 *
 * 10/11/97     DRM             Created.
 *
 ****************************************************************************/

#ifndef EVENT_H
#define EVENT_H

/*
 * Definition of 'EventType' enumeration.
 */

enum EventType { EVENT_NONE,
                 EVENT_LEFT_BUTTON,
                 EVENT_MIDDLE_BUTTON,
                 EVENT_RIGHT_BUTTON
               };

#endif
