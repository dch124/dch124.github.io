/*****************************************************************************
 *
 * File :       ModelBgdRT.h
 *
 * Module :     libTrack.a 
 *
 * Author :     Derek Magee, School of Computer Science, Leeds University.
 *
 * Created :    30 June 1998
 *
 *****************************************************************************
 *
 * PhD Example Software
 *
 * The author, Derek Magee, gives permission for this code to be copied,
 * modified and distributed within the University of Leeds subject to the
 * following conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 *****************************************************************************
 *
 * Description:
 *
 * Class definition for the ModelBgdRT class which statistically models
 * background OVER ALL TIME.
 * This requires the Image class from the Image library (libImage.a).
 *
 *****************************************************************************
 *
 *
 * Revision History:
 *
 * Date         By              Revision
 *
 * 30/06/98     DRM             Created from tracker code
 *                              (as TCOM-model_background.h)
 * 05/01/99     DRM             Changed to ModelBgd.h and included in tracker
 *                              library.
 * 14/09/01     DRM             Updated to ModelBgdRT.h to use new image 
 *                              library
 *
 ****************************************************************************/

#ifndef MODEL_BG_RT_H
#define MODEL_BG_RT_H 

#include <stdio.h>
#include <Image.h>

enum ImagePlaneType{
                    IMAGE_BRIGHTNESS,
                    IMAGE_RGB
} ;

class ModelBgdRT{
private:
            bool                InitOk ;
            ImagePlaneType      plane_type ;
            double              *means ;
            double              *sum_squares_av ;
            unsigned int        no_of_frames ;
            unsigned int        frame_size ;
public:
            ModelBgdRT(ImageRGB &) ;
            ModelBgdRT(ImageGrey &) ;
            ~ModelBgdRT() ;

            bool                add_new_image(Image &, Image *, double) ;
            bool                plot_current_bg(Image &) ;
            void                calculate_difference(Image &, Image &,
                                                     double, double) ;
            bool                initialised_ok();
};

#endif

