/*****************************************************************************
 *
 * File :       GrimsonBGNew.cpp
 *
 * Module :     visualise_data
 *
 * Author :     Derek Magee, School of Computing, Leeds University.
 *
 * Created :    18th September 2001
 *
 *****************************************************************************
 *
 * Source code for CogVis
 *
 * The author, Derek Magee, gives permission for this code to be copied,
 * modified and distributed within the University of Leeds subject to the
 * following conditions:-
 *
 * - The code is not to be used for commercial gain.
 * - The code and use thereof will be attributed to the author where
 *   appropriate (inluding demonstrations which rely on it's use).
 * - All modified, distributions of the source files will retain this header.
 *
 *****************************************************************************
 *
 * Description:
 *
 * Definition of class GrimsonBGNew which implements the Stauffer / Grimson
 * background model (based on mixtures of gaussians at each pixel).
 *
 * See:
 *
 * C. Stauffer, W.E.L. Grimson "Adaptive background mixture models for real-time
 * tracking", CVPR 99.
 *
 *****************************************************************************
 *
 * Revision History:
 *
 * Date         By              Revision
 *
 * 01/08/01     DRM             Created.
 *
 ****************************************************************************/

#ifndef GRIMSON_BG_H
#define GRIMSON_BG_H

#define UPDATE_RATE_MIN 25 

struct GaussianNew
{
            double weight ;
            double mean[3] ; 
            double mean_norm[3] ; 
            double mean_mag ;
            double covariance_indir ;
            double covariance_offdir ;
            double covariance_det ;
            double in_sq ;
            double off_sq ;
};

struct PixelInfo{
            GaussianNew  **gaussians ;
            unsigned int no_in_bg ;
            unsigned int frames_since_fg ;
            unsigned int frames_since_ud ;
};
            
enum DataType{
            DATA_RGB,      // RGB Data 
            DATA_NORM_RGB  // Intensity normalised RGB 
};

class GrimsonBGNew
{
// Public data 
public:
           
            bool         update_every_frame ;
 
// Private data 
private:
            unsigned int gaussians_per_mix ;
            double       bgd_prop ;
            double       alpha ;
            double       alpha_i ;
            unsigned int sx ;
            unsigned int sy ;
            unsigned int dx ;     
            unsigned int dy ;
            DataType     data_type ;
            unsigned int tot_pixels ;
            PixelInfo    *model ;
            bool         InitOk ;  
            
// Public methods 
public:
            GrimsonBGNew(unsigned int gauss_per_mix, 
                      double       bg_proportion,
                      double       update_alpha,
                      unsigned int size_x,
                      unsigned int size_y,
                      unsigned int x_inc,    // Increment for low-res model
                      unsigned int y_inc,
                      DataType     type) ;  // Increment for low-res model

            void      add_new_image(int *data, bool *mask) ;
            void      plot_best_mixture(int *data) ;
            void      set_alpha(double a) ;
            void      calculate_foreground(int *data,
                                           int *fg) ;
            void      calculate_foreground(int  *data,
                                           bool *fg) ;

// Private Methods
private:
            void      sort_gaussians(GaussianNew **) ;
            void      initialise_mixtures(GaussianNew *,
                                          GaussianNew **) ;
            double    calculate_gaussian(double *d,
                                         GaussianNew *) ;
            void      update_mixture(double *, PixelInfo *) ;
            bool      in_mixture(double *, PixelInfo *) ;
            double    mahalanobis_dist(double *, GaussianNew *) ;
            void      calculate_gaussian_norms(GaussianNew *g) ;
};
#endif
