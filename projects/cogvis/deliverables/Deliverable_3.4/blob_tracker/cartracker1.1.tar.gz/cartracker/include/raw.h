#ifndef QUICKTIME_RAW_H
#define QUICKTIME_RAW_H

#include "graphics.h"

typedef struct
{
	unsigned char *temp_frame;  /* For changing color models and scaling */
} quicktime_raw_codec_t;

#endif
