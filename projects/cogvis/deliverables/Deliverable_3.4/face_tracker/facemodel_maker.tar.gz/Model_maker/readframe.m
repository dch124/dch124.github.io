function frame = readframe(markup, index);
if markup.type == 1
   [R G B] = mpgread(MARKUP.videofile, index);
   frame = R;
else
   foo = markup.imagename(index);
   filename = [markup.videofile, foo{1}];
   frame = imread(filename);
   frame = rgb2gray(frame);
end
