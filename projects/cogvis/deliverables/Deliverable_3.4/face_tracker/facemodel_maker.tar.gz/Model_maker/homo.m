function hv = homo(v)
hv = [v ; ones(1,size(v,2))];