function map = affinemap(A,B,mode)
% STMAP optimal (LS) translation and scaling sA+T = B between corresponding points
% STMAP(A,B) where A, B are nxm matrices organised as columns of points
% returns n x n+1 affine map
% Cannot model a reflection

switch (mode)
case 'similarity'
   m = size(A,2);
   T = [-A(2,:);A(1,:)];
   P = [A(:), T(:), repmat(eye(2),m,1)] \ B(:);
   a = P(1);  b = P(2);
   map = [a -b P(3); b a P(4)];
  
case 'norotation'
m = size(A,2);
P = [A(:), repmat(eye(2),m,1)] \ B(:);
map = [P(1)*eye(2), P(2:3)];
end