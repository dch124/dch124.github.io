function M = boundsmap(A,B,flag)
% BOUNDSMAP translation and scaling mapping between bounds
% BOUNDSMAP(A,B) where A, B are nx2 matrices with 1st column lower bounds and 2nd column upper bounds,
% returns n x n+1 affine map
% Finds maximal enclosing mapping when flag is 'similarity'
AL = A(:,1);
AH = A(:,2);
BL = B(:,1);
BH = B(:,2);

S = (BH-BL)./(AH-AL);

if nargin > 2
switch (flag)
   case 'similarity'
      S = repmat(min(S),size(S));
   end
end

K = BL - AL.*S;

M = [diag(S), K];
