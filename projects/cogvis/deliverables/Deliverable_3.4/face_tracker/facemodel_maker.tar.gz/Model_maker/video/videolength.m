function nframes = videolength(video)
    nframes = video.nframes;