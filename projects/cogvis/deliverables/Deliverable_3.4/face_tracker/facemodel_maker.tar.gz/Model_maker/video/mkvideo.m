function video = mkvideo(filename)
% video = mkvideo(filename)
% avi, mpg and jpg
   [path file ext ver] = fileparts(filename);
   
   if any(strcmp(ext, {'.mpg', '.m1v'}))
      [imsize, nframes] = mpginfo(filename);
      video.type 		= 1;								% mpeg movie
      video.filename	= filename;						% full path to file
      video.nframes	= nframes;
      video.name		= file;							% name of video file
      video.imsize	= imsize;						% size of each frame in pixels

   else if any(strcmp(ext, {'.avi'}))
      infoavi = aviinfo(filename);
      video.type 		= 2;								% avi movie
      video.filename	= filename;						% full path to file
      video.nframes	= infoavi.NumFrames;
      video.name		= file;							% name of video file
      video.imsize	= [infoavi.Height infoavi.Width];				% size of each frame in pixels
      
      
   elseif strcmp(ext,'.jpg')						      
      video.type 		= 0;								% directory of jpeg images
      video.filename	= path;							% path to directory
      files = dir([path '*.jpg']);					
      video.nframes 	= length(files);
      video.name		=	path							% use directory path as name
      video.files 	= {files.name};				% name of each frame
   else
      video = []
   end
end

