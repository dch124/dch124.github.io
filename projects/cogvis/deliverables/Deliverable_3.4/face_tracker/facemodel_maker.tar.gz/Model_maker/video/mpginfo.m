function [imsize, nframes] = mpginfo(filename)
[R G B] = mpgread(filename,1);
imsize = size(R);
eval('movie = mpgread(filename,10000000);', 'nframes = catchfcn;')


function n = catchfcn
l = lasterr;
if strncmp(l,'Frame(s) requested beyond last frame',36)
   n = eval(strtok(l(39:end),')'));
else
   error(l)
end

