function frame = videoframe(video,index)
if video.type == 1
   [R G B] = mpgread(video.filename, index);
   %frame = R;
   frame = reshape([R G B], [size(R) 3]);
else if video.type == 2
   fr = aviread(video.filename, index);
   frame = double(fr.cdata)/256;
else
   foo = video.files(index);
   filename = [video.filename, foo{1}];
   frame = imread(filename);
   %frame = rgb2gray(frame);
end
end
