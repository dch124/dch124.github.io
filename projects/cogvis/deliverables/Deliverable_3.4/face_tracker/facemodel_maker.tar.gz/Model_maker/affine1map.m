function map = affine1map(P,Q)
n = length(P);
map = ([P(:) ones(n,1)]\Q(:))'; 