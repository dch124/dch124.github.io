function data = readdata(filename)
load(filename, 'data')