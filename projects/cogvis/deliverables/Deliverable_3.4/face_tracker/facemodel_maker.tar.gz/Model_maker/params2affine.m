function M = params2affine(p);
c = p(3)*cos(p(4));  s = p(3)*sin(p(4));
M = [c -s p(1); s c p(2)];