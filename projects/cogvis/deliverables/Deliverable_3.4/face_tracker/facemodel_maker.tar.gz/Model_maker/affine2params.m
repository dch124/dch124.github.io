function p = affine2params(M)
% AFFINE2PARAMS Compute parameters (x-trans, y-trans, scale, angle) of a 2-D affine map

s = norm(M(:,1));
a = acos(M(1,1)/s);
p = [M(:,3) ; s ; a];