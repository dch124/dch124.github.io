function newPC = cutcomponents(PC,k)
% cut the numbre component to k
s=size(PC.L);
if k>s(1)
	display "number of component not that big !!!";
else
newPC = PC;
newPC.E = PC.E(:,1:k);
newPC.L = PC.L(1:k,1);
end;
