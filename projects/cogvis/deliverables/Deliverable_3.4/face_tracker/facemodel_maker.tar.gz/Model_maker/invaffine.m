function B = invaffine(A);
M = A(:,1:end-1);
t = A(:,end);

IM = inv(M);
B = [IM, -IM*t];