function bounds = pointbounds(points);
bounds = [min(points, [], 2),	max(points, [], 2)];
