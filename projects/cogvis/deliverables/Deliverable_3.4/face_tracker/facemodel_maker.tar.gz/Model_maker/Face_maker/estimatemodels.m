function model = estimatemodels(markup_list);

%same than estimatemodel but for a list of markups.

size_markup=size(markup_list);
size_markup=size_markup(2);
markup=markup_list{1};
% initialise parameters
manual_indices = find(markup.manual);			% indices of aligned frames
nmanual = length(manual_indices);				% number of aligned frames
texheight = 100;										% height of the texture map in pixels
nsamples = 20;											% the number of sampled curve points
nvertices = markup_list{1}.model.nvertices; 			% number of vertices in shape template

% Iteratively align shapes to mean, updating mean on each iteration.
% Do this in pixel coordinates (PC).
% Initialise 'mean' to be shape from first aligned frame.
Vstd = markup_list{1}.vertices(:,:,manual_indices(1));
eyes_mean=geteyes(markup_list{1},Vstd);

t = inf;

for k = 1:4		% need to solve shrinking problem before using t to stop iteration
      %subplot(2,2,k), template(Vstd,markup.model.lines), drawnow;
            
      offset=0;
      for z=1:size_markup
         
         markup=markup_list{z};
         manual_indices = find(markup.manual);			% indices of aligned framE
         nmanual = length(manual_indices);				% number of aligned frames
         
         for i=1:nmanual
            
            index = manual_indices(i);
            V = markup.vertices(:,:, index);
            EYES=geteyes(markup,V);
            XV(:,:,i+offset) = affinemap(EYES, eyes_mean,'similarity') * homo(V);		% align V to mean
            %XV(:,:,i) = affinemap(V, Vstd,'similarity') * homo(V); 	   
            
         end
         offset=offset+nmanual;
		end
Vstd1 = mean(XV,3);		% re-compute mean
t = norm(Vstd-Vstd1,'fro')/norm(Vstd,'fro');
Vstd = Vstd1;
eyes_mean=geteyes(markup,Vstd);
end
% find bounds and aspect ratio of mean template
Pstd = templatepoints(Vstd, markup.model.lines, nsamples);
box = pointbounds(Pstd);
ar = (box(1,2)-box(1,1))/(box(2,2)-box(2,1));

% texture map has the same aspect ratio with given height
texwidth = ceil(texheight*ar);
texsize = [texheight texwidth];

% compute mapping from pixel-coordinates to model-coordinates, and map standard shape
PCtoMC = boundsmap(box, 0.5*[-ar ar; -1 1]);
Vstd = PCtoMC*homo(Vstd);
Pstd = PCtoMC*homo(Pstd);

% compute mapping from model-coordinates to texture-coordinates (origin top-left)
MCtoTC = boundsmap(0.5*[-ar ar; -1 1], [1 texwidth; 1 texheight]);

%compute Delaunay triangulation on points
TRI = delaunay(Pstd(1,:), Pstd(2,:));

%
% Model warp and position
%

% allocate data matrices for warp-vertices and position
nmanual=0;
for i=1:size_markup 
   markup=markup_list{i};
   manual_indices = find(markup.manual);			% indices of aligned framE
   nmanual = nmanual+ length(manual_indices);	
end

XS = zeros(2*nvertices, nmanual);
XP = zeros(4, nmanual);
eyes_mean=geteyes(markup_list{1},Vstd);

offset=0;
for z=1:size_markup
markup=markup_list{z};
manual_indices = find(markup.manual);			% indices of aligned framE
nmanual = length(manual_indices);	

for i=1:nmanual
   index = manual_indices(i);
   V = markup.vertices(:,:, index);
   
   % re-compute alignment mapping from pixel-coordinates to model-coordinates
   EYES=geteyes(markup,V);
   PCtoMC = affinemap(EYES, eyes_mean, 'similarity');
   V = PCtoMC * homo(V);
   XS(:,i+offset) = V(:);
   
   % compute mapping from image-coordinates to pixel-coordinates (origin top-left)
   h = markup.imsize(1);  w = markup.imsize(2);
   iar = w/h;
   ICtoPC = boundsmap(0.5*[-iar iar; -1 1], [1 w; 1 h]);
   
   % compute mapping from model-coordinates to image-coordinates and record as position
   MCtoIC = invaffine(multaffine(PCtoMC,ICtoPC));
   XP(:,i+offset) = affine2params(MCtoIC);
   
end
offset=offset+nmanual;
end

PCS = pca(XS);

% use fixed uniform density for position (instead of  PCP = pca(XP); )
PCP = mkunf([-0.15 0.15 ; -0.15 0.15; 0.6 0.75; -pi/36 pi/36]);

%
% Model shape-free texture
%

T = zeros(prod(texsize), nmanual);	% data matrix for un-normalised texture

% map dense standard vertices into texture map
Pstd = MCtoTC*homo(Pstd);

offset=0;
for z=1:size_markup
markup=markup_list{z};
manual_indices = find(markup.manual);			% indices of aligned framE
nmanual = length(manual_indices);	

for i=1:nmanual
   index = manual_indices(i);
   P = templatepoints(markup.vertices(:,:,index), markup.model.lines, nsamples);
   image = rgb2gray(videoframe(markup.video, index));      
   tex = movetexture(P, image, Pstd, zeros(texsize), TRI);
   XT(:,i+offset) = tex(:);        
end
offset=offset+nmanual;
end

% normalise texture - leave this out at present.  Needs to be revised to cover only
%texture region and not zero surround.
%Tstd = T(:,1);						% initialise 'mean' texture
%XT = zeros(size(T));				% data matrix for normalised texture

%t = inf;

%for k = 1:4		% need to solve shrinking problem before using t to stop iteration
      %subplot(2,2,k), template(Vstd,markup.model.lines), drawnow;

%   for i=1:nmanual
%      index = manual_indices(i);
%      XT(:,i) = (affine1map(T(:,i), Tstd) * homo(T(:,i)'))';		% align T to mean
%   end
%   Tstd1 = mean(XT,2);		% re-compute mean
%   t = norm(Tstd-Tstd1)/norm(Tstd);
%   Tstd = Tstd1;
%end


PCT = pca(XT);

% cumulative plot of eigenvalues

% cut off at 80% of total variance
PCS = chopcomponents(PCS,0.8);
PCT = chopcomponents(PCT,0.8);

% build data matrix for combined shape and texture model
% use ratio of largest eigenvalues to weight shape versus texture
w = sqrt(PCT.L(1)/PCS.L(1));
X = [w*tosubspace_raw(XS,PCS); tosubspace_raw(XT, PCT)];
PCC = pca(X)
PCC = chopcomponents(PCC,0.95);

model.combined = PCC;
model.position = PCP;
model.shape = PCS;
model.texture = PCT;
model.Pstd = Pstd;
%model.Tstd = Tstd;
model.nsamples = nsamples;
model.texsize = texsize;
model.tri = TRI;
model.nvertices = markup.model.nvertices;
model.lines = markup.model.lines;
model.nparams = PCC.nparams + PCP.nparams;

% show first three modes of shape/texture variation at mean position
nP = model.position.nparams;
nC = model.combined.nparams;
p = zeros(nP, 1);				% position fixed at parameter origin

model = learnoffsets(model)


