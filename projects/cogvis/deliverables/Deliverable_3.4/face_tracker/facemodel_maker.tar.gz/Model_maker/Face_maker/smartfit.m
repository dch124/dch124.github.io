function [a, err] = smartfit(model, image, a)

offsetinfo = model.offsetinfo;
%for scale_index=1:length(offsetinfo)
for scale_index=1:1
   t = offsetinfo;
   %sd = t{1}; A1 = t{2}; PCR1 = t{3}; A2 = t{4}; PCR2 = t{5};
   sd = t{1}; A1 = t{2}; PCR1 = t{3};
   
   % converge on position
   %a = smartfit1(model,image,a,A1,PCR1,sd);
   [a, err] = smartfit2(model,image,a,A1,PCR1,sd);

   
   % converge on shape
   %[a, err] = smartfit1(model,image,a,A2,PCR2,sd);   
end



