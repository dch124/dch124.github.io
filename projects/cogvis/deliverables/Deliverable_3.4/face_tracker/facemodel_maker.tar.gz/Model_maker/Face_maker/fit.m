function optp = fit(model, image, p0)
% variables 'model' and 'image' passed on to matchscore
optp = fminunc('matchscore', p0, optimset('Display','iter'), model, image);
