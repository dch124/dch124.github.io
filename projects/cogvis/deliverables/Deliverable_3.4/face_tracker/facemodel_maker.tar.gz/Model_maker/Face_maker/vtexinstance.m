function [V, tex] = vtexinstance(a, model, imsize);
% Produces vertices (in pixel-coordinates of size 'imsize') and texture map for given model parameters 'a'

nP = model.position.nparams;
[mS,nS] = size(model.shape.E);
[mT,nT] = size(model.texture.E);

p = a(1:nP);										% position parameters
c = a(nP+1:end);									% combined shape/texture parameters

% build mapping from model-coordinates to image-coordinates
MCtoIC = params2affine(p);

st = fromsubspace(c, model.combined);
s = st(1:nS);										% shape parameters
t = st(nS+1:end);									% texture parameters

% unweight shape
w = sqrt(model.texture.L(1)/model.shape.L(1));
s = s./w;

V = reshape(fromsubspace_raw(s, model.shape), 2, round(mS/2));		% recover vertices
tex = reshape(fromsubspace_raw(t, model.texture), model.texsize);			% recover texture


%compute mapping from image-coordinates to pixel-coordinates (origin top-left)
h = imsize(1);
w = imsize(2);
iar = w/h;
ICtoPC = boundsmap(0.5*[-iar iar; -1 1], [1 w; 1 h]);

% compute mapping from model-coordinates to pixel-coordinates, and map vertices
MCtoPC = multaffine(ICtoPC, MCtoIC);
V = MCtoPC*homo(V);
