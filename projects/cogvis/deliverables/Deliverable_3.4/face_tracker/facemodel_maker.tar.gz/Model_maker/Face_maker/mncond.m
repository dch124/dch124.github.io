function C = mncond(N,q,Y)
% MNCOND produces conditional density p(.|Y) from joint normal density N, where q specifies indices
% of conditioning variables Y (in order) from joint domain.
% If Y not supplied, pre-compute parameters from which conditional density may be generated.
% (details in Johnson and Wichern, "Applied Multivariate Statistical Analysis", Prentice Hall, 1998)
% When the joint density is over a time-series, these parameters define an auto-regressive process:
%
%				X = MX + A(Y-MY) + N(0,S)

S = mncov(N);
n = size(N.E,1);

p = setdiff(1:n,q);		% indices of X components

M1 = N.M(p,1);
M2 = N.M(q,1);
S11 = S(p,p);
S12 = S(p,q);
S21 = S(q,p);
S22 = S(q,q);

A = S12*inv(S22);

S = S11-A*S21;			% covariance

if nargin == 3
   % finish building conditional density
   M = M1 + A*(Y-M2);
   C = mkmn(M,S);
else
   % return partial density (an AR process when domain time series, so use this structure)
   M = zeros(length(p),1);
   C = mkmn(M,S,'condition');

    AR.N = C; 
    AR.M1 = M1;
    AR.M2 = M2;
    AR.A = A;
    
    C = AR;
end


