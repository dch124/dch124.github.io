function draw_graph(M, P);
r = 0.02;			% node size
xlim([0,1]), ylim([0,1]);
n = size(M,1);

for i=1:n
   for j=[1:i-1, i+1:n]
      if M(i,j) > eps
         t = M(i,j);
         line(P(1,[i j]), P(2,[i,j]), 'Color', [1-t 1-t 1])
      end
   end
end

for i=1:n
   rectangle('Position',[P(1,i)-r,P(2,i)-r, 2*r, 2*r], 'Curvature', [0.8 0.8], 'FaceColor', 'r')
end
