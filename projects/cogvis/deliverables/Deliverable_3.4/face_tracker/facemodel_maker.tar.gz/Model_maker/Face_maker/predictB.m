function [B, S] = predictB(A, bnet, T)
% PREDICTB For a given dynamic Bayes net, predict sequence B given sequence A.

% T is the number of previous samples to use for prediction
engine1 = jtree_unrolled_dbn_inf_engine(bnet, T+1); % removed 3rd argument of [2 3]

nA = size(A,2);
B = zeros(bnet.node_sizes(3,1),nA);

smpl = sample_bnet(bnet,1);
S = zeros(1,nA);
S(1:T)=smpl{1};

n=3;
evidence = cell(n,T+1);
for t=T+1:nA
   fprintf(1,'Predicting frame %d\n', t)
   % enter evidence from A and B for previous T slices
   for tt = 1:T
      %evidence{1,tt} = S(t-T+tt-1);
      evidence{2,tt} = A(:,t-T+tt-1);
      evidence{3,tt} = B(:,t-T+tt-1);
   end
   [engine2, ll] = enter_evidence(engine1, evidence);
   bnet2 = bnet_from_engine(engine2);
   smpl = sample_bnet(bnet2,1);
   S(t) = smpl{1};
   B(:,t) = smpl{3};
   %marg = marginal_nodes(engine2,[1 3],T+1);
   %[v,I] = max(marg.T);
   %B(:,t) = marg.mu(:,I);
   %S(t) = I;  
end



