function im=copy_face_image(face,image)
% fonction bidon pour copier la tete dans l'image, les 1 ne sont pas copie
s=size(image);
im=zeros(s(1),s(2),s(3));
for i=1:s(1)
   for j=1:s(2)
      if face(i,j)<1     
         im(i,j,1)=face(i,j);
         im(i,j,2)=face(i,j);
         im(i,j,3)=face(i,j);
      else
         im(i,j,1)=image(i,j,1);         
         im(i,j,2)=image(i,j,2);
         im(i,j,3)=image(i,j,3);
		end	
   end
end
