function c = nzmean(C)
% return row vector of column means of non-zero values
c = sum(C)./max(sum(C>0),ones(1,size(C,2)));
