function drawinstance(p, model, flag)
[V, image] = modelinstance(p, model, zeros(150,200));
cla
hold on
imshow(image);
[yhi, xhi] = size(image);
set(gca, 'XLim', [1 xhi], 'YLim', [1 yhi], 'Ydir', 'reverse')
template(V,model.lines)

if strcmp(flag,'all')
P = templatepoints(V, model.lines, model.nsamples);
trimesh(model.tri, P(1,:), P(2,:), ones(size(P(1,:))),...
   'FaceColor', 'none', 'EdgeColor', 'green')
end

hold off
drawnow;