function  instance = fitmodel(video, model, astart, istart)
nframes = videolength(video);
A = zeros(size(astart,1),nframes);

namedfigure('FITMODEL', 'Position', [300 300 video.imsize(2:-1:1)]);

a = astart;
for index= istart:nframes
   if index==1
   'enter breakpoint'   
   end
   
   %a virer
   index=1;
   
   im = videoframe(video,index);
   [a err] = smartfit(model, rgb2gray(im), a);
   fprintf(1,'Error for frame %d: %4.4f\n', index, err)

   A(:,index) = a;
   
   namedfigure('FITMODEL', 'Name',...
      ['FITMODEL: frame ', int2str(index), ' of ', int2str(video.nframes)]);
   drawfit(a,model,im);

end

a = astart;
for index=istart-1:-1:1
      im = videoframe(video,index);
      [a err] = smartfit(model, rgb2gray(im), a);
     fprintf(1,'Error for frame %d: %4.4f\n', index, err)
   A(:,index) = a;
   
   namedfigure('FITMODEL', 'Name',...
      ['FITMODEL: frame ', int2str(index), ' of ', int2str(video.nframes)]);
   drawfit(a,model,im);
 
end

instance.params = A;
instance.model = model;
instance.video = video;
instance.limits = [1 nframes];

   