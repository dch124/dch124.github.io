function a = encode(V,P);
n = size(P,2);
m = size(V,2);
a = zeros(1,m);
for i=1:m
   [mind, j] = min(normv(P-repmat(V(:,i),1,n)));
    a(i) = j;    
end
