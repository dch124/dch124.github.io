function D = mkunf(bounds)
D.bounds = bounds;
D.nparams = size(bounds,1);