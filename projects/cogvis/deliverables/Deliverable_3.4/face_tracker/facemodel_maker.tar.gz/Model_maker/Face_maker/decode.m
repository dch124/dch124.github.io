function V = decode(a,P)
V = P(:,a);
