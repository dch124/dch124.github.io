function [newE, newL] = eigsort(E,L)
[d, index] = sort(diag(L));
d = abs(d);				% to deal with negative eigenvalues close to zero
newL = diag(d(end:-1:1));
newE = E(:,index(end:-1:1));

