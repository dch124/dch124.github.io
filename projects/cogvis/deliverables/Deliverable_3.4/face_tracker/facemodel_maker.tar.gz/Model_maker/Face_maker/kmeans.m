function P = kmeans(V, n)
% KMEANS, cluster vectors into n parts using k-means
% The vectors V are clustered into n parts, represented by returned
% prototypes P

% Initialise P from V and set threshold to be 1/100th of diameter of V
P = samplen(V,n);
E = repmat(inf, 1, n);
%t = (diameter(V)/100)^2;
nsamples = size(V,2);

D = zeros(n, nsamples);
nchanges = inf;
iminold = zeros(1,nsamples);

while nchanges > 0   
   for i=1:n
      D(i,:) = normv(V-repmat(P(:,i),1,nsamples));
   end
   [dmin, imin] = min(D,[],1);
   
   for i=1:n
      j = find(imin==i);
      if length(j) > 1				% check there are enough samples to estimate this component
         P(:,i) = mean(V(:,j),2);
      end
   end
   
   nchanges = sum(imin - iminold > 0)
   iminold = imin;
   
end


function dmax = diameter(V)
Vsmpl = samplen(V,20);
dmax = 0;
for v=Vsmpl
   for u=Vsmpl
      d = norm(u-v);
      if d > dmax
         dmax=d;
      end
   end
end

