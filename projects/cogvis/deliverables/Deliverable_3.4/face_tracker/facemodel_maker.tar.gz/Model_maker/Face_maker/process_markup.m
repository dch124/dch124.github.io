path = 'c:\dch\research';
NAME = 'take1_B';
NAME = 'david';
NAME = 'take1_A';

markup_filename = [path '\data\markup_' NAME '.mat'];
model_filename = [path '\data\model_' NAME '.mat'];
modes_filename = [path '\videos\modes_' NAME];
instance_filename = [path '\data\instance_' NAME '.mat'];
fitmpg_filename = [path '\videos\fit_' NAME];

% read in markup file and construct model
mkp = readdata(markup_filename);
model = estimatemodel(mkp);
writedata(model,model_filename)
modesmpg(model,modes_filename)

% get model parameters for initial frame from markup file
model = readdata('c:\dch\research\data\model_david');
[astart, istart] = markup_params(mkp, model);

% fit model to video (video must not have a sound track)
instance = fitmodel(mkp.video, model, astart, istart);
writedata(instance,instance_filename);

% plot all model parameters over time
instance = readdata(instance_filename);
instanceplot(instance);
%instanceplot(unstandardiseinstance(instance))

% build mpeg showing fit
fitmpg(instance,fitmpg_filename);
