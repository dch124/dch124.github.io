function [A, B, q] = HOMMtrain(alist,n,T)

A = zeros(n,n,T);
q = zeros(n,T);

% compute frequencies
for b=alist
   a=b{1};
   for d=1:T
      i = a(T+1-d);
      q(i,d) = q(i,d)+1;
      for t=T+1:length(a)
         j = a(t);
         for d=1:T
            i = a(t-d);
            A(i,j,d) = A(i,j,d)+1;
         end
      end
   end
end

% normalise to give probabilities
for d=1:T
   for i=1:n
      r = A(i,:,d);
      rsum = sum(r);
      if rsum ~= 0
         A(i,:,d) = r/rsum;
      end
   end
   q(:,d) = q(:,d)/sum(q(:,d));
end

B = ones(1,T)*(1/T);

