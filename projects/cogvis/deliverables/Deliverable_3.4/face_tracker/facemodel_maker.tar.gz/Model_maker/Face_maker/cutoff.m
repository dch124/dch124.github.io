function k = cutoff(D, t)
s = sum(D);
if s==0
   k = 1;
else
   k = min(find((cumsum(D)/s)>t));
end

