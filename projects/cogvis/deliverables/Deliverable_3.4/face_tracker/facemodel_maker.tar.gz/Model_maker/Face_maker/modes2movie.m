function modesmovie(model)
% MODESMOVIE, show first four modes aSs a movie
namedfigure('MODESMPG','Position', [512 384 320 240])
ncparams = model.nparams - 4;									% number of combined parameters
inc = 1/10;
aN = randa([0 0; 0 0; 0.4 0.4; 0 0; 0 0],model,2);			% not random but convenient
aN(1:2,:) = [-0.33 0.33 ; -0.25 -0.25];	% position in four quadrants
emptyimage = repmat(0.5, 240, 320);		% image into which to render

index = 1;
M=moviein(83);
for x=[0:inc:2, 2:-inc:-2, -2:inc:0]
   aN(5:6,:) = diag([x x]);	% combined-parameters for each mode
   [V, image] = modelinstance(aN, model, emptyimage);
   image = clip(image,[0 1]);
   %image = clip(washin(image, 50),[0 1]);
   namedfigure('MODESMPG')
   drawimage(image), set(gca,'Position',[0 0 1 1]), drawnow;
   M(:,index) = getframe;
   index = index+1;
end
movie(M);
