function p = mnmpdf(X,M)

N = M.N;
a = M.a;

p = 0;
for i=1:M.ncomps
   p = p + a(i)*mnpdf(X,N(i));
end
