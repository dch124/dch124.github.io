function N = save_PCA(PCA,name)
%save_PCA(PCA,name)
% Save eigen space (real) in a file 'name' : 
%  (int) no_rows, (int) no_cols, data_vectors, data_values, data_mean
% A bit more general than save_eigen

fid = fopen(name,'w');
f=size(PCA.E);
fwrite(fid,f(1),'int');
fwrite(fid,f(2),'int');
% eigen vectors
fwrite(fid,double(PCA.E),'double')
% eigen values
fwrite(fid,double(PCA.L),'double')
% mean
fwrite(fid,double(PCA.M),'double')

fclose(fid);                        
