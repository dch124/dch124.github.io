function pc = Gtrain(Vlist,T,k)
% Estimate Gaussian density function over window of T-samples and spanning k principal components

d = size(Vlist{1},1)*T;

% mean
nsamples = 0;
m = zeros(d,1);
for W=Vlist
   V = W{1};
   for n=T:size(V,2)
      m = m + reshape(V(:,n-T+1:n),d,1);
      nsamples = nsamples+1;
   end
end
m = m./nsamples;

% covariance
C = zeros(d);
for W=Vlist
   V = W{1};
   'done'
   for n=T:size(V,2)
      X = reshape(V(:,n-T+1:n),d,1) - m;
      C = C + X*X';
   end
end
C = C/(size(X,2)-1);

if k == 0
   % all eigenvalues
   [E,L] = eig(C);
   [E,L] = eigsort(E,L);
else
   % k eigenvalues
   [E,L] = eigs(C,k);
end

L = diag(L);

% return parameters for Gaussian distribution in principal component structure
pc.E = E;
pc.L = L;
pc.M = M;


