function a = project(V, image, model)
% PROJECT, returns projection into model space 'a' of given template and texture

% align vertices with mean shape to find mapping from pixel-coordinates to model-coordinates
PCtoMC = affinemap(V, reshape(model.shape.M, 2, model.nvertices), 'similarity');

% compute mapping from image-coordinates to pixel-coordinates
   [h w] = size(image);
   iar = w/h;
   ICtoPC = boundsmap(0.5*[-iar iar; -1 1], [1 w; 1 h]);
   
   % compute mapping from model-coordinates to image-coordinates, giving position
   MCtoIC = invaffine(multaffine(PCtoMC,ICtoPC));
   p = affine2params(MCtoIC);

% compute position parameters

% map vertices into model coordinates and compute shape parameters
Vmodel = PCtoMC*homo(V);
s = tosubspace_raw(Vmodel(:), model.shape);

% weight by ratio of first texture and shape standard deviations
w = sqrt(model.texture.L(1)/model.shape.L(1));
s = w*s;

% extract texture and compute texture parameters
P = templatepoints(V, model.lines, model.nsamples);
tex = movetexture(P, image, model.Pstd, zeros(model.texsize), model.tri);
%T = (affine1map(tex(:),model.Tstd) * homo(tex(:)'))';		% normalise texture
t = tosubspace_raw(tex(:), model.texture);

% project shape and texture parameters into combined space
c = tosubspace([s;t], model.combined);

% final parameter vector
a = [p; c];






