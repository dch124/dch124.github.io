function W = tosubspace(V,N)
W = diag(1./sqrt(N.L))*N.E'*(V - repmat(N.M,1,size(V,2)));

