function limits = mnmextent(M)
% MNMEXTENT computes 'non-zero' domain for a multi-variate normal mixture
N = M.N;
P = [];
for i=1:M.ncomps
   m = N(i).M;
   d = sqrt(diag(N(i).covariance));
   P = [P m-d m+d];
end
limits = [min(P,[],2), max(P,[],2)];
