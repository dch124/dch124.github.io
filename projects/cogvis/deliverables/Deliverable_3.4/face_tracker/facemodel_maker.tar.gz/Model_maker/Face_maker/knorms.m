function N = knorms(V,nnormals,display)
% KNORMS, span vectors by given number of multi-variate normal densities with full covariance

% Initialise normals with mean taken from random samples, unit variance and zero covariance
[k, nsamples] = size(V);
S = eye(k);
for i=1:nnormals
   N(i) = mkmn(samplen(V,1),S);
end

lold = -inf;
ratio = 0;
while ratio < 0.98
   D = zeros(nnormals, nsamples);
   for i=1:nnormals
      D(i,:) = mnpdf(V,N(i));
   end
   [dmax,imax] = max(D,1);
   for i=1:nnormals
      j = find(imax==i);
      if length(j) > 1				% check there are enough samples to estimate this component
         N(i) = mlemn(V(:,j),0);
      end
      
   end
   l = sum(log(dmax));   			% log-likelihood for current estimate
   ratio = l/lold;   lold = l;		% compute improvement
   l, ratio
end


if nargin == 3		% show results
   cla
   colours = 'rgbcm';   
   
   hold on
   for i=1:nnormals
      j = find(imax==i);
      c = colours(mod(i,5)+1);
      plot(V(1,j),V(2,j),['.' c])
      N1 = marginalmn(N(i),1:2);
      P = fromsubspace([1.5*cos(-pi:pi/100:pi) ; 1.5*sin(-pi:pi/100:pi)],N1);
      plot(P(1,:),P(2,:),['-' c])
   end
   hold off
end

