function instancempg(instance, filename)

namedfigure('INSTANCEMPG');

params = instance.params;
nframes = size(params,2);
model = instance.model;
imsize = [200 150];
emptyimage = zeros(imsize);

for index=1:nframes
      
   % reconstructed image
   [V, image2] = modelinstance(params(:,index),model,emptyimage);
   image2 = repmat(clip(image2,[0 1]),[1 1 3]);
   
   namedfigure('INSTANCEMPG', 'Name',...
      ['FITMPG (frame ', int2str(index), ' of ', int2str(nframes)],...
      'Position', [256 256 imsize(2) imsize(1)]);
   cla
   drawimage(image2);  set(gca, 'Position', [0 0 1 1]);
      
   %M(index) = getframe;
   M(index) = im2frame(image2);
   index = index+1;
end

mpgwrite(M, [], filename, [1 0 1 1 10 8 10 10])
