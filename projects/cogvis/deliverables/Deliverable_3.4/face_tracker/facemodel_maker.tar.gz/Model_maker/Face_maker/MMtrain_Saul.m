function [A, q] = MMtrain_Saul(alist,n,T)

A = zeros(n,n,T);
q = zeros(1,n,T);

for b=alist
   a=b{1};
   for d=1:T
      i = a(T+1-d);
      q(i,d) = q(i,d)+1;
      for t=T+1:length(a)
         j = a(t);
         for d=1:T
            i = a(t-d);
            A(i,j,d) = A(i,j,d)+1;
         end
      end
end


rowsums = max(sum(A), ones(n,1,T));

for d=1:T
   for i=1:n
      r = A(i,:,d);
      rsum = sum(r);
      if rsum ~= 0
         A(i,:,d) = r/rsum;
      end
   end
   q(:,d) = q(:,d)/sum(:,d);
end

