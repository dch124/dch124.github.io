function MNM = mnm_mle(V,nnormals,option)
% MLE for multi-variate normal mixture via EM. The idea is to form expected likelihood (a function
% of the model parameters) using marginal for unknowns derived from current estimate of model. 
% Then to maximise this function to update the current estimate. For normal mixtures this reduces to
% simple update equations (Webb, A., Statistical Pattern Recognition, Arnold 1999).

% Initialise normals with mean taken from random samples, unit variance and zero covariance
[k, nsamples] = size(V);
S = eye(k);

N1 = mlemn(V,'condition');
for i=1:nnormals
   % N(i) = mkmn(samplen(V,1),S);
   N(i) = mkmn(randmn(N1,1),N1.covariance,'condition');
end
a = repmat(1/nnormals, nnormals);		% initialise mixing proportions

lold = -realmax;
change = inf;
modflag = 0;

while change < 0 | change > 0.001 | modflag
   modflag = 0;
   W = zeros(nnormals, nsamples);
   for i=1:nnormals						% probability of samples for each component
      W(i,:) = a(i)*mnpdf(V,N(i));
   end
   tW = sum(W,1);					   % likelihood for each sample
   
   W = W ./ repmat(tW,nnormals,1);	% normalise weights across components to sum to 1
   
   M = V*W';								% weighted sum of samples corresponding to each component
   a = sum(W,2)/nsamples;				% new mixing proportions
   
   for i=1:nnormals
      m = M(:,i)/(a(i)*nsamples);
      CV = V - repmat(m,1,nsamples);
      S = ((CV.*repmat(W(i,:),k,1))*CV')/(a(i)*nsamples);
	   newN = mkmn(m,S,option);
      if isempty(newN) | a(i) < 1.5/nsamples			% occurs if only one sample nearby
         [amax imax] = max(a);
         N(i) = N(imax);									% replace by strongest component				
         N(i).M = N(i).M + rand*(N(i).E(:,1));		% shift along principal direction
         a(i) = amax/2;										% incase another normal needs moving
         a(imax) = amax/2;
         modflag = 1;
      else
         N(i) = newN;
      end
   end
   l = sum(log(tW));   			% log-likelihood for current estimate
   change = 2*(l-lold)/(l+lold);   lold = l;		% relative improvement
   {'l' l 'change' change 'modflag' modflag}
   subplot(1,1,1), plot([N.L])
end

MNM.N = N;
MNM.a = a;
MNM.ncomps = nnormals;
MNM.nparams = k;
MNM.type = 'mnm';


