function newM = mnmmarginal(M,p)

N = M.N;

for i=1:M.ncomps
   newN(i) = marginalmn(N(i),p);
end

newM.N = newN;
newM.a = M.a;
newM.ncomps = M.ncomps;