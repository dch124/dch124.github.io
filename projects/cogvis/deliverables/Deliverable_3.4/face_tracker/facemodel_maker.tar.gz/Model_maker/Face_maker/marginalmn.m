function N1 = marginalmn(N,p)
% MARGINALMN produces the marginal density over the p-components of a given multi-variate normal density

N1 = mkmn(N.M(p), N.covariance(p,p));
