function [A, PCR] = learnoffsets_old(markup)
% Go through aligned frames one-by-one. For each, generate perturbed instances of
% recorded model instance (position and combined shape/texture). Subtract
% this perturbed instance from image (performed in 'shape-free' texture window). Build
% linear mapping from residual window to peturbation.
global xr XD XR Xdebug

namedfigure('LEARNOFFSETS1', 'Position', [0.2, 0.1, 0.8, 0.7])

model = markup.model;
nsamples = 10;
mindices = find(markup.manual)
mindices = mindices(2:end);			% leave out first for test image
i=1;
n = length(mindices)*nsamples
XR = zeros(prod(model.texsize),n);
Xdebug = XR;
XD = zeros(model.nparams,n);
for index = mindices
   index
   % start by finding model parameters for this frame
   V = markup.vertices(:,:,index);
   image = readframe(markup, index);
   a = project(V, image, model);
   asmpls = randda(a,model, nsamples);
   for a1 = asmpls
      [V, tex] = vtexinstance(a1,model,size(image));
      P = templatepoints(V, model.lines, model.nsamples);
      tex1 = movetexture(P,image, model.Pstd, model.texsize, model.tri);
      %dtex = tex-tex1;
      dtex = filter2(fspecial('gaussian',10,2),tex-tex1);
      Xdebug(:,i) = tex1(:);
      XR(:,i) = dtex(:);
      XD(:,i) = a - a1;
      
      % show images for first few iterations
      if i < 7
         subplot(6,4,4*(i-1)+1), imshow(tex,[0 1])
         subplot(6,4,4*(i-1)+2), imshow(tex1,[0 1])
         subplot(6,4,4*(i-1)+3), imshow(dtex,[-0.2 0.2])
         drawnow;
      end
      
      i = i+1;
   end
end

PCR = pca(XR);
PCR = chopcomponents(PCR,0.95);

xr = tosubspace_raw(XR,PCR);
%A = XD/homo(xr);
A = XD/xr;

% show projected difference images
namedfigure('LEARNOFFSETS1')
for i=1:6
   subplot(6,4,4*(i-1)+4),  
   im = reshape(fromsubspace_raw(xr(:,i),PCR),model.texsize);
   imshow(im,[-0.2 0.2])
end

% plot actual offset against computed offset for position and 1st shape parameters
namedfigure('LEARNOFFSETS2')
da = A*xr;
n = size(da,1);
nn = ceil(sqrt(n));
for i = 1:n
   subplot(nn,nn,i)
   plot(XD(i,:),da(i,:),'.')
end



function asmpls = randa(model, n)
% random model parameters
%nP = size(model.position.E, 2);
Psmpls = randunf(model.position,n);

nC = size(model.combined.E, 2);
Csmpls = randn(nC,n);

asmpls = [Psmpls ; Csmpls];

%asmpls = randn(nP+nC,n);

function asmpls = randda(a, model, n)
% random model parameters about a
D.bounds = [a(1:3), a(1:3)];
%D.bounds = [a(1:3)-[0.05 0.05 0.025]',a(1:3)+[0.05 0.05 0.025]'];
Psmpls = randunf(D,n);

% plus/minus 0.5 standard deviation for shape parameters
nC = model.combined.nparams;
Csmpls = repmat(a(4:end,1),1,n) + (rand(nC,n)-0.5);
%Csmpls = randn(nC,n);

asmpls = [Psmpls ; Csmpls];

%asmpls = randn(nP+nC,n);
