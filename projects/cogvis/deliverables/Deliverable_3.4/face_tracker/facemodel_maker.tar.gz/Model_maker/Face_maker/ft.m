function x=ft(s);

N=length(s);
for w=1:N
  x(w) = s*exp(2*pi*i*(w-1)*[0:(N-1)]/N)';
end
