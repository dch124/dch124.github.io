function v = mnpdf(X,N)

CX = X - repmat(N.M,1,size(X,2));			% centre about mean
v = real(N.scaling * exp(-0.5*sum(CX.*conj(N.icovariance*CX))));


