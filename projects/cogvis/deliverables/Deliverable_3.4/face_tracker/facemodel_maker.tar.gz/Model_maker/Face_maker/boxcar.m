function w = boxcar(n)
w = ones(n,1);