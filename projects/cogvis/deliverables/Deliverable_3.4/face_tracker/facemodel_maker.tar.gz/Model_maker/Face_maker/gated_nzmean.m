function c = gated_nzmean(C)
% return row vector of column means of non-zero values, gated by zero central pixel
c = C(5,:);		% central pixels
b = c==0;			% bitmap of zero central pixels
c = c + b.*(sum(C)./max(sum(C>0),ones(size(c))));		% gate dilation at zero pixels only
