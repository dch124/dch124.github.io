function bnet = interaction_model(instA, instB, Q)
limits = interval_intersect(instA.limits, instB.limits);
lo = limits(1);  hi = limits(2);
PA = instA.params([5:end],lo:hi);
PB = instB.params([5:end],lo:hi);

bnet = mk_hmm(PA,PB,Q);

