function V = randmn(N,n)
% RANDMN draws n random samples from given multi-variate normal density
V = fromsubspace(randn(length(N.L),n),N);

