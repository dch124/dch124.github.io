function [A, PCR] = learnoffsets2(model, range, images, aN, sd)
% Go through aligned frames one-by-one. For each, generate perturbed instances of
% recorded model instance (position and combined shape/texture). Subtract
% this perturbed instance from image (performed in 'shape-free' texture window). Build
% linear mapping from residual window to peturbation.

namedfigure('LEARNOFFSETS2','Units', 'normalized','Position', [0.2, 0.1, 0.4, 0.7]);  clf;
nsamples = 10;
nimages = size(aN,2);
i=1;
n = nimages*nsamples;
XR = zeros(prod(model.texsize),n);
XD = zeros(model.nparams,n);
emptytex = zeros(model.texsize);

for k=1:nimages
   image = images{k};
   a = aN(:,k);
      
   % generate random perturbations of sampled model instance
   for da = randa(range,model,nsamples);
      a1 = a+da;
      [V, tex] = vtexinstance(a1,model,size(image));
      P = templatepoints(V, model.lines, model.nsamples);
      tex1 = movetexture(P,image, model.Pstd, emptytex, model.tri);
      
       % normalise texture
      %tex1 = reshape(affine1map(tex1(:),model.Tstd) * homo(tex1(:)'),model.texsize);
            
      %dtex = filter2(fspecial('log',ceil(5*sd),sd),tex-tex1);
      dtex = tex-tex1;
      XR(:,i) = dtex(:);
      XD(:,i) = da;
      i = i+1;
   end
   
   % show final sample for each of the first 6 images
      if k < 7
         namedfigure('LEARNOFFSETS1');
         subplot(6,4,4*(k-1)+1), drawimage(tex,[0 1])
         subplot(6,4,4*(k-1)+2), drawimage(tex1,[0 1])
         subplot(6,4,4*(k-1)+3), drawimage(dtex,[-0.2 0.2])
         drawnow;
         mem(k) = i-1;
      end
end

PCR = pca(XR);
PCR = cutcomponent(PCR,45);

xr = tosubspace_raw(XR,PCR);
%A = XD/homo(xr);
A = XD/xr;

% show projected difference images
namedfigure('LEARNOFFSETS1')
for k=1:min(6,nimages)
   subplot(6,4,4*(k-1)+4),  
   im = reshape(fromsubspace_raw(xr(:,mem(k)),PCR),model.texsize);
   drawimage(im,[-0.2 0.2])
end
drawnow;

% plot actual offset against computed offset for position and 1st shape parameters
namedfigure('LEARNOFFSETS2')
da = A*xr;
n = size(da,1);
nn = ceil(sqrt(n));
for i = 1:n
   subplot(nn,nn,i)
   plot(XD(i,:),da(i,:),'.')
end
drawnow;
