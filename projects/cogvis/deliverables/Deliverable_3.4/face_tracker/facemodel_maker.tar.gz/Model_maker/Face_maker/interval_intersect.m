function C = interval_intersect(A,B)
% LIMITS_INTERSECT Intersection of intervals.
% intervalC = interval_intersect(intervalA, intervalB)
% intervalC = interval_intersect(intervals)

% A, B and C are n-D intervals: lower limits in 1st column, upper limits in 2nd column.
% If B is not present, A is assumed to be a 3-D matrix of intervals.
% If intersection is empty, C=[].

if nargin<2
   lo = max(A(:,1,:),[],3);	hi = min(A(:,2,:),[],3);
else
   lo = max(A(:,1),B(:,1));	hi = min(A(:,2),B(:,2));
end

if lo > hi
   C = [];
else
   C = [lo hi];
end
