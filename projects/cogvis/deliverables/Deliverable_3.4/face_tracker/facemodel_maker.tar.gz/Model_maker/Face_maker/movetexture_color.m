function A = movetexture_color(VB, B, VA, A, tri)
% Move texture from B to A, according to mapping defined by VB and VA
% Move only those pixels inside triangle. Other will be moved by neighbouring triangles.
% Perform raster scan of A within each triangle, move corresponding pixels across from B

for indices=tri'
   V3A = VA(:,indices');
   V3B = VB(:,indices');
   
   M = (V3B / [V3A ; 1 1 1])';			%mapping from A to B
   SV3A = (sortrows(V3A',2))';
   
   x1 = SV3A(1,1);
   y1 = SV3A(2,1);
   x2 = SV3A(1,2);
   y2 = SV3A(2,2);
   x3 = SV3A(1,3);
   y3 = SV3A(2,3);
   
   if y3 > y1		%check triangle has vertical extent
      g13 = (x3-x1)/(y3-y1);
      x4 = x1+(y2-y1)*g13;
      
      if y2 > y1		% check upper part of triangle has vertical extent
         g12 = (x2-x1)/(y2-y1);
         for y=ceil(y1):floor(y2)
            xlo = x1+(y-y1)*g12;  xhi = x1+(y-y1)*g13;
            if x4 < x2,  t = xlo; xlo = xhi; xhi = t; end;
            for x = ceil(xlo):floor(xhi)
               P = round([x y 1] * M);
               A(y,x,1) = B(P(2),P(1),1);
               A(y,x,2) = B(P(2),P(1),2);
               A(y,x,3) = B(P(2),P(1),3);
            end
         end
      end
      
      if y3 > y2		% check lower part of triangle has vertical extent
         g23 = (x3-x2)/(y3-y2);
         for y=ceil(y2):floor(y3)
            xlo = x2+(y-y2)*g23;  xhi = x1+(y-y1)*g13;
            if x4 < x2,  t = xlo; xlo = xhi; xhi = t; end;
            for x = ceil(xlo):floor(xhi)
               P = round([x y 1] * M);
               A(y,x,1) = B(P(2),P(1),1);
               A(y,x,2) = B(P(2),P(1),2);
               A(y,x,3) = B(P(2),P(1),3);
            end
         end
      end
   end
end
