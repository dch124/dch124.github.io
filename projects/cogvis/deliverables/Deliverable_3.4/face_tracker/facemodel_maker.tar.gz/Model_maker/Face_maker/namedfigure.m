function h = namedfigure(name, varargin)

h = findobj('Tag',name);
if isempty(h)
   h = figure('Name', name, 'Tag', name);
else
   figure(h)		% make figure current
end

n = length(varargin);
if n>0
   pn = varargin(1:2:end);
   pv = varargin(2:2:end);
   set(h,pn,pv)
end

