function fitmpg(instances, filename, frames, positions)

video = instances{1}.video;		% take video from first instance
imsize = video.imsize;
ninstances = length(instances);

if nargin>3
w = round(imsize(2)/4);  h = round(1.25*w);	% image patch with approximate proportions of head
emptyimage = repmat(0.3,h,w);

maps = cell(ninstances);
for i=1:ninstances
   bounds = instance_bounds(instances{i});
   ar = positions{1}(3)/positions{i}(4);
   maps{i} = boundsmap(bounds,0.5*[-ar ar; -1 1],'similarity');
   emptyimages{i} = repmat(0.3,positions{i}(4),positions{i}(3));
end
end

frameno = 1;
for index=frames   
   % current colour frame
   image = videoframe(video,index);
   namedfigure('FITMPG', 'Name',...
      [' frame ', int2str(index), ' of ', int2str(length(frames))],...
      'Position', [256 256 imsize(2) imsize(1)]);
   cla
   
   if nargin > 3
   for i=1:ninstances
      % inlay textured head
            a = instances{i}.params(:,index);
      model = instances{i}.model;

         a(1:4,1) = affine2params(multaffine(maps{i},params2affine(a(1:4,1))));
         [V, image1] = modelinstance(a,model,emptyimages{i});
         image1 = repmat(clip(image1,[0 1]),[1 1 3]);
         x = positions{i}(1);  y = positions{i}(2);  [h,w,d] = size(image1);
         image(y:y+h-1,x:x+w-1,:) = image1;
      end
   end
      
   drawimage(image);  set(gca, 'Position', [0 0 1 1]);
   
   for i=1:ninstances     
      a = instances{i}.params(:,index);
      model = instances{i}.model;
      
      % draw template
      [V, tex] = vtexinstance(a, model, size(image(:,:,1)));
      h = template(V, model.lines);
      tmplt = get(h,'UserData');
      set(tmplt.nodehandles, 'Visible', 'off')
      
      drawnow;
   end
   
   M(frameno) = getframe;
   frameno = frameno + 1;
end

mpgwrite(M, [], filename, [1 0 1 1 10 8 10 10])
