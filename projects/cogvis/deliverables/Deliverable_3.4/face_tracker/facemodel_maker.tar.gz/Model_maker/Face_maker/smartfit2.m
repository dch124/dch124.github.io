function [a, errmin] = smartfit2(model,image,a,A,PCR,sd)

imsize = size(image);
errmin = inf;				% initialise minimum current error to maximum value
flag = 1;					% go into first iteration
d = zeros(size(a));		% zero displacement for first iteration
emptytex = zeros(model.texsize);
%subplot(1,1,1), drawfit(a,model,image), drawnow;

	[V, tex] = vtexinstance(a, model,imsize);
    P = templatepoints(V, model.lines, model.nsamples);
    tex1 = movetexture(P,image, model.Pstd, emptytex, model.tri); 
    dtex = tex-tex1;
    r = tosubspace_raw(dtex(:), PCR);
    d = A * r				

   %for f = [1 0.5 0.25 0.125]
     for f = [1]
		a1 = a - f*d;
      [V, tex] = vtexinstance(a1, model,imsize);
      P = templatepoints(V, model.lines, model.nsamples);
      tex1 = movetexture(P,image, model.Pstd, emptytex, model.tri);
      
      % normalise texture
      %tex1 = reshape(affine1map(tex1(:),model.Tstd) * homo(tex1(:)'),model.texsize);
      
      %dtex = filter2(fspecial('log',ceil(5*sd),sd),tex-tex1);
      dtex = tex-tex1;
      err = norm(dtex,'fro');
      %if err < errmin
         a = a1										% update current instance
         %subplot(1,1,1), drawfit(a,model,image), drawnow;
         errmin = err;
         %r = tosubspace_raw(dtex(:), PCR);
         %d = A * r;									% new displacement
         
         %namedfigure('foo');
         %subplot(2,2,1), imshow(tex);
         %subplot(2,2,2), imshow(tex1);
         %subplot(2,2,3), imshow(dtex,[-0.05 0.05])
         %subplot(2,2,4), imshow(reshape(fromsubspace_raw(r,PCR),model.texsize),[-0.05 0.05]);     
         %drawnow;
         break									  		% skip to displacements from new instance
   %end
end

