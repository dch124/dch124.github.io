function s = HOMMsamplepath(A,B,q,N)

s = zeros(1,N);
C = cumsum(A,2);
cq = cumsum(q,1);
T = size(A,3);
w = size(A,2);

for d=1:T
   s(T+1-d) = sample(cq(:,d));
end

for n = T+1:N
   p = zeros(1,w);
   for d=1:T
      p = p + B(d)*C(s(n-d),:,d);
   end
   
   if p == 0
      s=s(1:n);
      break
   end
   s(n) = sample(p);
end

