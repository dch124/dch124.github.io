function image1 = washin(image, n);
% dilate image borders by iteratively smoothing and overlaying original non-zero patch
image1 = image;
b = image==0;
for i=1:n
   image1 = colfilt(image1,[3 3],'sliding', 'nzmean');
   image1 = image + b .* image1;
end
