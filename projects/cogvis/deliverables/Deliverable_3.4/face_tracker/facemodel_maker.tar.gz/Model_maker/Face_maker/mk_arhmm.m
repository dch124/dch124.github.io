function bnet = mk_arhmm(Adata,Bdata,Q)
% MK_HMM builds an AR HMM with two observed nodes in each time-slice
% A,B are observed data for HMM (possibly of different sizes)

intra = zeros(3);			% modified HMM (three nodes: one hidden, two observed in each time slice)		
intra(1,[2 3]) = 1;
inter = zeros(3);			% hidden and observed nodes connected
inter(1,1) = 1;
inter(2,2) = 1;
inter(3,3) = 1;

n = 3; 						% number of nodes in each slice

[OA,T]  = size(Adata);			% size of observed vectors from A and length of sequences
OB = size(Bdata,1);			% size of observed vectors from B

ns = [Q OA OB];			% node sizes
dnodes = 1;					% labels of discrete nodes
onodes = [2 3];			% labels of observed nodes
eclass1 = [1 2 3];		% node 1 in slice 1 gets CPD(1) - the prior, node 2/3 in slice 1 gets CPD(2/3) - gaussians
eclass2 = [4 5 6];		% node 1 in slide t>=2 gets CPD(4) - the transmat, node 2/3 in slice t>=2 gets CPD(5/6)

bnet = mk_dbn(intra, inter, ns, dnodes, eclass1, eclass2);

Sigma2 = repmat(0.01*eye(OA), [1 1 Q]);				% diagonal, small variance for node 2
Sigma3 = repmat(0.01*eye(OB), [1 1 Q]);				% diagonal, small variance for node 3

bnet.CPD{1} = tabular_CPD(bnet, 1, []);
bnet.CPD{2} = gaussian_CPD(bnet, 2, [], Sigma2 ,[],'diag','tied',0,1);	% clamp cov
bnet.CPD{3} = gaussian_CPD(bnet, 3, [], Sigma3 ,[],'diag','tied',0,1);		% clamp cov
bnet.CPD{4} = tabular_CPD(bnet, 4, []);
bnet.CPD{5} = gaussian_CPD(bnet, 5, [], [] ,[],'diag');
bnet.CPD{6} = gaussian_CPD(bnet, 6, [], [],[],'diag');


engine1 = frontier_fast_inf_engine(bnet,onodes);

% learning

cases = { cell(n,T) };		% number-of-nodes x length-of-sequence
for ii=1:T
   cases{1}{2,ii} = Adata(:,ii);	%Person A
   cases{1}{3,ii} = Bdata(:,ii);	%Person B
end

max_iter = 2;
[engine2, LL] = learn_params_dbn(engine1, cases, max_iter);
bnet = bnet_from_engine(engine2);



