function s = decode_smooth(a,P)
nfft = 256;
noverlap = 128;
V = P(:,a);
subplot(2,3,5);
imagesc(log10(V+eps)), axis xy, colormap(jet)


M = length(a);
N = M * (nfft-noverlap);
s = zeros(1,N);
xx = ((M-1)/(N-1))*((1:N)-1) + 1;
for w=1:floor(nfft/2)
   s = s + cos((2*pi*w/nfft)*1:N) .* spline(1:M, V(w,:), xx);
end



