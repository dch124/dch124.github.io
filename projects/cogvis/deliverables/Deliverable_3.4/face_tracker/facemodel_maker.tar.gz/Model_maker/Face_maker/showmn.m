function showmn(N,p,X)
namedfigure('PDF');
cla
nsamples = size(X,2);
V = X(p,:);
plot(V(1,:),V(2,:),'.g')
hold on
N1 = marginalmn(N,p);
P = fromsubspace([1.5*cos(-pi:pi/100:pi) ; 1.5*sin(-pi:pi/100:pi)],N1);
plot(P(1,:),P(2,:),'-r')
hold off
