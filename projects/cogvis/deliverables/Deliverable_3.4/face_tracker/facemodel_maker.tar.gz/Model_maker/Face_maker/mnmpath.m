function [V, MOV] = mnmpath(M,M0,T,m,method,type,limits)
% MNMPATH produces a sample path of m time-steps of the stochastic process defined by multi-variate normal
% mixture M over window of length T and initialised by multi-variate normal mixture M0.
% At each time-step, a sample is taken from the conditional density derived from M and the current history.
% The method of sampling is either RANDOM or EXP (for the expected value) or MODE - latter two not implemented yet.


p = size(M.N(1).covariance,1)/T;				% size of data vectors
V = zeros(p,m);								% matrix to hold path vectors in columns

ARM = mnmcond(M,1:p*(T-1));	       		% time increases down rows (final row is current time-step)

V(:,1:T) = reshape(randmnm(M0,1),p,T);		% initialise path (one more sample than needed)

frameno = 1;

if nargin < 7
   limits = mnmextent(mnmmarginal(M,p*(T-1)+1:p*(T-1)+2));
end

for n = T+1:m
   History = reshape(V(:,n-T+1:n-1),p*(T-1),1);
   CM = arm_to_mnm(ARM,History); 
   
   if strcmp(method,'RANDOM')
      V(:,n) = randmnm(CM,1);
   elseif strcmp(method,'EXP')      
 %     V(:,n) = C.M;
   else
      error('Sampling method not RANDOM, EXP or MODE')
   end
   
   if nargin > 5
      % Show conditional density for movie
      subplot(2,1,1)
      showmnm(mnmmarginal(CM,1:2),type,limits)
               
      MOV(frameno) = getframe;
      frameno = frameno+1
   end
end
