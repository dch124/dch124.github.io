function showpath(W,p)
W = W(p,:);
if length(p) == 2
   plot(W(1,:),W(2,:),'-r')
elseif length(p) == 3
   plot(W(1,:),W(2,:),W(3,:),'-r')
end
