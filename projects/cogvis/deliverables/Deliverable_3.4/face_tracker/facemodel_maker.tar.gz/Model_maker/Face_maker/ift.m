function s=ift(x)
N = length(x);
s = zeros(1,N);
for n=1:N
   y = exp(-2*pi*i*(n-1)*[0:(N-1)]/N);
   s(n) = x * y';
end
s = s/N;