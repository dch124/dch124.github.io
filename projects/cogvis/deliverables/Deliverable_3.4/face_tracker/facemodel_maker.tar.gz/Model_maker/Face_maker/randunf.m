function x = randunf(D,n)
% draws n samples from given uniform distribution
b = D.bounds;
m = size(b,1);
x = diag(diff(b,1,2)) * rand(m,n) + repmat(b(:,1),1,n);
