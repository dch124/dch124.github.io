function CM = mnmcond(M,p)
% MNMCOND builds 'shell' for conditional density from given multi-variate normal mixture.

n = M.ncomps;
N = M.N;
a = M.a;

for i=1:n
   AR(i) = mncond(N(i),p);
   D(i) = marginalmn(N(i),p);
end

CM.ncomps = n;
CM.AR = AR;
CM.D = D;
CM.a = a;