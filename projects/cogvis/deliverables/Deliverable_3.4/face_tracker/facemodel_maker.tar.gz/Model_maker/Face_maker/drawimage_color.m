function drawimage_color(im,limits)
% drawimage_color(im,limits)


if nargin==2
   lo = limits(1);  hi = limits(2);
   im = clip((im-lo)/(hi-lo),[0 1]);
end

if length(size(im))==2
   	'ixi'
   % grayscale image, map to rgb to avoid possible colormap clash within figure
   %im = repmat(im,[1 1 3]);
end

image(im);
set(gca,'DataAspectRatioMode','manual','Visible','off')

%,'Position',[0 0 1 1])
