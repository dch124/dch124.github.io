function i = sample(V)
% SAMPLE, produces a random sample from given cumulative distribution

u = rand;
i=1;
while u > V(i)
   i=i+1;
end

