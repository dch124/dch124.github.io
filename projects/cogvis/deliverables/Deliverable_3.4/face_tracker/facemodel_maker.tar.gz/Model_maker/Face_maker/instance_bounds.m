function bounds = instance_bounds(instance)
params = instance.params;
model = instance.model;
%imsize = instance.video.imsize;
limits = instance.limits;
for index = limits(1):limits(2)
   [V, tex] = vtexinstance(params(:,index),model,[100 100]);	% give vertices in image-coordinates
   B(:,:,index) = pointbounds(V(1:2,:)/100 - 0.5);
end

bounds = interval_union(B(:,:,limits(1):limits(2)));