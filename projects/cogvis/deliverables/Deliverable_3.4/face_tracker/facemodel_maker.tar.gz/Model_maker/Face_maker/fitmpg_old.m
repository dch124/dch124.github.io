function fitmpg(instance, filename)

namedfigure('FITMPG');

params = instance.params;
model = instance.model;
video = instance.video;
imsize = video.imsize;

emptyimage = repmat(0, imsize(1), round(imsize(2)/1.5));

for index=1:instance.video.nframes
   
   % current colour frame
   image1 = videoframe(video,index);
   
   % reconstructed image
   [V, image2] = modelinstance(params(:,index),model,emptyimage);
   image2 = repmat(clip(image2,[0 1]),[1 1 3]);
   
   % combines images onto a single canvas, and render with template
   canvas = cat(2,image1,image2);
   imsize = size(canvas);
   namedfigure('FITMPG', 'Name',...
      ['FITMPG (frame ', int2str(index), ' of ', int2str(instance.video.nframes)],...
      'Position', [256 256 imsize(2) imsize(1)]);
   cla
   drawimage(canvas);  set(gca, 'Position', [0 0 1 1]);
   
   [V, tex] = vtexinstance(params(:,index), model, size(image1(:,:,1)));
   h = template(V, model.lines);
   tmplt = get(h,'UserData');
   set(tmplt.nodehandles, 'Visible', 'off')
   drawnow;
   
   M(index) = getframe;
end

mpgwrite(M, [], filename, [1 0 1 1 10 8 10 10])
