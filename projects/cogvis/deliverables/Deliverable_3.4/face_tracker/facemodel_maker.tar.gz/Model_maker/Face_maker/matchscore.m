function score = matchscore(a, model, image)
global SUPFIG
% compute vertices and texture for given model parameters
[V, tex] = vtexinstance(a, model, size(image));

% extract texture from image
P = templatepoints(V, model.lines, model.nsamples);
imageB = movetexture(P, image, model.Pstd, model.texsize, model.tri);

score = norm(tex-imageB,'fro');

figure(SUPFIG);  subplot(1,1,1)
drawfit(a,model,image)
