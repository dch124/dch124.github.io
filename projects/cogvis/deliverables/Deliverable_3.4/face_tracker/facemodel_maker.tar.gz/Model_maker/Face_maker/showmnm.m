function showmnm(M,p,type,X,domain)
% SHOWMNM, plot mixture of multivariate normal distributions M, using indices p
% (a vector of length 2).  Also plot dataset X (normally set from which M estimated).
% Either plot as ellipses at 

namedfigure('PDF');

m = 50;
n = 50;
Z = zeros(m,n);

if length(p) ~= 2
   error('selection of indices of variables to plot must be of length two')
end

switch (type)
   
case 'ellipses'
   ncomps = M.ncomps;
   nsamples = size(X,2);
   N = M.N;
   a = M.a;
   W = zeros(ncomps, nsamples);
   for i=1:ncomps						% probability of samples for each component
      W(i,:) = a(i)*mnpdf(X,N(i));
   end
   
   colours = 'rgbcm';   
   [c,imax] = max(W);
   
   V = X(p,:);
   for i=1:ncomps
      j = find(imax==i);
      c = colours(mod(i,5)+1);
      plot(V(1,j),V(2,j),['.' c])
      hold on
      N1 = marginalmn(N(i),p);
      P = fromsubspace([1.5*cos(-pi:pi/100:pi) ; 1.5*sin(-pi:pi/100:pi)],N1);
      plot(P(1,:),P(2,:),['-' c])
   end
   
   hold off
   
case {'contour', 'shaded'}
   M = mnmmarginal(M,p);
   
   if nargin < 4
      domain = mnmextent(M);
   end
   
   xx = linspace(domain(1,1),domain(1,2),m);
   yy = linspace(domain(2,1),domain(2,2),n);
   for x=1:m
      x
      for y=1:n
         Z(x,y) = mnmpdf([xx(x); yy(y)],M);
      end
   end
   
   if strcmp(type,'contour')
      contourf(Z)
   elseif strcmp(type, 'shaded')
      surf(Z, 'FaceColor','interp','EdgeColor','none','FaceLighting','phong')
   end
   
otherwise
   error('Unknown display type')
end

