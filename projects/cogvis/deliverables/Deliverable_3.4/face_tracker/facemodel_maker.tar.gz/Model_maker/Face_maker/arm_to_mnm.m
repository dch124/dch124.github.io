function M = arm_to_mnm(ARM,Y)
% ARM_TO_MNM instantiates given 'shell' conditional density for given Y

AR = ARM.AR;
a = ARM.a;
D = ARM.D;
n = ARM.ncomps;

for i=1:n
   N(i) = AR_to_norm(AR(i),Y);
   a(i) = a(i) * mnpdf(Y,D(i));
end

a = a/sum(a);

M.N = N;
M.a = a;
M.ncomps = n;