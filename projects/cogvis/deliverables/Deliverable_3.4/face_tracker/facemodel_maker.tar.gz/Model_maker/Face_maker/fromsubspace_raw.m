function V = fromsubspace_raw(W,N)

V = N.E*W + repmat(N.M,1,size(W,2));