function N = save_Pstd(Pstd,name,s)
%save_Pstd(Pstd,name)

% Save the points of the mean (interpolated) in a file 'name' : 
%  (int) nbr, x1, y1, x2, y2...

'save Pstd'

fid = fopen(name,'w');
f=size(Pstd)
fwrite(fid,f(2),'int');

% data
for i=1:f(2)
fwrite(fid,Pstd(1,i),'double');
fwrite(fid,Pstd(2,i),'double');
end

if nargin==3 fwrite(fid,s,'int')
end



fclose(fid);                        
