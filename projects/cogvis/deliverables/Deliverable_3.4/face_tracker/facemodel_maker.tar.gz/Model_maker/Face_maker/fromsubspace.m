function V = fromsubspace(W,N)

V = N.E*diag(sqrt(N.L))*W + repmat(N.M,1,size(W,2));