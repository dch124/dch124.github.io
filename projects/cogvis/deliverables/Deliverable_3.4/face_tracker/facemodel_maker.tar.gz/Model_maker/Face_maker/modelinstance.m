function [V, image] = modelinstance(aN, model, image)
imsize = size(image);
for i=1:size(aN,2)
   [V(:,:,i), tex] = vtexinstance(aN(:,i), model, imsize);
   %tex = washin(tex,1);			% fix for holes appearing around the edge
   									% perhaps better to incorporate into PC's for texture
   P = templatepoints(V(:,:,i), model.lines, model.nsamples);
   image = movetexture(model.Pstd,tex,P,image, model.tri); 
end

