% use the GUI markup to produce a disk file of marked-up frames

% read in markup file and construct model
markup = readdata('vinnie_expression_markup.mat');
model = estimatemodel(markup);
writedata(model,'C:/TEMP/vincent/Matlab/Face/vinnie_model_describe.mat')

% build mpeg showing first four modes of model
%modesmpg(model,'c:\dch\research\videos\david_modes')
modesmovie(model)

% get model parameters for initial frame from markup file
video = mkvideo('C:\TEMP\vincent\vinnie1.mpg');

[astart, istart] = markup_params(markup, model);

% fit model to video (note that video must not have a sound track)
instance = fitmodel(video, model, astart, istart);
writedata(instance,'C:\TEMP\vincent\derek_instance');

% plot all model parameters over time
instance = readdata('c:\dch\research\data\instance_david');
instanceplot(instance);
instanceplot(unstandardiseinstance(instance))

% build mpeg showing fit
fitmpg({instance},'C:\TEMP\vincent\instance_derek.mpg',1:380,{[1 1 100 80]});


% INTERACTION MODELLING AND SYNTHESIS

instanceA = ...
   process_markup('c:\dch\research\data\markup_take1_A', 'c:\dch\research', 'A');
instanceB = ...
   process_markup('c:\dch\research\data\markup_take1_B', 'c:\dch\research', 'B');

% build mpeg showing fit
fitmpg({instanceA, instanceB},'c:\dch\research\videos\fit_take1_2',1:1091);

%
instanceB = readdata('c:\dch\research\data\instance_take1_A.mat');  % dch
instanceA = readdata('c:\dch\research\data\instance_take1_B.mat');  % Titch
instanceplot(instanceA);

% smooth instances
[b,a] = butter(9,0.1);
instanceA.params = filter(b,a,(instanceA.params)')';
instanceB.params = filter(b,a,(instanceB.params)')';


T =5;
bnet3 = interaction_model(instanceA, instanceB, 5);
[C3,S3] = predictB(instanceA.params([5:end],:), bnet3, T);

fC3 = filter(b,a,C3')';

P = repmat([0 0 0.5 0]',1,size(fC3,2));
instanceC.params = [P;fC3];
instanceC.limits = [T+1 1091];
instanceC.model = instanceB.model;

instanceB.params(1:2,:) = 0;
instanceB.params(3,:) = 0.5;

interactionmpg(instanceA,instanceB,'c:\dch\research\videos\interaction3',100:101)

writedata({C3,S3},'foo')
duration = 1090;
smpl = sample_dbn(bnet3,duration);
Aparams = [smpl{2,:}];
Bparams = [smpl{3,:}];
S = [smpl{1,:}];

[b,a] = butter(9,0.1);
Aparams = filter(b,a,Aparams')';
Bparams = filter(b,a,Bparams')';

P = repmat([1/3 0 0.6 0]',1,duration);
instanceC.params = [P;Aparams];
instanceC.limits = [1 duration];
instanceC.model = instanceA.model;
instanceC.video = [];

P = repmat([-1/3 0 0.6 0]',1,duration);
instanceD.params = [P;Bparams];
instanceD.limits = [1 duration];
instanceD.model = instanceB.model;
instanceD.video = [];


fittexmpg({instanceC,instanceD},'c:\dch\research\videos\interaction2',[240 320],1:duration)

figure
subplot(3,1,1), plot(S)	,			title('HMM state')
subplot(3,1,2), plot(Aparams(1,:)), title('Shape/texture parameters for A')
subplot(3,1,3), plot(Bparams(1,:)), title('Shape/texture parameters for B')
for i=1:3
   params = [xxx{i,:}];
   subplot(3,1,i), plot(params(1,:))
end


for i=1:1
   subplot(3,1,1), plot(instanceA.params(4+i,1:1091))
   subplot(3,1,2), plot(instanceB.params(4+i,1:1091))
   subplot(3,1,3), plot(fC3(i,1:1091))
end


subplot(4,1,1), plot(S3(1,:))
subplot(4,1,2), plot(C2)
subplot(4,1,3), plot(instanceA.params(5,:))
subplot(4,1,4), plot(instanceB.params(5,:))

s = struct(bnet3.CPD{4});
s.CPT
