function newPC = chopcomponents(PC,k)
newPC = PC;
n = cutoff(PC.L,k);
newPC.E = PC.E(:,1:n);
newPC.L = PC.L(1:n,1);
newPC.nparams = n;
