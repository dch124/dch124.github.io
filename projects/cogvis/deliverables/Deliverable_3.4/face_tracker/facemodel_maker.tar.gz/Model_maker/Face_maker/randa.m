function asmpls = randa(range, model, n)
% random model parameters
nC = model.combined.nparams;
nP = model.position.nparams;
prange = range(1:nP,:);  crange = range(nP+1,:);
asmpls = randunf(mkunf([prange; repmat(crange,nC,1)]), n);
