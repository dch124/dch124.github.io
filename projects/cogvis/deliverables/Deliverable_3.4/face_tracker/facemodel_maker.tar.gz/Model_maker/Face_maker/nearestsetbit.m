function res = nearestsetbit(index, bitmap, mode);
if strcmp(mode,'up')
   g = find(bitmap(index+1:end));
   if isempty(g), res = 0;  else, res = g(1)+index; end
elseif strcmp(mode,'down')
   g = find(bitmap(1:index-1));
   if isempty(g), res = 0; else, res = g(end); end
elseif strcmp(mode,'all')
   g = find(bitmap);
   [val, k] = min(abs(g-index));
   if isempty(val), res = 0; else res = g(k); end 
else
   warndlg('mode not recognised: must be up, down, or all')
end
