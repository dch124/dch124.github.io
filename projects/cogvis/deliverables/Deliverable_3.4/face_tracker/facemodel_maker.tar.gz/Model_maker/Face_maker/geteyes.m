function EYES = geteyes(markup,V)

EYES=zeros(2,2);

eye1=markup.model.lines{markup.model.eyes(1)};
eye2=markup.model.lines{markup.model.eyes(2)};

Xeye1=0;
Xeye2=0;
Yeye1=0;
Yeye2=0;
s=size(eye1);
for i=1:s(2)-1
   Xeye1=Xeye1+V(1,eye1(i));
   Xeye2=Xeye2+V(1,eye2(i));
   Yeye1=Yeye1+V(2,eye1(i));
   Yeye2=Yeye2+V(2,eye2(i));
end
Xeye1=Xeye1/(s(2)-1);
Xeye2=Xeye2/(s(2)-1);
Yeye1=Yeye1/(s(2)-1);
Yeye2=Yeye2/(s(2)-1);

EYES(1,1)=Xeye1;
EYES(2,1)=Yeye1;
EYES(1,2)=Xeye2;
EYES(2,2)=Yeye2;
