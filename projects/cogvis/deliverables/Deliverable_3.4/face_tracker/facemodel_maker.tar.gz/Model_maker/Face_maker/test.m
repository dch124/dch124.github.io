

%test
k=1;
image = images{k};
a = aN(:,k);

a1= a+da;
[V, tex] = vtexinstance(a1,model,size(image));
P = templatepoints(V, model.lines, model.nsamples);
tex1 = movetexture(P,image, model.Pstd, emptytex, model.tri);
dtex = tex-tex1;
clear res
res(:,1)=dtex(:);
res=tosubspace_raw(res,PCR);
A*res