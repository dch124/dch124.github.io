function S = mncov(N)
%S = N.E*diag(N.L)*N.E';
S = N.covariance;
