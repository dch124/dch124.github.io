function model = estimatemodel(markup);

% image coordinates (IC) and model coordinates (MC) have increasing x left-to-right
% and increasing y top-to-bottom. This follows MATLAB convention for images and
% ensures affine transformations between pixel and image/model coordinates do
% not introduce reflections (and thereby violate assumption in stmap that mapping
% is a translation and uniform scaling).

% Normalisation of texture has been removed.  This affects project, learnoffsets1, 
% and smartfit1

% initialise parameters
manual_indices = find(markup.manual);			% indices of aligned frames
nmanual = length(manual_indices);				% number of aligned frames
texheight = 100;										% height of the texture map in pixels
%texheight = 100;										% height of the texture map in pixels
nsamples = 20;											% the number of sampled curve points
nvertices = markup.model.nvertices; 			% number of vertices in shape template

% Iteratively align shapes to mean, updating mean on each iteration.
% Do this in pixel coordinates (PC).
% Initialise 'mean' to be shape from first aligned frame.
Vstd = markup.vertices(:,:,manual_indices(1));
EYES_mean=geteyes(markup,Vstd);

t = inf;

for k = 1:4		% need to solve shrinking problem before using t to stop iteration
      %subplot(2,2,k), template(Vstd,markup.model.lines), drawnow;

   for i=1:nmanual
      index = manual_indices(i);
      V = markup.vertices(:,:, index);
      EYES=geteyes(markup,V);
      XV(:,:,i) = affinemap(EYES, EYES_mean,'similarity') * homo(V);		% align V to mean
  		%XV(:,:,i) = affinemap(V, Vstd,'similarity') * homo(V); 	   
   end
   Vstd1 = mean(XV,3);		% re-compute mean
   t = norm(Vstd-Vstd1,'fro')/norm(Vstd,'fro');
   Vstd = Vstd1;
   EYES_mean=geteyes(markup,Vstd);
end

% find bounds and aspect ratio of mean template
Pstd = templatepoints(Vstd, markup.model.lines, nsamples);
box = pointbounds(Pstd);
ar = (box(1,2)-box(1,1))/(box(2,2)-box(2,1));

% texture map has the same aspect ratio with given height
texwidth = ceil(texheight*ar);
texsize = [texheight texwidth];

% compute mapping from pixel-coordinates to model-coordinates, and map standard shape
PCtoMC = boundsmap(box, 0.5*[-ar ar; -1 1]);
Vstd = PCtoMC*homo(Vstd);
Pstd = PCtoMC*homo(Pstd);

% compute mapping from model-coordinates to texture-coordinates (origin top-left)
MCtoTC = boundsmap(0.5*[-ar ar; -1 1], [1 texwidth; 1 texheight]);

%compute Delaunay triangulation on points
TRI = delaunay(Pstd(1,:), Pstd(2,:));

%
% Model warp and position
%

% allocate data matrices for warp-vertices and position
XS = zeros(2*nvertices, nmanual);
XP = zeros(4, nmanual);
EYES_mean=geteyes(markup,Vstd);

for i=1:nmanual
   index = manual_indices(i);
   V = markup.vertices(:,:, index);
   
   % re-compute alignment mapping from pixel-coordinates to model-coordinates
   EYES=geteyes(markup,V);
   PCtoMC = affinemap(EYES, EYES_mean, 'similarity');
   V = PCtoMC * homo(V);
   XS(:,i) = V(:);
   
   % compute mapping from image-coordinates to pixel-coordinates (origin top-left)
   h = markup.imsize(1);  w = markup.imsize(2);
   iar = w/h;
   ICtoPC = boundsmap(0.5*[-iar iar; -1 1], [1 w; 1 h]);
   
   % compute mapping from model-coordinates to image-coordinates and record as position
   MCtoIC = invaffine(multaffine(PCtoMC,ICtoPC));
   XP(:,i) = affine2params(MCtoIC);
   
end

PCS = pca(XS);

% use fixed uniform density for position (instead of  PCP = pca(XP); )
PCP = mkunf([-0.15 0.15 ; -0.15 0.15; 0.6 0.75; -pi/36 pi/36]);

%
% Model shape-free texture
%

T = zeros(prod(texsize), nmanual);	% data matrix for un-normalised texture

% map dense standard vertices into texture map
Pstd = MCtoTC*homo(Pstd);

for i=1:nmanual
   index = manual_indices(i);
   P = templatepoints(markup.vertices(:,:,index), markup.model.lines, nsamples);
   image = rgb2gray(videoframe(markup.video, index));      
   tex = movetexture(P, image, Pstd, zeros(texsize), TRI);
   XT(:,i) = tex(:);        
end

% normalise texture - leave this out at present.  Needs to be revised to cover only
%texture region and not zero surround.
%Tstd = T(:,1);						% initialise 'mean' texture
%XT = zeros(size(T));				% data matrix for normalised texture

%t = inf;

%for k = 1:4		% need to solve shrinking problem before using t to stop iteration
      %subplot(2,2,k), template(Vstd,markup.model.lines), drawnow;

%   for i=1:nmanual
%      index = manual_indices(i);
%      XT(:,i) = (affine1map(T(:,i), Tstd) * homo(T(:,i)'))';		% align T to mean
%   end
%   Tstd1 = mean(XT,2);		% re-compute mean
%   t = norm(Tstd-Tstd1)/norm(Tstd);
%   Tstd = Tstd1;
%end


PCT = pca(XT);

% cumulative plot of eigenvalues

% cut off at 80% of total variance
PCS = chopcomponents(PCS,0.8);
PCT = chopcomponents(PCT,0.8);

% build data matrix for combined shape and texture model
% use ratio of largest eigenvalues to weight shape versus texture
w = sqrt(PCT.L(1)/PCS.L(1));
X = [w*tosubspace_raw(XS,PCS); tosubspace_raw(XT, PCT)];
PCC = pca(X)
PCC = chopcomponents(PCC,0.95);

model.combined = PCC;
model.position = PCP;
model.shape = PCS;
model.texture = PCT;
model.Pstd = Pstd;
%model.Tstd = Tstd;
model.nsamples = nsamples;
model.texsize = texsize;
model.tri = TRI;
model.nvertices = markup.model.nvertices;
model.lines = markup.model.lines;
model.nparams = PCC.nparams + PCP.nparams;

% show first three modes of shape/texture variation at mean position
nP = model.position.nparams;
nC = model.combined.nparams;
p = zeros(nP, 1);				% position fixed at parameter origin

model = learnoffsets(model)


