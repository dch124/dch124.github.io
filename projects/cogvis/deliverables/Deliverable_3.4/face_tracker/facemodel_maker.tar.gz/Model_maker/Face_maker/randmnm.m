function x = randmnm(M,n)
% RANDMNM choses random samples from multi-variate normal mixture M

N = M.N;
a = M.a;
c = cumsum(a);
p = length(N(1).L);
x = zeros(p,n);
for i =1:n
   x(:,i) = randmn(N(sample(c)),1);
end

