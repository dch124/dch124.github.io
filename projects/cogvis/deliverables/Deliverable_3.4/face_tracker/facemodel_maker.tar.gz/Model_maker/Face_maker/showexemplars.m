function showexemplars(P,X,p)
colours = 'rgbcm';   

nexemplars = size(P,2);
nsamples = size(X,2);
D = zeros(nexemplars, nsamples);

for i=1:nexemplars
   D(i,:) = normv(X-repmat(P(:,i),1,nsamples));			% squared distance
end
[dmin, imin] = min(D,[],1);

for i=1:nexemplars
      j = find(imin==i);
      c = colours(mod(i,5)+1);
      % plot chosen elements of vectors
      plot(X(p(1),j),X(p(2),j),['.' c], P(p(1),i),P(p(2),i), ['o' c])
      hold on
end

   xlabel(['component ' int2str(p(1))])
   ylabel(['component ' int2str(p(2))])
   title('Data points and exemplars')
