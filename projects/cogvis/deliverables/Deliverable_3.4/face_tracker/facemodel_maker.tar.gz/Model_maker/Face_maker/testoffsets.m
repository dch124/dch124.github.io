function testoffsets(markup, model) 
mindices = find(markup.manual);
nsamples = 10;
i=1;
for index=mindices
   V = markup.vertices(:,:,index);
   image = readframe(markup, index);
   a = project(V, image, model);
   %for da = randa([-0.05 0.05],[-0.05 0.05],[0 0],[-0.5 0.5],model,nsamples);
   for da = randa([0 0],[0 0],[0 0],[-0.5 0.5],model,nsamples);
      a1 = a+da;
      [V, tex] = vtexinstance(a1,model,size(image));
      P = templatepoints(V, model.lines, model.nsamples);
      tex1 = movetexture(P,image, model.Pstd, model.texsize, model.tri);
      dtex = filter2(fspecial('gaussian',10,2),tex-tex1);
      xr(:,i) = tosubspace_raw(dtex(:),model.PCR);
      XD(:,i) = da;
      i=i+1;
   end
end

namedfigure('TESTOFFSETS')
da = model.A*xr;
n = size(da,1);
nn = ceil(sqrt(n));
for i = 1:n
   subplot(nn,nn,i)
   plot(XD(i,:),da(i,:),'.')
end
