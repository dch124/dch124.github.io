function N = save_matrix(X,name)
% Save matrix in a file 'name' : (int) no_rows, (int) no_cols, datas

fid = fopen(name,'w');
f=size(X);

fwrite(fid,f(1),'int');
fwrite(fid,f(2),'int');
fwrite(fid,X,'double')
fclose(fid);                        
