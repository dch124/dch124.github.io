function N = save_lines(lines,name)
%save_lines(lines,name)
% Save the constitution of the points in lines in a file 'name' : 
%  (int) nbr { (int) size p1 p2 p3...}

fid = fopen(name,'w');
f=size(lines);
fwrite(fid,f(2),'int');

% data
for i=1:f(2)
f=size(lines{i});
fwrite(fid,f(2),'int')
	for j=1:f(2)
		fwrite(fid,lines{i}(j),'int')
	end
end

fclose(fid);                        
