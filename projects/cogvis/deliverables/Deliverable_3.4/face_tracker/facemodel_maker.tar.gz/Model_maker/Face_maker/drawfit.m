function drawfit(aN, model, image)   

drawimage(image)
for i=1:size(aN,2)
   [V(:,:,i), tex] = vtexinstance(aN(:,i), model, size(image));
   h = template(V(:,:,i), model.lines);
   tmplt = get(h,'UserData');
   set(tmplt.nodehandles, 'Visible', 'off')
end
drawnow;
