function [A, q] = MMtrain(alist,n)

A = zeros(n);
q = zeros(1,n);

for b=alist
   a=b{1};
   i = a(1);
   q(i) = q(i)+1;
   for j=a(2:end)
      A(i,j) = A(i,j)+1;
      i = j;
   end
end

n = max(sum(A,2)', ones(1,size(A,1)));
A = diag((1./n))*A;
q = q/sum(q);
