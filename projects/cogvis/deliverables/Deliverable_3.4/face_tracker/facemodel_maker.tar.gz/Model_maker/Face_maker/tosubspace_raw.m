function W = tosubspace_raw(V,N)
W = N.E'*(V - repmat(N.M,1,size(V,2)));

