% MARKUP, application for constructing templates of nodes and lines, and aligning these with inidividual video frames.

open markup.fig		% pre-defined markup window