function instanceplot(instance)

namedfigure('PLOTINSTANCE', 'Units', 'normalized','Position', [0.1 0.1 0.8 0.8]);
params = instance.params;

subplot(3,2,1), plot(params(1,:)), title('Horizontal position')
subplot(3,2,3), plot(params(2,:)), title('Vertical position')
%subplot(4,2,5), plot(params(3,:)), title('Scale')
subplot(3,2,5), plot(params(4,:)), title('Angle')
subplot(3,2,2), plot(params(5,:)), title('1st component')
subplot(3,2,4), plot(params(6,:)), title('2nd component')
subplot(3,2,6), plot(params(7,:)), title('3rd component')
%subplot(4,2,8), plot(params(8,:)), title('4th component')

   