% Experiment with HMM toolbox from Berkeley

Q = 5;					% num hidden states in HMM
[O, T] = size(P);		% size of observed vector and length of sequence
ncases = 1;				% one training sequence
cases = {P};
max_iter = 10;

prior0 = normalise(rand(Q,1));
transmat0 = mk_stochastic(rand(Q,Q));
mu0 = rand(O,Q);
Sigma0 = repmat(eye(O), [1 1 Q]);

data = zeros(O, T, ncases);
for i=1:ncases
   data(:,:,i) = cases{i};
end
[LL2, prior2, transmat2, mu2, Sigma2] = learn_ghmm(data, prior0, transmat0, mu0, Sigma0, max_iter);


% Experiment with BNT from Berkeley

instance = readdata('c:\dch\research\data\david_instance');
X = instance.params;
P = X(4,1:320);
P = X([1:2,4:end],:);

intra = zeros(2);			% an HMM (two nodes: one hidden, one observed)		
intra(1,2) = 1;
inter = zeros(2);			% hidden nodes connected, but not observed nodes (not an AR HMM)
inter(1,1) = 1;
n = 2; 						% number of nodes in each slice

[O, T] = size(P);			% size of observed vector and length of sequence
Q = 5; 						% num hidden states

ns = [Q O];
dnodes = 1;					% labels of discrete nodes
onodes = [2];				% labels of observed nodes
eclass1 = [1 2];			% node 1 in slice 1 gets CPD(1) - the prior, node 2 in slice 1 gets CPD(2) - the gaussian
eclass2 = [3 2];			% node 1 in slide t>=2 gets CPD(3) - the transmat, node 2 in slice t>=2 gets CPD(2)
bnet = mk_dbn(intra, inter, ns, dnodes, eclass1, eclass2);

prior0 = normalise(rand(Q,1));					% random prior
transmat0 = mk_stochastic(rand(Q,Q));			% random transition matrix (rows sum to one)
mu0 = rand(O,Q);										% random means for gaussians
Sigma0 = repmat(0.1*eye(O), [1 1 Q]);				% diagonal, unit variance
bnet.CPD{1} = tabular_CPD(bnet, 1, prior0);
bnet.CPD{2} = gaussian_CPD(bnet, 2, mu0, Sigma0);
bnet.CPD{3} = tabular_CPD(bnet, 3, transmat0);


clear engine;
engine{1} = hmm_inf_engine(bnet, onodes);
%engine{2} = jtree_unrolled_dbn_inf_engine(bnet, T, onodes);
N = length(engine);


% inference

ev = sample_dbn(bnet2, 320);
evidence = cell(n,T);
evidence(onodes,:) = ev(onodes, :);

instance2.params = [ev{2,1:100}];
instanceplot(instance2)

subplot(3,1,1), plot([ev{1,1:320}])
subplot(3,1,2), plot(filter(boxcar(5),5,[ev{2,1:320}]))
subplot(3,1,3), plot(P(1:320))


t = 2;
query = [1 2];
for i=1:N
  [engine{i}, ll(i)] = enter_evidence(engine{i}, evidence);
  m{i} = marginal_nodes(engine{i}, query, t);
end


% learning

cases = { cell(n,T) };		% number-of-nodes x length-of-sequence
for ii=1:T
   cases{1}{2,ii} = P(:,ii);	Person A
end

max_iter = 10;
[engine2, LL] = learn_params_dbn(engine, cases, max_iter);



bnet2 = bnet_from_engine(engine2);

for i=1:N
  temp = bnet_from_engine(engine2{i});
  for e=1:3
    CPD{i,e} = struct(temp.CPD{e});
  end
end


% Build a Dynamic Bayes Net with discrete hidden node and two Gaussian observation nodes at each time slice.
% This allows one observation stream to be inferred when the other is known.

add_BNT_to_path
instance = readdata('c:\dch\research\data\david_instance');
X = instance.params;
P = X(4,1:320);
%P = X([1:2,4:end],:);

intra = zeros(3);			% a modified HMM (three nodes: one hidden, two observed in each time slice)		
intra(1,[2 3]) = 1;
inter = zeros(3);			% hidden nodes connected, but not observed nodes (not an AR HMM)
inter(1,1) = 1;
n = 3; 						% number of nodes in each slice


[O, T] = size(P);			% size of observed vector and length of sequence
Q = 5; 						% num hidden states

ns = [Q O O];
dnodes = 1;					% labels of discrete nodes
onodes = [2 3];				% labels of observed nodes
eclass1 = [1 2 3];			% node 1 in slice 1 gets CPD(1) - the prior, node 2/3 in slice 1 gets CPD(2/3) - gaussians
eclass2 = [4 2 3];			% node 1 in slide t>=2 gets CPD(4) - the transmat, node 2/3 in slice t>=2 gets CPD(2/3)
bnet = mk_dbn(intra, inter, ns, dnodes, eclass1, eclass2);

prior0 = normalise(rand(Q,1));					% random prior
transmat0 = mk_stochastic(rand(Q,Q));			% random transition matrix (rows sum to one)
mu0 = rand(O,Q);										% random means for gaussians
Sigma0 = repmat(0.1*eye(O), [1 1 Q]);				% diagonal, unit variance
bnet.CPD{1} = tabular_CPD(bnet, 1, prior0);
bnet.CPD{2} = gaussian_CPD(bnet, 2, mu0, Sigma0);
bnet.CPD{3} = gaussian_CPD(bnet, 3, mu0, Sigma0);
bnet.CPD{4} = tabular_CPD(bnet, 4, transmat0);

%engine = frontier_inf_engine(bnet, onodes);
%engine = jtree_dbn_inf_engine(bnet, onodes);
engine = hmm_inf_engine(bnet,onodes);

% learning

cases = { cell(n,T) };		% number-of-nodes x length-of-sequence
for ii=1:T
   cases{1}{2,ii} = P(:,ii);	%Person A
   cases{1}{3,ii} = P(:,ii);	%Person B
end

max_iter = 10;
[engine2, LL] = learn_params_dbn(engine, cases, max_iter);

bnet2 = bnet_from_engine(engine2);

% inference

clear ev
ev = sample_dbn(bnet2, 320);

instance2.params = [ev{1:3,1:100}];
instanceplot(instance2)

subplot(4,1,1), plot([ev{1,1:TT}])
subplot(4,1,2), plot(filter(boxcar(5),5,[ev{2,1:TT}]))
subplot(4,1,3), plot(filter(boxcar(5),5,Q))
subplot(4,1,4), plot(P(1:TT))

TT = 100;
ev = sample_dbn(bnet2, TT);
evidence = cell(n,TT);
%evidence(2,:) = ev(2,:);			% Sampled data for Person A
evidence(2,:) = cases{1}(2,1:TT);			% Sampled data for Person A
[engine5, ll] = enter_evidence(engine5, evidence);

clear Q
for t=1:TT
   marg = marginal_nodes(engine5,1,t);
   Q(t) = marg(2).mu;
   [v,I] = max(marg(1).T);
   S(t) = I;  
   end

bnet5 = bnet_from_engine(engine5);
ev = sample_dbn(bnet5, TT);

bnet4 = bnet_from_engine(engine2);
engine5 = frontier_inf_engine(bnet4, [2]);

engine5 = jtree_unrolled_dbn_inf_engine(bnet4, TT, [2]);

