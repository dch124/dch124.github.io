function model = learnoffsets(model)

% make some images from which to work !!
nimages = 40;
k = 1;
% At fixed position, sample shape over +/-2SD
for a = randa([0 0; 0 0; 0.7 0.7; 0 0; -1.2 1.2],model,nimages);
   [V, image] = modelinstance(a, model, zeros(2*model.texsize));
   %image = washin(image,10);		% dilate face to prevent border effects
   images{k} = image;
   aN(:,k) = a;
   k=k+1;
end

sdN = [2];		% standard deviations for smoothing

for scale_index=1:length(sdN)
   
   sd = sdN(scale_index);   
   
   % gradient for translation
   [A1, PCR1] = learnoffsets2(model, [-0.02 0.02; -0.02 0.02; -0.03 0.03;  -pi/72 pi/72;...
         -0.8 0.8],images, aN, sd);
	%[A1, PCR1] = learnoffsets2(model, [-0.03 0.03; -0.0 0.0; -0 0;...
       %  -pi/36 pi/36; -0 0],images, aN, sd);
   %A1(5:end,:) = 0;		% disable shape gradient
   
   % gradient for shape parameters
   %[A2, PCR2] = learnoffsets1(model, [0 0; 0 0; 0 0; 0 0; -0.5 0.5],images, aN, sd);
   
   %offsetinfo{scale_index} = {sd, A1, PCR1, A2, PCR2};
   offsetinfo = {sd, A1, PCR1};

end

model.offsetinfo = offsetinfo;
