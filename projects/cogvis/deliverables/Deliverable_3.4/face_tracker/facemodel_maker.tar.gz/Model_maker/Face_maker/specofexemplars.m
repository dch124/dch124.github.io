function specofexemplars(V)
X = abs(V);
w = size(V,2)
imagesc([1 w],[0 1], log10(abs(X)+eps)), axis xy, colormap(jet)
xlabel('Time'), ylabel('Frequency')

