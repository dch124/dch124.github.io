function usinstance = unstandardiseinstance(instance)
params = instance.params;
model = instance.model;
nframes = size(params,2);
usparams = params(4:end,:).*repmat(sqrt(model.combined.L),1,nframes);
usinstance.params = [params(1:3,:) ; usparams];
usinstance.model = model;