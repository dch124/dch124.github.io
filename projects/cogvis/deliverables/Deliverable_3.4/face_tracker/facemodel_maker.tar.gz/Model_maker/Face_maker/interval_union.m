function C = interval_union(A,B)
% LIMITS_UNION Union of intervals.
% intervalC = interval_union(intervalA, intervalB)
% intervalC = interval_union(intervals)

% A, B and C are n-D intervals: lower limits in 1st column, upper limits in 2nd column.
% If B is not present, A is assumed to be a 3-D matrix of intervals.

if nargin<2
   lo = min(A(:,1,:),[],3);	hi = max(A(:,2,:),[],3);
else
   lo = min(A(:,1),B(:,1));	hi = max(A(:,2),B(:,2));
end

C = [lo hi];
