function fittexmpg(instances, filename, imsize, frames)

ninstances = length(instances);
emptyimage = repmat(0.5,imsize);

frameno = 1;
for index=frames   
   namedfigure('FITMPG', 'Name',...
      [' frame ', int2str(index), ' of ', int2str(length(frames))],...
      'Position', [256 256 imsize(2) imsize(1)]);
   cla
   
   image = emptyimage;
   for i=1:ninstances
      params = instances{i}.params;
      model = instances{i}.model;
      a = params(:,index);
   [V, image] = modelinstance(a,model,image);
   end
   
   image = repmat(clip(image,[0 1]),[1 1 3]);
   drawimage(image);  set(gca, 'Position', [0 0 1 1]);
   drawnow;
   
   M(frameno) = getframe;
   frameno = frameno + 1;
end

mpgwrite(M, [], filename, [1 0 1 1 10 8 10 10])
