function interactionmpg(instanceA, instanceC, filename, frames)

params = instanceC.params;
model = instanceC.model;
video = instanceA.video;
imsize = video.imsize;
namedfigure('INTERACTIONMPG', 'Position', [256 256 imsize(2) imsize(1)]);

image = repmat(0.5,imsize(1), imsize(2)/2);
frameno = 1;
for index=frames
   
   % current colour frame
   image2 = videoframe(video,index);
   % reconstructed image
   [V, image] = modelinstance(params(:,index),model,image);
   image2(:,1:160,:) = repmat(clip(image,[0 1]),[1 1 3]);
   
     namedfigure('INTERACTIONMPG', 'Name',...
      ['INTERACTIONMPG (frame ', int2str(index), ' of ', int2str(instanceA.video.nframes)]);
   cla
   drawimage(image2);  set(gca, 'Position', [0 0 1 1]);
   
      drawnow;
   
   M(frameno) = getframe;
   frameno = frameno+1;
end

mpgwrite(M, [], filename, [1 0 1 1 10 8 10 10])
