function draw_triangles_shape(model)
% draw the triangle of the shape
s=size(model.tri);
%clf
%axis([0 model.texsize(2) 0 model.texsize(1)])
%axis ij
%axis manual
%hold 

M1=model.Pstd(1,:);
M2=model.Pstd(2,:);


for i=1:s(1)
plot([M1(model.tri(i,1)),M1(model.tri(i,2))],[M2(model.tri(i,1)),M2(model.tri(i,2))],'ko-')
end

for i=1:s(1)
plot([M1(model.tri(i,2)),M1(model.tri(i,3))],[M2(model.tri(i,2)),M2(model.tri(i,3))],'ko-')
end

for i=1:s(1)
plot([M1(model.tri(i,3)),M1(model.tri(i,1))],[M2(model.tri(i,3)),M2(model.tri(i,1))],'ko-')
end


