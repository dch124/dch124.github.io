function N = mkmn(M,S,option)
%MKMN, builds structure for a multi-variate normal density function
N.M = M;
N.covariance = S;
[E,L] = eig(S);
[E,L] = eigsort(E,L);
L = diag(L);

if L<eps, N = []; return, end		% degenerate case


if nargin==3 & strcmp(option,'condition') & length(L) > 1
      % redistribute last 5% of variance uniformly over final components
      t = 0.05*sum(L);					% 0.05 of total variance
      k = cutoff(L,0.95);
      t1 = sum(L(k+1:end));				% total variance beyond 95% cutoff
      v = t/(1+length(L)-k);			% share of variance for each final component
      L(k+1:end) = v;					% give share to components beyond cutoff
      L(k) = L(k)+v-(t-t1);			% take balance from cutoff and give share also
end

N.icovariance = E*diag(1./L)*E';
N.E = E;
N.L = L;
N.scaling = 1/( ((2*pi)^(length(L)/2)) * sqrt(prod(L)) );
N.nparams = length(L);
N.type = 'mn';