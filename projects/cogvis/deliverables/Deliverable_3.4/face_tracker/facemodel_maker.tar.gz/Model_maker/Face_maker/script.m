//Script to create a Face model

% place the point, do the line linking for as many image as you want.
% Make sure the left eye is the second spline et the right eye the third
markup_fig
% Don't forget to save the markup

%load it
markup = readdata('your_markup_file.mat');
markup.model.eyes=zeros(2,1);
markup.model.eyes(1)=2;
markup.model.eyes(2)=3;

% create the model (might take a while)
model = estimatemodel_color(markup);
% have a look at estimatmodel function to move the parameters.

save_model(model)
% will create all the .lab file you need for the tracker.


