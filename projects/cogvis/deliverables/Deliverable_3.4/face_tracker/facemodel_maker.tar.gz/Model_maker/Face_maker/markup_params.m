function [astart, istart] = markup_params(markup, model)
mindices = find(markup.manual);			% indices of all selected frames
istart = mindices(1);						% use the first of these
image = rgb2gray(videoframe(markup.video,istart));
astart = project(markup.vertices(:,:,istart),image,model);
