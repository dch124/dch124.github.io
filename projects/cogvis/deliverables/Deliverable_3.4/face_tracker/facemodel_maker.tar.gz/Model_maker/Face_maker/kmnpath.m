function [V, MOV] = mnmpath(M,M0,T,m,method,display)
% Random walk of m time-steps of the stochastic process defined by multi-variate normal mixture M
% over window of length T and initialised by multi-variate normal mixture M0.
% At each time-step, a sample is taken from the 
% conditional density derived from M and the current history.
% The method of sampling is either RANDOM or EXP (for the expected value) or MODE.


p = size(N(1).covariance,1)/T;				% size of data vectors
V = zeros(p,m);								% matrix to hold path vectors in columns

   ARM = mnmcond(M,1:p*(T-1));		% time increases down rows (final row is current time-step)
D = marginalmn(M,1:p*(T-1));				% marginal over history


V(:,1:T) = reshape(randmnm(M0,1),p,T);		% initialise path (one more sample than needed)

if nargin == 6
   % setup for display
   subplot(2,1,1)
   M1 = marginalmnm(N,p*(T-1)+1:p*(T-1)+2);	% marginal over 1st and 2nd state variables at current time-step
   M = N1.M;										% sample mesh over +/- two SDs
   D = 2*sqrt(diag(mncov(N1)));
   Z = zeros(50);
   xx = linspace(M(1)-D(1),M(1)+D(1),50);
   yy = linspace(M(2)-D(2),M(2)+D(2),50);
   frameno = 1;
end

for n = T+1:m
   History = reshape(V(:,n-T+1:n-1),p*(T-1),1);
   for i =1:M.nnormals
      C.a(i) = M      C.N(i) = AR_to_norm(AR(i),History);
      C.a(i) = M.a(i) * mnpdf(History,D(i));
   end
   C.a(i) = C.(i)/sum(C.a(i));
         
   if strcmp(method,'RANDOM')
      randomfrom(
      C = AR_to_norm(AR{i}.History)
      
      V(:,n) = randmn(C,1);
   elseif strcmp(method,'EXP')      
 %     V(:,n) = C.M;
   else
      error('Sampling method not RANDOM, EXP or MODE')
   end
   
   if nargin == 6
      % Show conditional density for movie
      v = C.M;
      for x=1:50
         for y=1:50
            v(1) = xx(x);
            v(2) = yy(y);
            Z(x,y) = mnpdf(v,C);
         end
      end
      if strcmp(display,'contour')
         contourf(Z)
      else
            surf(Z, 'FaceColor','interp','EdgeColor','none','FaceLighting','phong');
      end
         
      MOV(frameno) = getframe;
      frameno=frameno+1
   end
end



function Z = mn2pdf(X,Y,N)
Z = zeros(size(X));
k = find(X==X);		% must be a better way to do this
Z(k) = mnpdf([X(k);Y(k)],N);