function WX = doit(X,T);

% start by looking for peaks in signal X and generate windows of size T
% Do this by making all windows and filtering those with local maximum
clf
subplot(3,1,1), plot(X,'b')
% filter sequence to remove small bumps
sd = 2;
Y = filter(boxcar(5),5,X);
subplot(3,1,2), plot(Y,'b')
Z = filter([1 -1],1,Y);
subplot(3,1,3), plot(Z,'b')

hT=round(T/2);
p=zeros(size(Z));  goingup=0;
for i=hT:length(Z)-hT
   if Z(i)>0, goingup=1;
   elseif Z(i)<0
      if goingup, p(i-hT+1)=1; end
      goingup=0;
   end
end

peakindices = find(p);
%hT = T/2;
%peakindices = find((Z(hT:end-hT-1)>=0) & (Z(hT+1:end-hT)<0));


subplot(3,1,2), hold on, ylim = get(gca,'Ylim');
plot(repmat(peakindices+hT,2,1), repmat(ylim',1,length(peakindices)),'-r')
hold off

WX = window_sequences({Y},T,inf);
WX = WX(:,peakindices);			% should contain all windows of length T about peak
figure;
subplot(2,1,1), plot(WX)

PC = pca(WX);
subplot(2,1,2), plot(PC.M,'b'), hold on, plot(PC.E(:,1:4),'g')


