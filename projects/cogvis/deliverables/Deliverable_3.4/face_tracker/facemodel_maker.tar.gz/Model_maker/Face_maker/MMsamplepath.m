function s = MMsamplepath(A,q,N)

s = zeros(1,N);
C = cumsum(A,2);
cq = cumsum(q);
i = sample(cq);
'starting at', i
for n = 1:N
   s(n) = i;
   if C(i,end) == 0
      s=s(1:n);
      break
   end
   j = sample(C(i,:)');
   [j A(i,j)]
   i=j;
end

