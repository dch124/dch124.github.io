function X = graph_layout(M)

ntimes = 5000;
n = size(M,1);
X = rand(2,n);
MM = zeros([n,n,n]);
for i = 1:n
   MM(:,:,i) = diag(M(i,:));
   MM(i,i,i) = 1;
end

k=0.1;
for i=1:ntimes
   p = rand(2,1);
   D = repmat(p,1,n) - X;
   [c,i] = min(normv(D));
   X = X + D*MM(:,:,i)*k;
   k = k*0.999;
end

k=0.1;
for i=1:ntimes
   p = rand(2,1);
   D = repmat(p,1,n) - X;
   [c,i] = min(normv(D));
   X(:,i) = X(:,i) + D(:,i)*k;
   %k = k*0.999;
end
