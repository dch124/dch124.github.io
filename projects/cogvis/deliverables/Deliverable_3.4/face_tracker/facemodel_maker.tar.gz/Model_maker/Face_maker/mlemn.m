function N = mlemn(X,option)
% Maximum likelihood estimate of multi-variate normal density from given samples

n = size(X,2);			% number of samples

M = mean(X,2);			% sample mean (ML estimator for mean) 

X = X - repmat(M,1,n);
S = X*X'./n;				% sample covariance (ML estimator for covariance)

if nargin<2, option = 'none'; end

N = mkmn(M, S, option);
