function C = AR_to_norm(AR,Y);
% AR_TO_NORM computes normal density from AR process and given Y

C = AR.N;
C.M = AR.M1 + AR.A*(Y-AR.M2);
