function X = window_sequences(Vlist,T,m)
% Generate data matrix by sliding T-window over time series up to a maximum of m positions from start

% compute length of data matrix
k = 0;
for W=Vlist
   [d,n] = size(W{1});
   nsamples = min(m,n-T+1);
   k = k+nsamples;
end

% build data matrix
X = zeros(d,T,k);
lo = 1;
for W=Vlist
   V = W{1};
   n = size(V,2);
   nsamples = min(m,n-T+1);
   hi = lo+nsamples-1;
   for i=1:T
      X(:,i,lo:hi) = V(:,i:(i+nsamples-1));
   end
   lo = hi+1;
end

X = reshape(X,d*T,k);

