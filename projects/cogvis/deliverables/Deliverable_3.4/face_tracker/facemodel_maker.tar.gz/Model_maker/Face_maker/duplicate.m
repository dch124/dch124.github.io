function first = duplicate(V);
% locate the first duplicate in the vector V
% first contain the positions, -1 if no duplicates.
s=size(V);
first=zeros(2,1);
exit=0;
first(1)=-1;first(2)=-1;
for i=1:s(2)
	for j=i+1:s(2)
		if ((V(1,i)==V(1,j)) & (V(2,i)==V(2,j))) 
			exit=1;
			first(1)=i;first(2)=j;
			break;
		end
	end
if (exit==1) 
	break;
end
end

