function A = pca(X,k)
% Principal component analysis

[m,n] = size(X);

M = mean(X,2);			% centre on sample mean
CX = X - repmat(M,1,n);

if nargin == 2
   % compute only the first k principal components
   [E,L] = eigs(CX*CX'./n, k);
elseif n>=m
   % solve problem directly
   [E,L] = eig(CX*CX'./n);
else
   % solve transposed problem 
   % to solve (1/n)CC'x=ax, let x=Cy, (1/n)CC'Cy=aCy, cancel C giving (1/n)C'Cy=ay
   [E,L] = eig(CX'*CX./n);				% retain divisor from original problem
   E = normalisecolumns(CX*E);		% transform back to obtain principal components of original problem
end

[E,L] = eigsort(E,L);

A.M = M;
A.E = E;
A.L = diag(L);
A.nparams = m;


function B = normalisecolumns(A)

B = zeros(size(A));
for c=1:size(A,2)
   V = A(:,c);
   s = norm(V);
   if s==0
      B(:,c) = V;
   else
      B(:,c) = V/s;
   end
end



