function N = save_tri(tri,name)
%save_tri(tri,name)

% Save the points of the triangles of the mean (interpolated) in a file 'name' : 
%  (int) nbr, a1, b1, c1, a2, b2 ,c2...

fid = fopen(name,'w');
f=size(tri);
fwrite(fid,f(1),'int');

% data
for i=1:f(1)
fwrite(fid,tri(i,1),'int')
fwrite(fid,tri(i,2),'int')
fwrite(fid,tri(i,3),'int')
end

fclose(fid);                        
