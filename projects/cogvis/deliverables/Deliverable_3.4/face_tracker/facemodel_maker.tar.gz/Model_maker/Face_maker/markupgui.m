function markupgui(action)
% MARKUPGUI callback for markup GUI

% Information on current session:
%		session.markup			the current markup structure
%		session.filename		filename for save operations
%		session.index			index of current frame
%		session.instance		instance structure defining template for non-selected frames

% Uses and constructs models of the form:
% 		model.position			PC for position
% 		model.combined			PC for combined model
% 		model.shape				PC for shape
% 		model.texture			PC for texture
% 		model.PNORM				high resolution sampling used for rendering
% 		model.nsamples			number of samples used for high-resolution sampling
% 		model.texsize			size of texture map
% 		model.tri		  		high resolution triangulation
% 		model.lines				lines of the model
%
%
% For the creation of files of markup data from images and videos.  Creates and edits structures of the form:
% 		markup.nframes			number of frames in video or images
% 		markup.vertices		2 x nvertices x nframes matrix of vertices
%		markup.nvertices		number if vertices
% 		markup.manual			vector of length nframes, 1 if aligned, 0 otherwise
% 		markup.lines			indices into vertices defining lines of the modelled structure
% 		markup.filename		filename of markup file on disk
% 		markup.imsize		   [height, width] in pixels of frames
%		markup.model			model defining structure and default used for markup


session = get(gcbf, 'UserData');

if isempty(session)
   % first time through, so initialise session
   session.markup = [];
   session.instance = [];
   set(gcbf, 'UserData', session)		% save now incase re-entered before end
end

switch(action)
   
case 'new'				%start a new markup archive
   
   % save current markup file if open
   if ~isempty(session.markup)
      button = questdlg('Save current markup archive?');
      if strcmp(button, 'Yes')
         markupgui('save')
      end
   end
   
   % obtain name of video
   [file, path] = uigetfile('*.*', 'Select video or image in target directory');
   if file == 0 & path == 0, return, end		% trap 'cancel'
   
   video = mkvideo([path file]);
   if isempty(video), warndlg('Not an MPEG video or JPEG image'), return, end
   markup.video = video;
   markup.nframes = video.nframes;
   
   % define model with one vertex
   model = [];
   model.nvertices = 1;
   model.lines = {};
   
   markup.model = model;
   markup.imsize = video.imsize;																% image size
   markup.vertices = repmat(round(markup.imsize(2:-1:1)/2)', [1, 1, markup.nframes]);	% put single vertex in the middle
   markup.manual = zeros(1, markup.nframes);												% all frames unselected
   
   % configure slider for the number of frames in video
   set(findobj('Tag','Slider1'),'Min',1,'Max',markup.nframes, 'Value',1,...
      'SliderStep',[1/markup.nframes 10/markup.nframes]);
   
   set(gcf, 'Name', ['Markup file: <untitled> of video: ', markup.video.name])
   
   session.markup = markup;
   session.filename = [];									% no filename for save
   session.index = 1;										% start at frame 1
   session.template_handle = [];							% no template handle yet
   session.instance = [];
   
   session = showframe(session);
   
   turnonuimenus;
   
   
case 'open'		% open existing markup archive
   
   [file, path] = uigetfile('*.mat', 'Select markup archive');
   if file == 0 & path == 0, return, end		% trap 'cancel'
   session.filename = [path file];	% record filename for later save
   
   markup = readdata(session.filename);
   
   session.markup = markup;
   session.index = 1;										% start at frame 1
   session.template_handle = [];							% no template handle yet
   session.instance = [];
   
   % configure slider for the number of frames in video
   set(findobj('Tag','Slider1'),'Min',1,'Max',markup.nframes, 'Value',1,...
      'SliderStep',[1/markup.nframes 10/markup.nframes]);
   
   set(gcf, 'Name', ['Markup file: ', file, '  of video: ', markup.video.name])
   
   session = showframe(session);
   
   turnonuimenus;
   
   
case 'save'		% save markup archive to disk
   
   session = updatemarkup(session);
   if isempty(session.filename)
      markupgui('saveas')
   else
      writedata(session.markup, session.filename)
   end
   
case 'saveas'	%write markup archive as new file
   
   session = updatemarkup(session);
   [file, path] = uiputfile('*.mat', 'Save as...');
   if file == 0 & path == 0, return, end		% trap 'cancel'
   
   session.filename = [path file];
   set(gcf, 'Name', ['Markup file: ', file, '  of video: ', session.markup.video.name])

   writedata(session.markup, session.filename)
   
case 'openmodel'	% load model from disk
   
   [file, path] = uigetfile('*.mat', 'Select model');
   if file == 0 & path == 0, return, end		% trap 'cancel'
   
   model = readdata([path file]);
   session.markup.model = model;
   
   % initialise vertices from means in current model
   nP = model.position.nparams;
   nC = model.combined.nparams;
   p = [0 0 0.7 0]';
   c = zeros(nC,1);
   [V, image] = vtexinstance([p;c], model, session.markup.imsize);
   session.markup.vertices = repmat(V, [1, 1, session.markup.nframes]);
   
   session = showframe(session);
   
case 'savemodel'	% save model to disk
   
   [file, path] = uiputfile('*.mat', 'Save model as...')
   if file == 0 & path == 0, return, end		% trap 'cancel'
   writedata(session.markup.model, [path file])
   
case 'openinstance'	% initialise all unselected templates from a model instance held on disk
   [file, path] = uigetfile('*.mat', 'Select instance');
   if file == 0 & path == 0, return, end		% trap 'cancel'
   
   instance = readdata([path file]);
   session.instance = instance;					% save incase needed in future
   
   if session.markup.model.nvertices ~= instance.model.nvertices
      % different model, so import model also and unselect all frames
      session.markup.model = instance.model;
      session.markup.manual(:) = 0;
      session.markup.vertices = zeros(2,instance.model.nvertices,session.markup.nframes);
   end
   
   for index=1:session.markup.nframes
      if ~session.markup.manual(index)
         [vertices, tex] = vtexinstance(instance.params(:,index),...
            instance.model,session.markup.imsize);
         session.markup.vertices(:,:,index) = vertices;
      end     
   end
   
   session = showframe(session);
   
   
case 'frameselect'	% set new frame index from slider

   session = updatemarkup(session);
   session.index = round(get(gcbo,'Value'));
	session.index
   session = showframe(session);
   
case 'forwardseek'	% move forward to nearest selected frame
   nindex = nearestsetbit(session.index, session.markup.manual, 'up');
   nindex 
	if nindex>0
      session = updatemarkup(session);
      session.index = nindex;
      session = showframe(session);
   end   
   
case 'backseek'	% move backwards to nearest selected frame
   nindex = nearestsetbit(session.index, session.markup.manual, 'down');
   if nindex>0
      session = updatemarkup(session);
      session.index = nindex;
      session = showframe(session);
   end  
   
case 'aligned'	% toggle select for this frame
   session.markup.manual(session.index) = get(findobj('Tag','Checkbox1'),'Value');
	get(findobj('Tag','Checkbox1'),'Value')
   session.markup.manual
   if session.markup.manual(session.index) == 0
      % use template from instance if available
      session = updatemarkup(session);     
      session = showframe(session);
   end
   
%case 'estimatemodel'
%   session.markup.model = estimatemodel(session.markup);
%   session.markup.model = learnoffsets(session.markup.model);
   
end

set(gcbf,'UserData',session)				% save session info back with calling figure

% end of markupgui



function session = showframe(session);

figure(gcbf), cla			% select figure issuing callback and clear axes

% update text box with new frame number
index = session.index;
set(findobj('Tag','StaticText1'),'String',['Frame ', int2str(index)])

image(videoframe(session.markup.video, index));

if ~session.markup.manual(index) & isempty(session.instance)
   % not selected, nor initialised from instance
   nindex = nearestsetbit(index, session.markup.manual, 'all');
   if nindex
      % update template from nearest selected frame
      session.markup.vertices(:,:,index) = session.markup.vertices(:,:,nindex);
   end
end

% set select checkbox
set(findobj('Tag', 'Checkbox1'), 'Value', session.markup.manual(index))

% set slider position
set(findobj('Tag','Slider1'), 'Value', session.index);

% draw template
'template_handel affectation'
session.template_handle = template(session.markup.vertices(:,:,index), session.markup.model.lines);
'done'

function session = updatemarkup(session);
[vertices, lines, changeflag] = templatedata(session.template_handle);
if changeflag == 2		% structure changed
   % overwrite markup for all frames
   session.markup.vertices = repmat(vertices,[1 1 session.markup.nframes]);
   session.markup.model.lines = lines;
   session.markup.model.nvertices = size(vertices, 2);
elseif changeflag == 1	% vertices/lines moved 
   % update markup for this frame only
   session.markup.vertices(:,:,session.index) = vertices;
end


function index = stringindex(string, array);
%index of matching string in array. 0 if array empty or no match
if isempty(array)
   index = 0
else
   bits = strcmp(string, array);
   if sum(bits) == 0
      index = 0
   else
      [C, index] = max(bits);
   end
end


function turnonuimenus;
H = [findobj('Tag','MarkupSave'), findobj('Tag','MarkupSaveAs'),...
      findobj('Tag','MarkupLoadModel'), findobj('Tag','MarkupSaveModel'),...
      findobj('Tag','MarkupOpenInstance')];
set(H, 'Enable', 'on')
