function B = clip(A,range)
%CLIP, clips values in A to given range
imsize = size(A);
B = min(repmat(range(2),imsize),max(repmat(range(1),imsize),A));
