function C = multaffine(A, B)
C = A * [B ; zeros(1,size(B,2)-1), 1];