function from_spline=create_from_spline(ctrls,steps)

from_spline.nctrls=ctrls;
from_spline.nsteps=steps;

