function template_delete(template_handle)
template = get(template_handle,'Userdata');
for h = [template.nodehandles template.linehandles] 
   delete(h);
   end
