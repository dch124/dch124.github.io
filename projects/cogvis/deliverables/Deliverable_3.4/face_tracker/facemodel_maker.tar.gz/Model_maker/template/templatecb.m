function templatecb(action)

% changeflag:	0 no change
%					1 moved vertices
%					2 new or deleted structure
%
% mode:	1 normal(move)
%			2 add nodes
%			3 add line

global TEMPLATE_HANDLE

h = get(gco, 'Userdata');
template = get(h, 'Userdata');

switch action
   
case 'nodedown'
   % template node selected, so get ready to take action on button up
   % if mode=2 do nothing (new node mode)
   mode = template.mode;
   if mode == 1 & strcmp(get(gcf,'SelectionType'),'normal')	% move-node mode
      set(gcbf, 'WindowButtonMotionFcn', 'templatecb move')
      set(gcbf, 'WindowButtonUpFcn', 'templatecb stopmove')
      for hh = [template.linehandles template.nodehandles]
         set(hh, 'EraseMode', 'xor')
      end
      
      
   elseif mode == 3		% new line mode
      set(gcbf, 'WindowButtonUpFcn', 'templatecb addknot')
   end
   
case 'addknot'
   
   if strcmp(get(gcbf, 'SelectionType'), 'open')
      % double-click so complete line (final knot on first click) 
      template.mode = 1;		% back to move mode
      set(h,'Userdata',template)
      template_addline(h,template.newknots)
   else
      index = find(gco==template.nodehandles);
      template.newknots = [template.newknots index];
      set(h,'Userdata',template)
   end
   set(gcbf, 'WindowButtonUpFcn', '')  	% only runs following nodedown 
   
case 'addnode'
   % gco is the figure handle, so get template handle from global
   h = TEMPLATE_HANDLE;
   template = get(h, 'Userdata');
   if strcmp(get(gcbf, 'SelectionType'), 'open')
      % double-click so stop adding new nodes (final node on first click)
      template.mode = 1;
      set(gcbf, 'WindowButtonUpFcn', '')
      set(h,'Userdata',template)
   else
      currPt=get(gca, 'CurrentPoint');
      x = currPt(1,1);
      y = currPt(1,2);
      template_addnode(h,[x ; y])
   end
   
   
case 'delete'
   % so far incomplete
   index = find(gco==template.nodehandles);
   if isempty(index)	% this is a line
      % not yet implemented
   else	% this is a node
	'delete ok'
      template_deletenode(h, index)
   end
   
case 'properties'
   index = find(gco==template.nodehandles);
   if isempty(index)	% this is a line
      % not yet implemented
   else	% this is a node
      msgbox(['Index: ', int2str(index)])
   end

   
case 'move'
   currPt=get(gca, 'CurrentPoint');
   x = currPt(1,1);
   y = currPt(1,2);
   set(gco, 'XData', x)
   set(gco, 'YData', y)
   
   knotindex = find(gco==template.nodehandles);
   template.nodes(1, knotindex) = x;
   template.nodes(2, knotindex) = y;     
   
   for lineindex=1:length(template.lines)
      aline = template.lines(lineindex);
      % is the knot used for this line
      if ismember(knotindex, aline{1})
         linehandle = template.linehandles(lineindex);
         nSS = size(get(linehandle,'XData'),2);
         yy = linepoints_new(template.nodes, aline{1}, nSS);
         set(linehandle, 'XData', yy(1,:), 'YData', yy(2,:))
      end
   end  
   
   set(h,'Userdata',template)
   
case 'startnewline'
   template.mode = 3;
   % stop lines picking up button down
   %for h=template.linehandles
   %   set(h, 'HitTest', 'off')
   %end
   template.newknots = [];      
   set(h,'Userdata',template)  
   
case 'startnewnodes'
   template.mode = 2;
   set(gcbf, 'WindowButtonUpFcn', 'templatecb addnode')
   set(h,'Userdata',template)
   TEMPLATE_HANDLE = h;		% store here during addition of new nodes
   
case 'stopmove'
   set(gcbf, 'WindowButtonMotionFcn', '')
   set(gcbf, 'WindowButtonUpFcn', '')
   for hh = [template.linehandles template.nodehandles]
      set(hh, 'EraseMode', 'normal')
   end
   
   template.changeflag = max(template.changeflag, 1);
   set(h,'Userdata',template)  
end
