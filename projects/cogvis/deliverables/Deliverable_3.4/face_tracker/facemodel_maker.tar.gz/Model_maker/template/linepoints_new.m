function points = linepoints_new(nodes, indices, n)
% generate n points along spline defined by indexed sequence of nodes

nindices = size(indices,2);

if indices(1) == indices(end)
     % circular spline
%'circular spline'
to_spline=create_to_spline(nindices-1,nindices-1);
from_spline=create_from_spline(nindices-1,n/(nindices-1));

ctrls=nodes(:, indices(1:nindices-1));
ctrls2=to_spline_ctrls(ctrls,to_spline);
points=transpose(from_spline_boundary(ctrls2,from_spline));
else
% non circular spline
%'non circular spline'

from_spline=create_from_spline(nindices,n/(nindices-1));
to_spline=create_to_spline(nindices,nindices);

   ctrls = nodes(:, indices);
   ctrls2 = to_spline_ctrls(ctrls,to_spline);
   bndry = from_spline_boundary(ctrls2,from_spline);
   points=transpose(bndry(1:n,:));
   end
