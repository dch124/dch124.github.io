function template_deletenode(template_handle, index)
template = get(template_handle,'Userdata');
nnodes = size(template.nodes,2);
if nnodes==1, break, end		% don't allow deletion of final node
other_indices = [1:index-1, index+1:nnodes];
template.nodes = template.nodes(:,other_indices);

delete(template.nodehandles(index));
template.nodehandles = template.nodehandles(other_indices);

newlines = {};
newlinehandles = [];
for lineindex=1:length(template.lines)
   linehandle = template.linehandles(lineindex); 
   aline = template.lines(lineindex);
   % remove knot from this line if there
   aline = aline{1};
   aline = aline(find(index~=aline));
   if length(aline) < 2
      % delete the line
      delete(linehandle)
   else
      % reduce indices for all nodes above index, adjust line and save
      aline = aline -(aline > index);
      
      yy = linepoints_new(template.nodes, aline, 20);
      set(linehandle, 'XData', yy(1,:), 'YData', yy(2,:))

      newlines = {newlines{:} aline};
      newlinehandles = [newlinehandles linehandle];       
   end
end  
template.lines = newlines;
template.linehandles = newlinehandles;
template.changeflag = 2;		% to signify changed structure
set(template_handle, 'UserData', template)

