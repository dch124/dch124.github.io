function template_handle = template(nodes, lines);

cmenu_handle = uicontextmenu;
uimenu(cmenu_handle, 'Label', 'Delete', 'Callback', 'templatecb delete')
uimenu(cmenu_handle, 'Label', 'Add Node', 'Callback', 'templatecb startnewnodes')
uimenu(cmenu_handle, 'Label', 'Add Line', 'Callback', 'templatecb startnewline')
uimenu(cmenu_handle, 'Label', 'Properties', 'Callback', 'templatecb properties')

% starting a new template
template = [];
template.nodes = [];
template.lines = {};
template.nodehandles = [];
template.linehandles = [];
template.mode = 1;				% start in move mode
template.cmenu = cmenu_handle;
template.changeflag = 0;

% create dummy line to represent template (makes it behave like a graphics object)
template_handle = line('Xdata',[],'Ydata',[], 'Userdata', template);

for node = nodes
   template_addnode(template_handle, node)
end

for line = lines
   template_addline(template_handle, line{1})
end

% set this here since set as structure added
template = get(template_handle,'Userdata');
template.changeflag = 0;
set(template_handle, 'Userdata', template)

