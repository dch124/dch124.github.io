function template_addnode(template_handle, node)

template = get(template_handle,'Userdata');

nnodes = size(template.nodes,2);
h = line(node(1), node(2), 1.5, 'Color', 'r', 'Marker', 'o', ...
   'UIContextMenu', template.cmenu, 'ButtonDownFcn', 'templatecb nodedown', ...
   'EraseMode', 'normal', 'UserData', template_handle, ...
   'MarkerFaceColor', 'r', 'MarkerSize', 2);

template.nodes = [template.nodes node];
template.nodehandles = [template.nodehandles h(1)];
template.changeflag = 2;

set(template_handle, 'Userdata', template);


