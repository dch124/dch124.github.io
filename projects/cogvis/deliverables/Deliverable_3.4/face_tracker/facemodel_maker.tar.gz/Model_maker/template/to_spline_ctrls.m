function ctrls = to_spline_ctrls ( pnts, to_spline)
% fills `ctrls' with the `nctrls' ctrl points of the cubic B-spline
% representing the boundary given by the `npnts' held in `pnts' ...
% NOTE: ctrls must be double[nctrls][2] ;-)

X=zeros(to_spline.nctrls,1);
Y=zeros(to_spline.nctrls,1);

for j=1:to_spline.nctrls
	for i=1:to_spline.npnts
		tmp=b_func(j,to_spline.u(i),to_spline);
		X(j)=X(j)+tmp*pnts(1,i);	
		Y(j)=Y(j)+tmp*pnts(2,i);	
	end
end

X_res=fwd_bck_sub(to_spline,X);
Y_res=fwd_bck_sub(to_spline,Y);


ctrls(1,:)=transpose(X_res);
ctrls(2,:)=transpose(Y_res);





