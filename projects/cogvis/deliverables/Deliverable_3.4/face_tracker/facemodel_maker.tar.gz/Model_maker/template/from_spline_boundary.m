function pnts= from_spline_boundary ( ctrls, from_spline)

% return points along the boundary of the cubic B-spline
% defined by the `nctrls' ctrl points held in `ctrls' ...

pnts=zeros(ceil(from_spline.nsteps*from_spline.nctrls),2);
s_step=1/from_spline.nsteps;

for i=1:from_spline.nctrls
	for j=1:ceil(from_spline.nsteps)

		s=(j-1)*s_step;
		s_2=s*s;
		s_3=s_2*s;


		pnts(fix((i-1)*from_spline.nsteps+j),1)=(1-s_3+3*s_2-3*s) * ctrls(1,i) + (3*s_3-6*s_2+4) * ctrls(1,1+mod((i),from_spline.nctrls)) + (-3*s_3+3*s_2+3*s+1) * ctrls(1,1+mod((i+1),from_spline.nctrls)) + (s_3) * ctrls(1,1+mod((i+2),from_spline.nctrls));

		pnts(fix((i-1)*from_spline.nsteps+j),1) = pnts(fix((i-1)*from_spline.nsteps+j),1) /6.0;

		pnts(fix((i-1)*from_spline.nsteps+j),2) = (1-s_3+3*s_2-3*s)    * ctrls(2,i) + (3*s_3-6*s_2+4)      * ctrls(2,1+mod((i),from_spline.nctrls)) + (-3*s_3+3*s_2+3*s+1) * ctrls(2,1+mod((i+1),from_spline.nctrls)) + (s_3)        * ctrls(2,1+mod((i+2),from_spline.nctrls));

		pnts(fix((i-1)*from_spline.nsteps+j),2) = pnts(fix((i-1)*from_spline.nsteps+j),2)/6.0;

	end
end

