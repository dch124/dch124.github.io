function template_addline(template_handle, aline)
% HitTest must be off to allow selection of vertices.  Thus, context menu doesn't work

template = get(template_handle,'Userdata');

nSS = 6 * length(aline);		% scale number of intertpolated points by complexity

yy = linepoints_new(template.nodes, aline, nSS);

% erase mode 'normal' gives better lines but worse update
h  = line(yy(1,:),yy(2,:), ones(1,nSS), 'Color', 'w', 'EraseMode',...
   'normal','LineWidth', 0.5, 'HitTest', 'off', 'UIContextMenu', template.cmenu,...
   'Userdata', template_handle);

template.lines = {template.lines{:} aline};
template.linehandles = [template.linehandles h];
template.changeflag = 2;

set(template_handle, 'Userdata', template);


