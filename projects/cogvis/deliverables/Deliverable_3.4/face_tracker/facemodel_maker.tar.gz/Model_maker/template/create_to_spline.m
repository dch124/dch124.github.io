function to_spline=create_to_spline(ctrls,pnts)

to_spline.nctrls=ctrls;
to_spline.npnts=pnts;
to_spline.M=zeros(ctrls,ctrls);
to_spline.indxs=zeros(ctrls,1);

for i=1:pnts
	to_spline.u(i)=ctrls*(i+1)/pnts;
end

for j=1:ctrls
	for k=1:ctrls
		for i=1:pnts
		to_spline.M(j,k)=to_spline.M(j,k)+b_func(j,to_spline.u(i),to_spline) * b_func(k,to_spline.u(i),to_spline);
		end
	end
end

%lu_decomp :

for i=1:ctrls
	big=0;
	for j=1:ctrls
		temp=abs(to_spline.M(i,j));
		if (temp>big)
			big=temp;
		end
	end
	if (big==0)
	'warning : singular matrix in lu_decomp'
	end
	vv(i)=1/big;
end

for j=1:ctrls
	for i=1:j-1
		sum=to_spline.M(i,j);
		for k=1:i-1
			sum=sum-to_spline.M(i,k)*to_spline.M(k,j);
		end	
		to_spline.M(i,j)=sum;
		
	end
	big=0;
	for i=j:ctrls
		sum=to_spline.M(i,j);
		for k=1:j-1
			sum=sum-to_spline.M(i,k)*to_spline.M(k,j);
		end
		to_spline.M(i,j)=sum;
		dum=vv(i)*abs(sum);
		if (dum>=big)
			big=dum;
			imax=i;
		end
	end
	if (j~=imax)
		for k=1:ctrls
			dum=to_spline.M(imax,k);
			to_spline.M(imax,k)=to_spline.M(j,k);
			to_spline.M(j,k)=dum;
		end
		vv(imax)=vv(j);
	end
	to_spline.indxs(j)=imax;
	if (to_spline.M(j,j)==0)
		to_spline.M(j,j)=-inf;
	end
	if (j~=ctrls+1)
		dum=1/to_spline.M(j,j);
		for i=j+1:ctrls
			to_spline.M(i,j)=to_spline.M(i,j)*dum;
		end
	end
end



