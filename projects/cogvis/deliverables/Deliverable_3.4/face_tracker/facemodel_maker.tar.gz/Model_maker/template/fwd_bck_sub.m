function res = fwd_bck_sub (sp,X)
% fwd_bck_sub
% X=fwd_bck_sub(to_spline,X);

res=X;
ii=0;

for i=1:sp.nctrls
	ip=sp.indxs(i);
	sum=res(ip);
	res(ip)=res(i);
	if(ii~=0)
		for j=ii:i-1
			sum=sum-sp.M(i,j)*res(j);
		end
	elseif (sum)
		ii=i;
	end
	res(i)=sum;
end

for i=sp.nctrls:-1:1
	sum=res(i);
	for j=i+1:sp.nctrls
		sum=sum-sp.M(i,j)*res(j);
	end
	res(i)=sum/sp.M(i,i);
end
