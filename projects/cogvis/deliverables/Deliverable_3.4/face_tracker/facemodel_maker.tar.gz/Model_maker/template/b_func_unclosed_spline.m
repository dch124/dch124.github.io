function result= b_func_unclosed_spline.m(i,u,to_spline)

tmp=u-i-2;
if tmp<1
tmp=tmp+to_spline.nctrls;
elseif tmp>=to_spline.nctrls
	tmp=tmp-to_spline.nctrls;
end
v=tmp - floor(tmp);

if tmp >=5
	result=0;
elseif tmp<2
	result=v*v*v/6;
elseif tmp <3
	result=(1.0+3.0*v*(1.0+v*(1.0-v)))/6;
elseif tmp <4
	result=(4.0+3.0*v*v*(v-2.0))/6;
else result=(1.0+v*(3.0*(v-1.0)-v*v))/6;
end


