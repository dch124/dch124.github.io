function [vertices, lines, changeflag] = templatedata(template_handle);

template = get(template_handle, 'Userdata');
vertices = template.nodes;
lines = template.lines;
changeflag = template.changeflag;
template.changeflag = 0;		% reset change flag
set(template_handle, 'Userdata', template);