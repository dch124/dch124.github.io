function points = templatepoints(vertices, lines, nSS)

[ncomps, nvertices] = size(vertices);

% first include those vertices not appearing on a line
alone_points = vertices(:,setdiff(1:nvertices, [lines{:}]));
nalone = size(alone_points,2);

% allocate output matrix
nlines = length(lines);
points = zeros(ncomps,nalone+nSS*nlines);
points(:,1:nalone) = alone_points;

i = nalone+1;
for aline = lines;
   points(:,i:i+nSS-1) = linepoints_new(vertices, aline{1}, nSS);
   i = i+nSS;
end
