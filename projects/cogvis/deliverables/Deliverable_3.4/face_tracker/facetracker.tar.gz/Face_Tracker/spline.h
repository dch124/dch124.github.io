// ****************************************************************************
// File : netwatch/src/classes/spline.h
// Author : Neil Johnson
// Description :
// 
//   Include file for classes ToSpline and FromSpline
// ****************************************************************************

#ifndef _SPLINE_
#define _SPLINE_

// ****************************************************************************

#define TINY 1.0E-300 // small but larger than DBL_MIN

// ****************************************************************************

// Declaration of class ToSpline ...

class ToSpline {

  int nctrls;
  int npnts;

  double *u;
  double **M;
  double *X;
  double *Y;
  int *indxs;

  double b_func(int i, double u);
  void lu_decomp(double **a, int n, int *indx);
  void fwd_bck_sub(double **a, int n, int *indx, double *b);

public:

  ToSpline(int ctrls, int pnts);
  void ctrls(double pnts[][2], double ctrls[][2]);
  ~ToSpline();

};

// ****************************************************************************

// Declaration of class FromSpline ...

class FromSpline {

  int nctrls;
  double nsteps;

public:

  FromSpline(int ctrls, double steps) :nctrls(ctrls), nsteps(steps) {};
  void boundary(double ctrls[][2], double pnts[][2]);

};

#endif
