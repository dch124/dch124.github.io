// ****************************************************************************
// Author : Vincent Devin
// Description :
// date : 05/09/2000
//
// PCA_container.h
// ****************************************************************************

class PCA_container
{
 protected:

  int nbr_comp;
  int size;
  double * vector;
  double * result;
  double * M;
  double * E;
  double * L;

  public :

  // constructor

  PCA_container(char *matlab_file);

  //destructor

  ~PCA_container();

  void display_M();
  void display_E();
  void display_L();

  int get_nbr_comp();
  double * get_moy() { return M;}

  double get_eigenval_comp(int i) {return L[i];}


  int get_size();

  double * fromsubspace(double * V, int s);
  double * fromsubspace_raw(double * V, int s);
  double * fromsubspace_raw(double * V,int s, double * moy);
  double Compute_residus_color(unsigned char * V,int s);
  double Compute_residus(unsigned char * V,int s);
  double * tosubspace(double * V,int s);
  double * tosubspace(double * V,int s,double * Moy);
  double * tosubspace_color(unsigned char * V,int s);
  double * tosubspace_grey(unsigned char * V,int s);
  double * tosubspace_grey(unsigned char * V,int s,int beg, int end);


};
