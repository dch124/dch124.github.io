:- set(posonly)?
:- set(c,8)?
:- set(r,1000)?
:- set(nodes,500)?
:- set(h,2000)?
object(c0).object(c1).object(c2).object([]).
phrase(s_1).phrase(s_2).phrase(s_3).phrase(s_4).phrase(s_5).
player(p0).player(p1).

:- modeh(1,action(#player,#phrase,+(time)))?
:- modeb(*,state([[-(object),#player],[-(object),#player]],+(time)))?
:- modeb(*,state([],+(time)))?
:- modeb(*,successor(-(time),+(time)))?
time(dg1_4_301).
time(dg1_4_340).
successor(dg1_4_340,dg1_4_301).
state([c0],dg1_4_340).
