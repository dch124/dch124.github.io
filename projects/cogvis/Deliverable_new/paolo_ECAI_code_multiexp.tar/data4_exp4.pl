:- set(posonly)?
:- set(c,10)?
:- set(r,2000)?
:- set(i,3)?
:- set(h,1000)?
:- modeh(1,trans([+face,+face],[+face],+time,+time))?
:- modeh(1,trans([+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face],[+face],+time,+time))?
:- modeb(100,successor(-time,-time))?
:- modeb(100,state([+face],-time))?
:- consult(rules)?
:- generalise(trans/4)?

face(c0).
face(c1).
face(c2).
face(c3).
face(c4).
face(c5).
face(nil).

trans([A],[B],C,D) :- successor(D,C).
trans([A],[B,C],D,E) :- successor(E,D).
trans([A,B],[C],D,E) :- successor(E,D).

time(dg1_4_301).
time(dg1_4_340).
time(dg1_4_359).
time(dg1_4_377).
time(dg1_4_393).
time(dg1_4_412).
time(dg1_4_430).
time(dg1_4_452).
time(dg1_4_469).
time(dg1_4_494).
time(dg1_4_516).
time(dg1_4_539).
time(dg1_4_557).
time(dg1_4_577).
time(dg1_4_601).
time(dg1_4_616).
time(dg1_4_635).
time(dg1_4_652).
time(dg1_4_671).
time(dg1_4_688).
time(dg1_4_705).
time(dg1_4_720).
time(dg1_4_742).
time(dg1_4_760).
time(dg1_4_785).
time(dg1_4_805).
time(dg1_4_824).
time(dg1_4_845).
time(dg1_4_863).
time(dg1_4_876).
time(dg1_4_892).
time(dg1_4_907).
time(dg1_4_930).
time(dg1_4_953).
time(dg1_4_972).
time(dg1_4_992).
time(dg1_4_1015).
time(dg1_4_1038).
time(dg1_4_1058).
time(dg1_4_1082).
time(dg1_4_1101).
time(dg1_4_1119).
time(dg1_4_1141).
time(dg1_4_1162).
time(dg1_4_1188).
time(dg1_4_1207).
time(dg1_4_1229).
time(dg1_4_1251).
time(dg1_4_1270).
time(dg1_4_1286).
time(dg1_4_1304).
time(dg1_4_1328).
time(dg1_4_1345).
time(dg1_4_1363).
time(dg1_4_1376).

'*trans'([A,B],[C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A],[B,C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A,B],[C,D],E,F) :- face(A), face(B), face(C), face(D),
	time(E), time(F).
'*trans'([A],[B],C,D) :- face(A), face(B), time(C), time(D).

successor(dg1_4_340,dg1_4_301).
successor(dg1_4_359,dg1_4_340).
successor(dg1_4_377,dg1_4_359).
successor(dg1_4_393,dg1_4_377).
successor(dg1_4_412,dg1_4_393).
successor(dg1_4_430,dg1_4_412).
successor(dg1_4_452,dg1_4_430).
successor(dg1_4_469,dg1_4_452).
successor(dg1_4_494,dg1_4_469).
successor(dg1_4_516,dg1_4_494).
successor(dg1_4_539,dg1_4_516).
successor(dg1_4_557,dg1_4_539).
successor(dg1_4_577,dg1_4_557).
successor(dg1_4_601,dg1_4_577).
successor(dg1_4_616,dg1_4_601).
successor(dg1_4_635,dg1_4_616).
successor(dg1_4_652,dg1_4_635).
successor(dg1_4_671,dg1_4_652).
successor(dg1_4_688,dg1_4_671).
successor(dg1_4_705,dg1_4_688).
successor(dg1_4_720,dg1_4_705).
successor(dg1_4_742,dg1_4_720).
successor(dg1_4_760,dg1_4_742).
successor(dg1_4_785,dg1_4_760).
successor(dg1_4_805,dg1_4_785).
successor(dg1_4_824,dg1_4_805).
successor(dg1_4_845,dg1_4_824).
successor(dg1_4_863,dg1_4_845).
successor(dg1_4_876,dg1_4_863).
successor(dg1_4_892,dg1_4_876).
successor(dg1_4_907,dg1_4_892).
successor(dg1_4_930,dg1_4_907).
successor(dg1_4_953,dg1_4_930).
successor(dg1_4_972,dg1_4_953).
successor(dg1_4_992,dg1_4_972).
successor(dg1_4_1015,dg1_4_992).
successor(dg1_4_1038,dg1_4_1015).
successor(dg1_4_1058,dg1_4_1038).
successor(dg1_4_1082,dg1_4_1058).
successor(dg1_4_1101,dg1_4_1082).
successor(dg1_4_1119,dg1_4_1101).
successor(dg1_4_1141,dg1_4_1119).
successor(dg1_4_1162,dg1_4_1141).
successor(dg1_4_1188,dg1_4_1162).
successor(dg1_4_1207,dg1_4_1188).
successor(dg1_4_1229,dg1_4_1207).
successor(dg1_4_1251,dg1_4_1229).
successor(dg1_4_1270,dg1_4_1251).
successor(dg1_4_1286,dg1_4_1270).
successor(dg1_4_1304,dg1_4_1286).
successor(dg1_4_1328,dg1_4_1304).
successor(dg1_4_1345,dg1_4_1328).
successor(dg1_4_1363,dg1_4_1345).
successor(dg1_4_1376,dg1_4_1363).
successor(dg1_4_1394,dg1_4_1376).
