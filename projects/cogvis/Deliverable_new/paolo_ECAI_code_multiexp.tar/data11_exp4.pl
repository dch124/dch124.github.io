:- set(posonly)?
:- set(c,10)?
:- set(r,2000)?
:- set(i,3)?
:- set(h,1000)?
:- modeh(1,trans([+face,+face],[+face],+time,+time))?
:- modeh(1,trans([+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face],[+face],+time,+time))?
:- modeb(100,successor(-time,-time))?
:- modeb(100,state([+face],-time))?
:- consult(rules)?
:- generalise(trans/4)?

face(c0).
face(c1).
face(c2).
face(c3).
face(c4).
face(c5).
face(nil).

trans([A],[B],C,D) :- successor(D,C).
trans([A,B],[C],D,E) :- successor(E,D).
trans([A],[B,C],D,E) :- successor(E,D).

time(dg1_11_301).
time(dg1_11_328).
time(dg1_11_352).
time(dg1_11_376).
time(dg1_11_401).
time(dg1_11_424).
time(dg1_11_445).
time(dg1_11_467).
time(dg1_11_489).
time(dg1_11_510).
time(dg1_11_535).
time(dg1_11_562).
time(dg1_11_585).
time(dg1_11_606).
time(dg1_11_623).
time(dg1_11_644).
time(dg1_11_667).
time(dg1_11_686).
time(dg1_11_704).
time(dg1_11_734).
time(dg1_11_754).
time(dg1_11_775).
time(dg1_11_798).
time(dg1_11_823).
time(dg1_11_837).
time(dg1_11_852).
time(dg1_11_872).
time(dg1_11_889).
time(dg1_11_907).
time(dg1_11_922).
time(dg1_11_944).
time(dg1_11_964).
time(dg1_11_984).
time(dg1_11_1008).
time(dg1_11_1035).
time(dg1_11_1053).
time(dg1_11_1078).
time(dg1_11_1096).
time(dg1_11_1118).
time(dg1_11_1138).
time(dg1_11_1160).
time(dg1_11_1178).
time(dg1_11_1197).
time(dg1_11_1216).
time(dg1_11_1241).
time(dg1_11_1261).
time(dg1_11_1274).
time(dg1_11_1295).
time(dg1_11_1313).
time(dg1_11_1331).
time(dg1_11_1348).
time(dg1_11_1370).
time(dg1_11_1389).
time(dg1_11_1414).
time(dg1_11_1429).
time(dg1_11_1446).
time(dg1_11_1473).
time(dg1_11_1492).
time(dg1_11_1508).
time(dg1_11_1526).
time(dg1_11_1543).

'*trans'([A,B],[C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A],[B,C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A,B],[C,D],E,F) :- face(A), face(B), face(C), face(D),
	time(E), time(F).
'*trans'([A],[B],C,D) :- face(A), face(B), time(C), time(D).

successor(dg1_11_328,dg1_11_301).
successor(dg1_11_352,dg1_11_328).
successor(dg1_11_376,dg1_11_352).
successor(dg1_11_401,dg1_11_376).
successor(dg1_11_424,dg1_11_401).
successor(dg1_11_445,dg1_11_424).
successor(dg1_11_467,dg1_11_445).
successor(dg1_11_489,dg1_11_467).
successor(dg1_11_510,dg1_11_489).
successor(dg1_11_535,dg1_11_510).
successor(dg1_11_562,dg1_11_535).
successor(dg1_11_585,dg1_11_562).
successor(dg1_11_606,dg1_11_585).
successor(dg1_11_623,dg1_11_606).
successor(dg1_11_644,dg1_11_623).
successor(dg1_11_667,dg1_11_644).
successor(dg1_11_686,dg1_11_667).
successor(dg1_11_704,dg1_11_686).
successor(dg1_11_734,dg1_11_704).
successor(dg1_11_754,dg1_11_734).
successor(dg1_11_775,dg1_11_754).
successor(dg1_11_798,dg1_11_775).
successor(dg1_11_823,dg1_11_798).
successor(dg1_11_837,dg1_11_823).
successor(dg1_11_852,dg1_11_837).
successor(dg1_11_872,dg1_11_852).
successor(dg1_11_889,dg1_11_872).
successor(dg1_11_907,dg1_11_889).
successor(dg1_11_922,dg1_11_907).
successor(dg1_11_944,dg1_11_922).
successor(dg1_11_964,dg1_11_944).
successor(dg1_11_984,dg1_11_964).
successor(dg1_11_1008,dg1_11_984).
successor(dg1_11_1035,dg1_11_1008).
successor(dg1_11_1053,dg1_11_1035).
successor(dg1_11_1078,dg1_11_1053).
successor(dg1_11_1096,dg1_11_1078).
successor(dg1_11_1118,dg1_11_1096).
successor(dg1_11_1138,dg1_11_1118).
successor(dg1_11_1160,dg1_11_1138).
successor(dg1_11_1178,dg1_11_1160).
successor(dg1_11_1197,dg1_11_1178).
successor(dg1_11_1216,dg1_11_1197).
successor(dg1_11_1241,dg1_11_1216).
successor(dg1_11_1261,dg1_11_1241).
successor(dg1_11_1274,dg1_11_1261).
successor(dg1_11_1295,dg1_11_1274).
successor(dg1_11_1313,dg1_11_1295).
successor(dg1_11_1331,dg1_11_1313).
successor(dg1_11_1348,dg1_11_1331).
successor(dg1_11_1370,dg1_11_1348).
successor(dg1_11_1389,dg1_11_1370).
successor(dg1_11_1414,dg1_11_1389).
successor(dg1_11_1429,dg1_11_1414).
successor(dg1_11_1446,dg1_11_1429).
successor(dg1_11_1473,dg1_11_1446).
successor(dg1_11_1492,dg1_11_1473).
successor(dg1_11_1508,dg1_11_1492).
successor(dg1_11_1526,dg1_11_1508).
successor(dg1_11_1543,dg1_11_1526).
successor(dg1_11_1565,dg1_11_1543).
