%% Paulo Santos 26/02/04
%% e-mail: psantos@comp.leeds.ac.uk



% This program puts everything together: learn5, rloop5, count4.

% libraries needed overall:

:- use_module(library(system)).
:- use_module(library(charsio)).
:- use_module(library(lists)).
:- use_module(library(terms)).


% dat(X,[FileList]) is used to chose the data set


%dat(dice,[allData]).

dat(dice,[data4,data6,data7,data8,data9,data10,data11,data12]).

%dat(snap,[pss_snap3i]).

%dat(snap,[pss_snap3i,pss_snap4i,pss_snap5i]).

%,pss_snap6i,pss_snap7i,pss_snap8i]).




% run(Game, Aset): Game is 'dice' or 'snap', Aset is the final answer set

% initialise is the program initialisations defined on the learn.pl families

run(Game,ASet,S):-
    dat(Game,DataF),
    [learn6ILP],
    [count4],
    initialise,
    pickLearn(DataF),
    as(IAnSet),
    sweep(IAnSet,ASet1),
    qs(ASet1,ASet),
    statistics(runtime,S),
    testFile(IAnSet, ASet, 'test.dat'), !.


    
% picks up each input data file name and calls learn/1

pickLearn([IFile|Files]):-
    learn(IFile),
    pickLearn(Files).
    
pickLearn([]).    


% testFile/0: writes the file test with the input and output answer set 
%             may be used to verify individual answer sets

testFile(IAnSet, ASet, FILENAME):-
    tell(FILENAME),
    writeASet(IAnSet),
    nl,nl,
    writeASet(ASet),
    told.

% writeASet/1 writes in a human readable mode. Use write for machine readable output!

writeASet([I|Is]):-
   portray_clause(I),nl,
  writeASet(Is).


writeASet([]).


% quick sort

qs([], []).
qs([X|Xs], Ys) :-
        part(X, Xs, Littles, Bigs),
        qs(Littles, Ls),
        qs(Bigs, Bs),
        append(Ls, [X | Bs], Ys).


%part(X, Xs, Ls, Bs) :- Ls is a list of elements of Xs which are < X, 
%                       Bs is a list of elements of Xs which are >= X.

part(_, [], [], []).
part((X1,N1), [(X2,N2) | Xs], [(X2,N2) | Ls], Bs) :- 
    N1 < N2, 
    part((X1,N1), Xs, Ls, Bs).

part((X1,N1), [(X2,N2) | Xs], Ls, [(X2,N2) | Bs]) :- 
    N1 >= N2, 
    part((X1,N1), Xs, Ls, Bs).
