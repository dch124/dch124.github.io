:- set(posonly)?
:- set(c,10)?
:- set(r,2000)?
:- set(i,3)?
:- set(h,1000)?
:- modeh(1,trans([+face,+face],[+face],+time,+time))?
:- modeh(1,trans([+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face],[+face],+time,+time))?
:- modeb(100,successor(-time,-time))?
:- modeb(100,state([+face],-time))?
:- consult(rules)?
:- generalise(trans/4)?

face(c0).
face(c1).
face(c2).
face(c3).
face(c4).
face(c5).
face(nil).

trans([A],[B],C,D) :- successor(D,C).
trans([A],[B,C],D,E) :- successor(E,D).
trans([A,B],[C],D,E) :- successor(E,D).

time(dg1_10_301).
time(dg1_10_334).
time(dg1_10_348).
time(dg1_10_377).
time(dg1_10_391).
time(dg1_10_412).
time(dg1_10_431).
time(dg1_10_448).
time(dg1_10_469).
time(dg1_10_493).
time(dg1_10_517).
time(dg1_10_538).
time(dg1_10_559).
time(dg1_10_577).
time(dg1_10_591).
time(dg1_10_607).
time(dg1_10_621).
time(dg1_10_644).
time(dg1_10_662).
time(dg1_10_681).
time(dg1_10_703).
time(dg1_10_723).
time(dg1_10_743).
time(dg1_10_764).
time(dg1_10_788).
time(dg1_10_807).
time(dg1_10_826).
time(dg1_10_849).
time(dg1_10_865).
time(dg1_10_887).
time(dg1_10_907).
time(dg1_10_926).
time(dg1_10_945).
time(dg1_10_965).
time(dg1_10_982).
time(dg1_10_1004).
time(dg1_10_1029).
time(dg1_10_1053).
time(dg1_10_1069).
time(dg1_10_1087).
time(dg1_10_1100).
time(dg1_10_1119).
time(dg1_10_1135).
time(dg1_10_1152).
time(dg1_10_1166).
time(dg1_10_1185).
time(dg1_10_1206).
time(dg1_10_1228).
time(dg1_10_1248).
time(dg1_10_1272).
time(dg1_10_1288).
time(dg1_10_1304).
time(dg1_10_1324).
time(dg1_10_1338).
time(dg1_10_1353).
time(dg1_10_1371).
time(dg1_10_1385).
time(dg1_10_1404).
time(dg1_10_1426).
time(dg1_10_1440).
time(dg1_10_1455).
time(dg1_10_1477).
time(dg1_10_1495).
time(dg1_10_1516).
time(dg1_10_1532).
time(dg1_10_1549).
time(dg1_10_1567).
time(dg1_10_1586).
time(dg1_10_1602).
time(dg1_10_1615).
time(dg1_10_1632).
time(dg1_10_1646).

'*trans'([A,B],[C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A],[B,C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A,B],[C,D],E,F) :- face(A), face(B), face(C), face(D),
	time(E), time(F).
'*trans'([A],[B],C,D) :- face(A), face(B), time(C), time(D).

successor(dg1_10_334,dg1_10_301).
successor(dg1_10_348,dg1_10_334).
successor(dg1_10_377,dg1_10_348).
successor(dg1_10_391,dg1_10_377).
successor(dg1_10_412,dg1_10_391).
successor(dg1_10_431,dg1_10_412).
successor(dg1_10_448,dg1_10_431).
successor(dg1_10_469,dg1_10_448).
successor(dg1_10_493,dg1_10_469).
successor(dg1_10_517,dg1_10_493).
successor(dg1_10_538,dg1_10_517).
successor(dg1_10_559,dg1_10_538).
successor(dg1_10_577,dg1_10_559).
successor(dg1_10_591,dg1_10_577).
successor(dg1_10_607,dg1_10_591).
successor(dg1_10_621,dg1_10_607).
successor(dg1_10_644,dg1_10_621).
successor(dg1_10_662,dg1_10_644).
successor(dg1_10_681,dg1_10_662).
successor(dg1_10_703,dg1_10_681).
successor(dg1_10_723,dg1_10_703).
successor(dg1_10_743,dg1_10_723).
successor(dg1_10_764,dg1_10_743).
successor(dg1_10_788,dg1_10_764).
successor(dg1_10_807,dg1_10_788).
successor(dg1_10_826,dg1_10_807).
successor(dg1_10_849,dg1_10_826).
successor(dg1_10_865,dg1_10_849).
successor(dg1_10_887,dg1_10_865).
successor(dg1_10_907,dg1_10_887).
successor(dg1_10_926,dg1_10_907).
successor(dg1_10_945,dg1_10_926).
successor(dg1_10_965,dg1_10_945).
successor(dg1_10_982,dg1_10_965).
successor(dg1_10_1004,dg1_10_982).
successor(dg1_10_1029,dg1_10_1004).
successor(dg1_10_1053,dg1_10_1029).
successor(dg1_10_1069,dg1_10_1053).
successor(dg1_10_1087,dg1_10_1069).
successor(dg1_10_1100,dg1_10_1087).
successor(dg1_10_1119,dg1_10_1100).
successor(dg1_10_1135,dg1_10_1119).
successor(dg1_10_1152,dg1_10_1135).
successor(dg1_10_1166,dg1_10_1152).
successor(dg1_10_1185,dg1_10_1166).
successor(dg1_10_1206,dg1_10_1185).
successor(dg1_10_1228,dg1_10_1206).
successor(dg1_10_1248,dg1_10_1228).
successor(dg1_10_1272,dg1_10_1248).
successor(dg1_10_1288,dg1_10_1272).
successor(dg1_10_1304,dg1_10_1288).
successor(dg1_10_1324,dg1_10_1304).
successor(dg1_10_1338,dg1_10_1324).
successor(dg1_10_1353,dg1_10_1338).
successor(dg1_10_1371,dg1_10_1353).
successor(dg1_10_1385,dg1_10_1371).
successor(dg1_10_1404,dg1_10_1385).
successor(dg1_10_1426,dg1_10_1404).
successor(dg1_10_1440,dg1_10_1426).
successor(dg1_10_1455,dg1_10_1440).
successor(dg1_10_1477,dg1_10_1455).
successor(dg1_10_1495,dg1_10_1477).
successor(dg1_10_1516,dg1_10_1495).
successor(dg1_10_1532,dg1_10_1516).
successor(dg1_10_1549,dg1_10_1532).
successor(dg1_10_1567,dg1_10_1549).
successor(dg1_10_1586,dg1_10_1567).
successor(dg1_10_1602,dg1_10_1586).
successor(dg1_10_1615,dg1_10_1602).
successor(dg1_10_1632,dg1_10_1615).
successor(dg1_10_1646,dg1_10_1632).
successor(dg1_10_1665,dg1_10_1646).
