
% This is a SICSTUS meta-program that reads a data.pl file and writes multiple 
% other files with different kind of predicates constructed from data.pl.
% Each of these new files are, then, generalised according to progol induction 
% style.

% In its current incarnation it writes transitivity.pl and transI.pl for 
% searching recursive rules (transI.pl is an intermediate file) and rules.pl 
% and rulesI.pl for searching time dependent relations. Progol has to be called
% from the intermediate files so that the advise/1 predicates work.

% The result of the progol generalisations are put into the files tr.pl 
% and ru.pl as defined in the clauses write_rules and write_trans. 

% Responsible: Paulo E. Santos (pe_santos@yahoo.co.uk)

:- dynamic as/1.

:- use_module(library(system)).

% Initialisations, functions, settings

initialise:-
    [rloop4],
    retractall(as(_)),
    assert(as([])),
    prolog_flag(redefine_warnings,X,off).


% learn/2 gets a data set, writes the experiments and calls progol,
%         the answer set for each data set is asserted as argument of 
%         a dynamic predicate as/1. as/1 is updated with the new results 
%         by updateAs/1. as/1 is initiated with [] and is updated every time
%         learn is called.
%
%   FOR THE SAME KIND OF EXP. THE SAME as/1 CAN BE USED
%   FOR DIFFERENT KINDS IT HAS TO BE REFORMULATED



learn(InF,AdvI,AdvII):-
    [InF], 
    write_transI(AdvI),
%    write_transII(AdvII),
%    write_rules,
   popen('xterm -e progol transI',read,S1),
%    popen('xterm -e progol transII',read,S2),
%    popen('xterm -e progol rulesI',read,S3),
   close(S1),
%    close(S2),
%    close(S3),
    fileSuffix(AdvI,'.pl',Fname),
    filter(Fname,AsI),
    updateAs(AsI).

updateAs(As):-
    as(Prev),
    retract(as(Prev)),
    append(Prev,[As],List),
    assert(as(List)).
    
% fileSuffix/2 inserts the suffix .pl in the progol advised file name Adv

fileSuffix(Name,Suf,Fname):-
    atom_codes(Name,CodeList),
    atom_codes(Suf,SufList),
    append(CodeList,SufList,Cname),
    atom_codes(Fname,Cname),
    write(Fname).

% write experiments searching for recursive rules (without prunning)

write_transI(Adv):-
    tell('transitI.pl'),
    heading1,
    choose1,
    told,
    tell('transI.pl'),
    intermediateF(transitI,trans/2,Adv),
    told.

% writes experiments searching for recursive rules (with prunning)

write_transII(Adv):-
    tell('transitII.pl'),
    headingII,
    chooseII,
    told,
    tell('transII.pl'),
    intermediateF(transitII,trans/2,Adv),
    told.

% writes experiments searching for time-dependent rules

write_rules:-
    tell('rules.pl'),
    heading2,
    choose_Tr,
    chooseT,
    chooseSu,
    chooseSt,
    told,
    tell('rulesI.pl'),
    intermediateF(rules,trans/4,ru),
    told.

% needed in order to call progol in the interactive mode

intermediateF(In,Gen,Out):-
    write(':-consult('),
    write(In), write(')?'),nl,
    write(':-generalise('),
    write(Gen), write(')?'),nl,
    write(':-advise('),
    write(Out), write(')?'),nl.


% 'i' was set as 5, I'm now doing it 2
% the prune remains as before (20/01/04)

heading1:-
    write(':- set(posonly)?'),nl,
    write(':- set(c,10)?'),nl,
    write(':- set(r,2000)?'),nl,
    write(':- set(i,2)?'),nl,
    write(':- set(h,1000)?'),nl,
    write('face(c0).'),nl,
    write('face(c1).'),nl,
    write('face(c4).'),nl,
    write('face(c2).'),nl,
    write('face(c5).'),nl,
    write('face(c3).'),nl,nl,
    write(':- modeh(*,trans([+face,-face], [-face]))?'),nl,
    write(':- modeb(1,trans([+face,-face], [+face]))?'),nl,
    write(':- modeb(1,trans([+face,-face], [-face]))?'),nl,
    write(':- modeb(1,trans([-face,+face], [+face]))?'),nl,nl.


% choose1,2,... collects in the data set the data to be analysed

choose1:-
    successor(T2,T1),
    state([A,B],T1),state([C],T2),
    write('trans(['), write(A), 
    write(','), write(B),
    write('],['),write(C),
    write(']).'),nl,
    fail.

choose1.

headingII:-
    write(':- set(posonly)?'),nl,
    write(':- set(c,10)?'),nl,
    write(':- set(r,2000)?'),nl,
    write(':- set(i,2)?'),nl,
    write(':- set(h,1000)?'),nl,
    write('face(c0).'),nl,
    write('face(c1).'),nl,
    write('face(c4).'),nl,
    write('face(c2).'),nl,
    write('face(c5).'),nl,
    write('face(c3).'),nl,nl,
    write(':- modeh(*,trans([+face,-face], [-face]))?'),nl,
    write(':- modeb(1,trans([+face,-face], [+face]))?'),nl,
    write(':- modeb(1,trans([+face,-face], [-face]))?'),nl,
    write(':- modeb(1,trans([-face,+face], [+face]))?'),nl,nl,
    write('prune(Head,Body):-in(Atom,Body),clause(Atom,Body1),
           in(Head,Body1).'),nl,nl.


chooseII:-
    successor(T2,T1),
    state([A,B],T1),state([C],T2),
    write('trans(['), write(A), 
    write(','), write(B),
    write('],['),write(C),
    write(']).'),nl,
    fail.

chooseII.

heading2:-
    write(':- set(posonly)?'),nl,
    write(':- set(c,10)?'),nl,
    write(':- set(r,2000)?'),nl,
    write(':- set(h,1000)?'),nl,
    write('face(c0).'),nl,
    write('face(c1).'),nl,
    write('face(c4).'),nl,
    write('face(c2).'),nl,
    write('face(c5).'),nl,
    write('face(c3).'),nl,
    write('face([]).'),nl,nl,
    write(':- modeh(1,trans([],[+face], +time, +time))?'),nl,
    write(':- modeh(1,trans([+face,+face], [], +time, +time))?'),nl,
    write(':- modeh(1,trans([+face], [+face,+face], +time, +time))?'),nl,
    write(':- modeh(1,trans([+face,+face], [+face], +time, +time))?'),nl,
    write(':- modeh(1,trans([#face,#face], [#face], +time, +time))?'),nl,
    write(':- modeh(1,trans([+face,+face], [+face, +face], +time, +time))?'),nl,   
    write(':- modeh(1,trans([+face], [+face], +time, +time))?'),nl,
    write(':- modeb(*,successor(-time,-time))?'),nl,
    write(':- modeb(*, state([+face],-time))?'),nl,nl.



choose_Tr:-
    successor(T2,T1),
    state(S1,T1),state(S2,T2),
    write('trans('), 
    write(S1), write(','), 
    write(S2), write(','),
    write(T1), write(','),
    write(T2),write(')'),
    write('.'),nl,
    fail.
choose_Tr.

chooseT:-
    time(T),
    write('time('),
    write(T),
    write(').'),nl,
    fail.
chooseT.

chooseSu:-
    successor(T1,T2),
    write('successor('),
    write(T1),write(','),write(T2),
    write(').'),nl,
    fail.
chooseSu.


chooseSt:-
    state(S,T),
    write('state('),
    write(S),write(','),write(T),
    write(').'),nl,
    fail.
chooseSt.




