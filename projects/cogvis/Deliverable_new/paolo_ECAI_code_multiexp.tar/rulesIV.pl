:-consult(rules)?
:-generalise(trans/4)?
:-advise(data12_exp4)?
