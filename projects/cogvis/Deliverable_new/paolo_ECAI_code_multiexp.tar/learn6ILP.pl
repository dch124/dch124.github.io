
%% Paulo Santos 26/02/04
%% e-mail: psantos@comp.leeds.ac.uk


% This is a SICSTUS meta-program that reads a data.pl file and writes multiple 
% other files with different kind of predicates constructed from data.pl.
% Each of these new files are, then, generalised according to progol induction 
% style.

% In its current incarnation it writes transitivity.pl and transI.pl for 
% searching recursive rules (transI.pl is an intermediate file) and rules.pl 
% and rulesI.pl for searching time dependent relations. Progol has to be called
% from the intermediate files so that the advise/1 predicates work.

% The result of the progol generalisations are put into the files tr.pl 
% and ru.pl as defined in the clauses write_rules and write_trans. 


:- dynamic as/1.
:- op(200, fx, #).


% library needed: called in run.pl
%
%:- use_module(library(system)).

% Initialisations, functions, settings

initialise:-
    [rloop5],
    retractall(as(_)),
    assert(as([])),
    prolog_flag(redefine_warnings,X,off).


% learn/2 gets a data set, writes the experiments and calls progol,
%         the answer set for each data set is asserted as argument of 
%         a dynamic predicate as/1. as/1 is updated with the new results 
%         by updateAs/1. as/1 is initiated with [] and is updated every time
%         learn is called.
%
%   FOR THE SAME KIND OF EXP. THE SAME as/1 CAN BE USED
%   FOR DIFFERENT KINDS IT HAS TO BE REFORMULATED




learn(InputF):-
    [InputF], 
    experiment3(InputF),
    experiment1(InputF),
    experiment4(InputF).


%    experiment5(InputF).

%    experiment2(InputF).


% Looks for ordering [A,B] -> [C]

experiment1(InputF):-
    fileNameGen(InputF,'_exp1',AdvI),
    write_transI(AdvI),
    popen('xterm -e progol transI',read,S1),
    close(S1),
    fileSuffix(AdvI,'.pl',Fname),
    filter(Fname,AsI),
    updateAs(AsI).


% looks for equivalence [A,B] -> [nil]

experiment2(InputF):-
    fileNameGen(InputF,'_exp2',AdvII),
    write_transII(AdvII),
    popen('xterm -e progol transII',read,S2),
    close(S2),
    fileSuffix(AdvII,'.pl',Fname),
    filter(Fname,AsII),
    updateAs(AsII).


% looks for time-dependent rules

experiment3(InputF):-
    fileNameGen(InputF,'_exp3',Adv),
    write_rules(Adv),
    popen('xterm -e progol rulesI',read,S3),
    close(S3),
    fileSuffix(Adv,'.pl',Fname),
    filter(Fname,As),
    updateAs(As).

% experiment4 and 5 were inserted for the ILP04 paper

experiment4(InputF):-
    fileNameGen(InputF,'_exp4',Adv),
    write_rules4(Adv),
    popen('xterm -e progol rulesIV',read,S4),
    close(S4),
    fileSuffix(Adv,'.pl',Fname),
    filter(Fname,As),
    updateAs(As).

experiment5(InputF):-
    fileNameGen(InputF,'_exp5',Adv),
    write_rules5(Adv),
    popen('xterm -e progol rulesV',read,S5),
    close(S5),
    fileSuffix(Adv,'.pl',Fname),
    filter(Fname,As),
    updateAs(As).


% updateAs/1 append the new findings to as(List)

updateAs(As):-
    as(Prev),
    retract(as(Prev)),
    append(Prev,[As],List),
    assert(as(List)).
    
% fileSuffix/2 inserts the suffix .pl in the progol advised file name Adv

fileSuffix(Name,Suf,Fname):-
    atom_codes(Name,CodeList),
    atom_codes(Suf,SufList),
    append(CodeList,SufList,Cname),
    atom_codes(Fname,Cname).


% fileNameGen/3: Generates file names from data file for the experiments 
% E.g., fileNameGen(pss_snap6i, '_exp.pl',Name).


fileNameGen(Name,ExpName,FinalName):-
    atom_codes(Name,CodeList),
    atom_codes(ExpName,SufList),
    append(CodeList,SufList,Cname),
    atom_codes(FinalName,Cname),
    write(FinalName).


% write experiments searching for recursive rules (without prunning)

% transI : looks for ordering in [A,B] -> [C]

write_transI(Adv):-
    tell('transitI.pl'),
    headingI,
    choose(or,(successor(T2,T1),state([A,B],T1),state([C],T2)), trans, [A,B], [C], T1, T2),
    told,
    tell('transI.pl'),
    intermFile('transitI',trans/2,Adv),
    told.

headingI:-
    settings(posonly, 'c,10', 'r,2000', 'i,2', 'h,1000'),
    objects(face, [c0,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,nil]),nl,nl,
    mode(*, h, [trans],[[[+face,-face], [-face]]]),
    mode(1, b, [trans,trans,trans],[[[+face,-face], [+face]],
         [[+face,-face], [-face]], [[-face,+face], [+face]]]).

% writes experiments searching for recursive rules (with prunning)

% transII : looks for equivalence in [A,B] -> [nil]

write_transII(Adv):-
    tell('transitII.pl'),
    headingII,
    choose(eq,(successor(T2,T1),state([A,B],T1),state([nil],T2)), trans, [A,B], [nil], T1, T2),
    told,
    tell('transII.pl'),
    intermFile('transitII',trans/2,Adv),
    told.

headingII:-
    settings(posonly, 'c,10', 'r,2000', 'i,2', 'h,1000'),
    objects(face, [c0,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,nil]),nl,nl,
    mode(*, h, [trans],[[[+face,-face], [#face]]]),
    mode(1, b, [trans,trans,trans],[[[+face,-face], [#face]],
         [[+face,-face], [-face]], [[-face,+face], [#face]]]).


% writes experiments searching for time-dependent rules

write_rules(Adv):-
    tell('rules.pl'),
    headingRU,
    choose(time,(successor(T2,T1),state(X,T1),state(Y,T2)), trans, X, Y, T1, T2),
    told,
    tell('rulesI.pl'),
    intermFile(rules,trans/4,Adv),
    told.


headingRU:-
    settings(posonly, 'c,10', 'r,2000', 'i,3', 'h,1000'),
    objects(face, [c0,c1,c2,c3,c4,c5,nil]),nl,nl,
    mode(1, h, [trans,trans,trans,trans,trans,trans, trans, trans, trans, trans],[[[nil],[+face], +time, +time],[[+face,+face], [nil], +time, +time],[[+face], [+face,+face],+time, +time],[[+face,+face], [+face], +time, +time],[[+face,+face], [nil], +time, +time],[[+face], [+face,+face], +time, +time],[[+face,+face], [+face], +time, +time],[[#face,#face], [#face], +time, +time],[[+face,+face], [+face, +face], +time, +time],[[+face], [+face], +time, +time]]),
    mode(*,b,[successor, state],[[-time,-time],[[+face],-time]]), !.

% write_rules4

write_rules4(Adv):-
    tell('rules.pl'),
    headingRU4,
    choose(time,(successor(T2,T1),state(X,T1),state(Y,T2)), trans, X, Y, T1, T2),
    told,
    tell('rulesIV.pl'),
    intermFile(rules,trans/4,Adv),
    told.


headingRU4:-
    settings(posonly, 'c,10', 'r,2000', 'i,3', 'h,1000'),
    objects(face, [c0,c1,c2,c3,c4,c5,nil]),nl,nl, mode(1, h, [trans, trans, trans, trans],[[[+face,+face], [+face], +time, +time],[[+face], [+face,+face], +time, +time],[[+face,+face], [+face, +face], +time, +time],[[+face], [+face], +time, +time]]),mode(*,b,[successor, state],[[-time,-time],[[+face],-time]]), !.





% needed in order to call progol in the interactive mode

intermFile(In,Gen,Out):-
    write(':-consult('),
    write(In), write(')?'),nl,
    write(':-generalise('),
    write(Gen), write(')?'),nl,
    write(':-advise('),
    write(Out),write(')?'),nl.

    
% write('prune(Head,Body):-in(Atom,Body),clause(Atom,Body1),
%           in(Head,Body1).'),nl,nl.

%% mode writes the progol mode declarations.
% h defines modeh and b defines modeb

% a mode should accept any number of arguments, needs to be developed!


mode(N,HeadBody, [Pred|Preds],[Arg|Args]):-
     write(':- mode'), write(HeadBody), write('('), write(N),write(','),
     write(Pred), write('('),						    
     modeArg(Arg),
     write('))?'),nl,
     mode(N,HeadBody, Preds,Args).

mode(_,_,[],[]).

modeArg([Arg|Args]):-
    \+ Args = [],
    write(Arg),write(','), 
    modeArg(Args).

modeArg([Arg|Args]):-
    Args = [],
    write(Arg), 
    modeArg(Args).

modeArg([]).




% objects/2 writes the object sorts involved in the game

objects(Type, [L|Ls]):-
   Term =.. [Type, L],
   write(Term),write('.'),
   objects(Type, Ls).

objects(_,[]).


% settings/5 write the progol settings

settings(POS,C, R, I, H):-
    write(':- set('), write(POS),write(')?'),nl,
    write(':- set('), write(C), write(')?'),nl,
    write(':- set('), write(R), write(')?'),nl,
    write(':- set('), write(I), write(')?'),nl,
    write(':- set('), write(H), write(')?'),nl.


%% Choose/7: selects predicates to be re-written
% Currently: eq (equality), or (ordering), time (time-dependent)

choose(eq,(X,Y,Z), OutPred, Arg1, Arg2, T1, T2):-
    X,Y,Z,
    write(OutPred),write('('), write(Arg1), 
    write(','), write(Arg2),
    write(').'),nl,
   fail.

choose(or,(X,Y,Z), OutPred, Arg1, Arg2, T1, T2):-
    X,Y,Z,
    Arg2 \= [nil],
    write(OutPred),write('('), write(Arg1), 
    write(','), write(Arg2),
    write(').'),nl,
   fail.

choose(time,(X,Y,Z), OutPred, Arg1, Arg2, T1, T2):-
    X,Y,Z,
    write(X), write('.'), nl,
    write(OutPred),write('('), write(Arg1), 
    write(','), write(Arg2),
    write(','), write(T1),
    write(','), write(T2),
    write(').'),nl,
    write('time('),write(T1),write(').'),nl,
   fail.

choose(_,_,_,_,_,_,_).




