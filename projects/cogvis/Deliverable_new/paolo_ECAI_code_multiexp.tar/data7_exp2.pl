:- set(posonly)?
:- set(c,10)?
:- set(r,2000)?
:- set(i,2)?
:- set(h,1000)?
:- modeh(100,trans([+face,-face],[#face]))?
:- modeb(1,trans([+face,-face],[#face]))?
:- modeb(1,trans([+face,-face],[-face]))?
:- modeb(1,trans([-face,+face],[#face]))?
:- consult(transitII)?
:- generalise(trans/2)?

face(c0).
face(c1).
face(c2).
face(c3).
face(c4).
face(c5).
face(c6).
face(c7).
face(c8).
face(c9).
face(c10).
face(c11).
face(c12).
face(c13).
face(c14).
face(nil).

trans([c4,c0],[nil]).
trans([c0,c0],[nil]).
trans([c5,c5],[nil]).
trans([c2,c2],[nil]).
trans([c3,c3],[nil]).
trans([A,B],[nil]) :- trans([A,B],[C]).

'*trans'([A,B],[C]) :- face(A), face(B), face(C).
