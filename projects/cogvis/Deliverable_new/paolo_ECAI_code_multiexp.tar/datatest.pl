
time(dg1_4_301).
state([],dg1_4_301).
time(dg1_4_340).
successor(dg1_4_340,dg1_4_301).
state([c0],dg1_4_340).
time(dg1_4_359).
successor(dg1_4_359,dg1_4_340).
state([c5,c0],dg1_4_359).
time(dg1_4_377).
successor(dg1_4_377,dg1_4_359).
state([c5],dg1_4_377).
time(dg1_4_393).
successor(dg1_4_393,dg1_4_377).
state([c5,c0],dg1_4_393).
time(dg1_4_412).
successor(dg1_4_412,dg1_4_393).
state([c0],dg1_4_412).
time(dg1_4_430).
successor(dg1_4_430,dg1_4_412).
state([c5,c0],dg1_4_430).
time(dg1_4_452).
successor(dg1_4_452,dg1_4_430).
state([c5],dg1_4_452).
time(dg1_4_469).

