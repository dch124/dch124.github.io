:-consult(transitI)?
:-generalise(trans/2)?
:-advise(data12_exp1)?
