:- set(posonly)?
:- set(c,10)?
:- set(r,2000)?
:- set(i,3)?
:- set(h,1000)?
:- modeh(1,trans([nil],[+face],+time,+time))?
:- modeh(1,trans([+face,+face],[nil],+time,+time))?
:- modeh(1,trans([+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face],+time,+time))?
:- modeh(1,trans([+face,+face],[nil],+time,+time))?
:- modeh(1,trans([+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face],+time,+time))?
:- modeh(1,trans([#face,#face],[#face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face],[+face],+time,+time))?
:- modeb(100,successor(-time,-time))?
:- modeb(100,state([+face],-time))?
:- consult(rules)?
:- generalise(trans/4)?

face(c0).
face(c1).
face(c2).
face(c3).
face(c4).
face(c5).
face(nil).

trans([nil],[A],B,C) :- successor(C,B).
trans([c0,c1],[c1],A,B).
trans([c4,c1],[c4],A,B).
trans([A,B],[nil],C,D) :- successor(D,C).
trans([c0,c0],[c0],A,B) :- successor(B,A).
trans([c0,c5],[c5],A,B) :- successor(B,A).
trans([c5,c1],[c5],A,B).
trans([A],[B,C],D,E) :- successor(E,D).
trans([c1,c0],[c5],A,B).
trans([c0,c2],[c1],A,B).
trans([c0,c0],[c1],A,B).
trans([c0,c2],[c0],A,B).
trans([c3,c0],[c3],A,B) :- successor(B,A).
trans([c3,c4],[c3],A,B).
trans([c4,c3],[c3],A,B).
trans([c3,c2],[c3],A,B).
trans([c2,c3],[c3],A,B).
trans([c1,c2],[c3],A,B).
trans([c0,c2],[c2],A,B).
trans([c5,c0],[c5],A,B).
trans([c5,c2],[c5],A,B).
trans([c2,c0],[c5],A,B).
trans([c3,c5],[c3],A,B).

time(dg1_7_301).
time(dg1_7_326).
time(dg1_7_348).
time(dg1_7_369).
time(dg1_7_388).
time(dg1_7_411).
time(dg1_7_429).
time(dg1_7_454).
time(dg1_7_472).
time(dg1_7_491).
time(dg1_7_509).
time(dg1_7_531).
time(dg1_7_555).
time(dg1_7_574).
time(dg1_7_592).
time(dg1_7_611).
time(dg1_7_628).
time(dg1_7_647).
time(dg1_7_662).
time(dg1_7_680).
time(dg1_7_699).
time(dg1_7_718).
time(dg1_7_744).
time(dg1_7_766).
time(dg1_7_784).
time(dg1_7_802).
time(dg1_7_823).
time(dg1_7_840).
time(dg1_7_856).
time(dg1_7_872).
time(dg1_7_894).
time(dg1_7_911).
time(dg1_7_932).
time(dg1_7_955).
time(dg1_7_980).
time(dg1_7_1002).
time(dg1_7_1026).
time(dg1_7_1043).
time(dg1_7_1064).
time(dg1_7_1080).
time(dg1_7_1104).
time(dg1_7_1121).
time(dg1_7_1147).
time(dg1_7_1167).
time(dg1_7_1185).
time(dg1_7_1203).
time(dg1_7_1225).
time(dg1_7_1239).
time(dg1_7_1262).
time(dg1_7_1279).
time(dg1_7_1297).
time(dg1_7_1316).
time(dg1_7_1336).
time(dg1_7_1354).
time(dg1_7_1375).
time(dg1_7_1394).
time(dg1_7_1415).
time(dg1_7_1439).
time(dg1_7_1458).
time(dg1_7_1481).
time(dg1_7_1499).
time(dg1_7_1522).
time(dg1_7_1543).
time(dg1_7_1565).
time(dg1_7_1583).
time(dg1_7_1606).
time(dg1_7_1625).
time(dg1_7_1642).
time(dg1_7_1659).

'*trans'([nil],[A],B,C) :- face(A), time(B), time(C).
'*trans'([A,B],[nil],C,D) :- face(A), face(B), time(C), time(D).
'*trans'([A],[B,C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A,B],[C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A,B],[C,D],E,F) :- face(A), face(B), face(C), face(D),
	time(E), time(F).
'*trans'([A],[B],C,D) :- face(A), face(B), time(C), time(D).

successor(dg1_7_326,dg1_7_301).
successor(dg1_7_348,dg1_7_326).
successor(dg1_7_369,dg1_7_348).
successor(dg1_7_388,dg1_7_369).
successor(dg1_7_411,dg1_7_388).
successor(dg1_7_429,dg1_7_411).
successor(dg1_7_454,dg1_7_429).
successor(dg1_7_472,dg1_7_454).
successor(dg1_7_491,dg1_7_472).
successor(dg1_7_509,dg1_7_491).
successor(dg1_7_531,dg1_7_509).
successor(dg1_7_555,dg1_7_531).
successor(dg1_7_574,dg1_7_555).
successor(dg1_7_592,dg1_7_574).
successor(dg1_7_611,dg1_7_592).
successor(dg1_7_628,dg1_7_611).
successor(dg1_7_647,dg1_7_628).
successor(dg1_7_662,dg1_7_647).
successor(dg1_7_680,dg1_7_662).
successor(dg1_7_699,dg1_7_680).
successor(dg1_7_718,dg1_7_699).
successor(dg1_7_744,dg1_7_718).
successor(dg1_7_766,dg1_7_744).
successor(dg1_7_784,dg1_7_766).
successor(dg1_7_802,dg1_7_784).
successor(dg1_7_823,dg1_7_802).
successor(dg1_7_840,dg1_7_823).
successor(dg1_7_856,dg1_7_840).
successor(dg1_7_872,dg1_7_856).
successor(dg1_7_894,dg1_7_872).
successor(dg1_7_911,dg1_7_894).
successor(dg1_7_932,dg1_7_911).
successor(dg1_7_955,dg1_7_932).
successor(dg1_7_980,dg1_7_955).
successor(dg1_7_1002,dg1_7_980).
successor(dg1_7_1026,dg1_7_1002).
successor(dg1_7_1043,dg1_7_1026).
successor(dg1_7_1064,dg1_7_1043).
successor(dg1_7_1080,dg1_7_1064).
successor(dg1_7_1104,dg1_7_1080).
successor(dg1_7_1121,dg1_7_1104).
successor(dg1_7_1147,dg1_7_1121).
successor(dg1_7_1167,dg1_7_1147).
successor(dg1_7_1185,dg1_7_1167).
successor(dg1_7_1203,dg1_7_1185).
successor(dg1_7_1225,dg1_7_1203).
successor(dg1_7_1239,dg1_7_1225).
successor(dg1_7_1262,dg1_7_1239).
successor(dg1_7_1279,dg1_7_1262).
successor(dg1_7_1297,dg1_7_1279).
successor(dg1_7_1316,dg1_7_1297).
successor(dg1_7_1336,dg1_7_1316).
successor(dg1_7_1354,dg1_7_1336).
successor(dg1_7_1375,dg1_7_1354).
successor(dg1_7_1394,dg1_7_1375).
successor(dg1_7_1415,dg1_7_1394).
successor(dg1_7_1439,dg1_7_1415).
successor(dg1_7_1458,dg1_7_1439).
successor(dg1_7_1481,dg1_7_1458).
successor(dg1_7_1499,dg1_7_1481).
successor(dg1_7_1522,dg1_7_1499).
successor(dg1_7_1543,dg1_7_1522).
successor(dg1_7_1565,dg1_7_1543).
successor(dg1_7_1583,dg1_7_1565).
successor(dg1_7_1606,dg1_7_1583).
successor(dg1_7_1625,dg1_7_1606).
successor(dg1_7_1642,dg1_7_1625).
successor(dg1_7_1659,dg1_7_1642).
successor(dg1_7_1685,dg1_7_1659).
