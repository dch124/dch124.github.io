:- set(posonly)?
:- set(c,10)?
:- set(r,2000)?
:- set(i,2)?
:- set(h,1000)?
:- modeh(100,trans([+face,-face],[-face]))?
:- modeb(1,trans([+face,-face],[+face]))?
:- modeb(1,trans([+face,-face],[-face]))?
:- modeb(1,trans([-face,+face],[+face]))?
:- consult(transitI)?
:- generalise(trans/2)?

face(c0).
face(c1).
face(c2).
face(c3).
face(c4).
face(c5).
face(c6).
face(c7).
face(c8).
face(c9).
face(c10).
face(c11).
face(c12).
face(c13).
face(c14).
face(nil).

trans([c5,c1],[c5]).
trans([c2,c3],[c3]).
trans([c1,c3],[c3]).
trans([c0,c5],[c5]).
trans([c4,c3],[c3]).
trans([A,B],[A]) :- trans([B,A],[A]).
trans([A,B],[B]) :- trans([A,C],[D]), trans([E,A],[D]), trans([C,
	F],[B]).

'*trans'([A,B],[C]) :- face(A), face(B), face(C).
