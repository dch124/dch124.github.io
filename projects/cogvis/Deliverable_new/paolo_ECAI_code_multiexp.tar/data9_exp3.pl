:- set(posonly)?
:- set(c,10)?
:- set(r,2000)?
:- set(i,3)?
:- set(h,1000)?
:- modeh(1,trans([nil],[+face],+time,+time))?
:- modeh(1,trans([+face,+face],[nil],+time,+time))?
:- modeh(1,trans([+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face],+time,+time))?
:- modeh(1,trans([+face,+face],[nil],+time,+time))?
:- modeh(1,trans([+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face],+time,+time))?
:- modeh(1,trans([#face,#face],[#face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face],[+face],+time,+time))?
:- modeb(100,successor(-time,-time))?
:- modeb(100,state([+face],-time))?
:- consult(rules)?
:- generalise(trans/4)?

face(c0).
face(c1).
face(c2).
face(c3).
face(c4).
face(c5).
face(nil).

trans([nil],[A],B,C) :- successor(C,B).
trans([c4,c0],[c4],A,B).
trans([A],[B,C],D,E) :- successor(E,D).
trans([c0,c3],[c3],A,B) :- successor(B,A).
trans([c1,c2],[c3],A,B).
trans([c3,c4],[c3],A,B).
trans([A,A],[nil],B,C) :- successor(C,B).
trans([c1,c0],[c2],A,B).
trans([c2,c0],[c2],A,B) :- successor(B,A).
trans([c3,c2],[c3],A,B).
trans([c1,c3],[c3],A,B) :- successor(B,A).
trans([c2,c2],[c3],A,B).
trans([c2,c3],[c3],A,B) :- successor(B,A).
trans([c5,c3],[c3],A,B).
trans([c3,c1],[c3],A,B).
trans([c3,c5],[c3],A,B).
trans([c3,c0],[c3],A,B) :- successor(B,A).

time(dg1_9_301).
time(dg1_9_324).
time(dg1_9_343).
time(dg1_9_363).
time(dg1_9_383).
time(dg1_9_396).
time(dg1_9_414).
time(dg1_9_429).
time(dg1_9_443).
time(dg1_9_458).
time(dg1_9_476).
time(dg1_9_496).
time(dg1_9_517).
time(dg1_9_537).
time(dg1_9_568).
time(dg1_9_584).
time(dg1_9_603).
time(dg1_9_622).
time(dg1_9_643).
time(dg1_9_663).
time(dg1_9_681).
time(dg1_9_705).
time(dg1_9_723).
time(dg1_9_736).
time(dg1_9_752).
time(dg1_9_770).
time(dg1_9_788).
time(dg1_9_804).
time(dg1_9_819).
time(dg1_9_831).
time(dg1_9_849).
time(dg1_9_866).
time(dg1_9_881).
time(dg1_9_898).
time(dg1_9_913).
time(dg1_9_932).
time(dg1_9_949).
time(dg1_9_963).
time(dg1_9_978).
time(dg1_9_995).
time(dg1_9_1008).
time(dg1_9_1029).
time(dg1_9_1042).
time(dg1_9_1060).
time(dg1_9_1076).
time(dg1_9_1091).
time(dg1_9_1107).
time(dg1_9_1124).
time(dg1_9_1140).
time(dg1_9_1157).
time(dg1_9_1171).
time(dg1_9_1187).
time(dg1_9_1204).
time(dg1_9_1219).
time(dg1_9_1240).
time(dg1_9_1257).
time(dg1_9_1274).
time(dg1_9_1287).

'*trans'([nil],[A],B,C) :- face(A), time(B), time(C).
'*trans'([A,B],[nil],C,D) :- face(A), face(B), time(C), time(D).
'*trans'([A],[B,C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A,B],[C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A,B],[C,D],E,F) :- face(A), face(B), face(C), face(D),
	time(E), time(F).
'*trans'([A],[B],C,D) :- face(A), face(B), time(C), time(D).

successor(dg1_9_324,dg1_9_301).
successor(dg1_9_343,dg1_9_324).
successor(dg1_9_363,dg1_9_343).
successor(dg1_9_383,dg1_9_363).
successor(dg1_9_396,dg1_9_383).
successor(dg1_9_414,dg1_9_396).
successor(dg1_9_429,dg1_9_414).
successor(dg1_9_443,dg1_9_429).
successor(dg1_9_458,dg1_9_443).
successor(dg1_9_476,dg1_9_458).
successor(dg1_9_496,dg1_9_476).
successor(dg1_9_517,dg1_9_496).
successor(dg1_9_537,dg1_9_517).
successor(dg1_9_568,dg1_9_537).
successor(dg1_9_584,dg1_9_568).
successor(dg1_9_603,dg1_9_584).
successor(dg1_9_622,dg1_9_603).
successor(dg1_9_643,dg1_9_622).
successor(dg1_9_663,dg1_9_643).
successor(dg1_9_681,dg1_9_663).
successor(dg1_9_705,dg1_9_681).
successor(dg1_9_723,dg1_9_705).
successor(dg1_9_736,dg1_9_723).
successor(dg1_9_752,dg1_9_736).
successor(dg1_9_770,dg1_9_752).
successor(dg1_9_788,dg1_9_770).
successor(dg1_9_804,dg1_9_788).
successor(dg1_9_819,dg1_9_804).
successor(dg1_9_831,dg1_9_819).
successor(dg1_9_849,dg1_9_831).
successor(dg1_9_866,dg1_9_849).
successor(dg1_9_881,dg1_9_866).
successor(dg1_9_898,dg1_9_881).
successor(dg1_9_913,dg1_9_898).
successor(dg1_9_932,dg1_9_913).
successor(dg1_9_949,dg1_9_932).
successor(dg1_9_963,dg1_9_949).
successor(dg1_9_978,dg1_9_963).
successor(dg1_9_995,dg1_9_978).
successor(dg1_9_1008,dg1_9_995).
successor(dg1_9_1029,dg1_9_1008).
successor(dg1_9_1042,dg1_9_1029).
successor(dg1_9_1060,dg1_9_1042).
successor(dg1_9_1076,dg1_9_1060).
successor(dg1_9_1091,dg1_9_1076).
successor(dg1_9_1107,dg1_9_1091).
successor(dg1_9_1124,dg1_9_1107).
successor(dg1_9_1140,dg1_9_1124).
successor(dg1_9_1157,dg1_9_1140).
successor(dg1_9_1171,dg1_9_1157).
successor(dg1_9_1187,dg1_9_1171).
successor(dg1_9_1204,dg1_9_1187).
successor(dg1_9_1219,dg1_9_1204).
successor(dg1_9_1240,dg1_9_1219).
successor(dg1_9_1257,dg1_9_1240).
successor(dg1_9_1274,dg1_9_1257).
successor(dg1_9_1287,dg1_9_1274).
successor(dg1_9_1299,dg1_9_1287).
