:-consult(transitII)?
:-generalise(trans/2)?
:-advise(pss_snap3i_exp2)?
