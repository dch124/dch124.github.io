
% Implements a loop that reads the answer files and puts the results of the
% generalisations in a list asserted as asets(L).

% can be inserted at the end of generalise() command in the integrate progs.

:- dynamic asets/1.

% Libraries needed: called in run.pl
%
%:- use_module(library(charsio)).
%:- use_module(library(lists)).


% filter/2 should be initialised with the file to be filtered (File) and outputs the asnwer set As

filter(File, As):-
    absolute_file_name(File,File2),
    open(File2,read,Stream),
    retractall(asets(X)),
    assert(asets([])),
    loop(Stream),
    close(Stream),
    asets(List),
    reverse(List,As).

% reads progol output

loop(Stream):-
    repeat,
    read_term(Stream, Term,[syntax_errors(quiet)]),
    select(Stream, Term),
    Term == end_of_file,
    !.
    
% selects the desired formulae

select(Stream, end_of_file).

% If Term is a ground formula move on

select(Stream, Term):-
    ground(Term),
    !,fail.

% if it is a compound formula, insert it in the answer set

select(Stream, Term):-
    compound(Term),
    insert(Term),!.

insert(Term):-
    asets(T1),
    append([Term],T1,T),
    retract(asets(T1)),
    assert(asets(T)).


