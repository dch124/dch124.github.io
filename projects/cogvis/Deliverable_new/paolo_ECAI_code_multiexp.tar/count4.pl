%% Paulo Santos 26/02/04
%% e-mail: psantos@comp.leeds.ac.uk


%% Counts the number of time a formula appears in the answer sets.

% libraries needed, defined in run.pl:

% :- use_module(library(lists)).
% :- use_module(library(terms)).

:- dynamic aux/1.

% input test list:
 initial([[a(X,Y),b(d,f,V)],[a(a,f),f(g,h),p],[f(g,h),a(W,R)]]).
    

% sweep(I,O): I is the input list of answer sets, O is the final answer set (i.e. every formulae that scored more than once. For the time being, the remainder formulae are discarded.

% test rule

 test(I,O):-
    initial(I),
    sweep(I,O),!. 

% sweep/2 counts the number of subsumptions of each formulae in the answer set
%         deletes the weaker formula when there is a match								  

sweep(I,O):-
    sweep1(I,O1),
    flatten(O1,O).									     

sweep1([L|Ls],[Out|Outs]):- 
    count(L,Ls,Out,Res),
    sweep1(Res,Outs).								     

sweep1([],[]).


% removes nested lists

flatten([[X|L1]|L2],L):-
	conc([X|L1],L2,L3),
	flatten(L3,L),!.
flatten([[]|L1],L):-
	flatten(L1,L),!.
flatten([X|L1],[X|L]):-
	flatten(L1,L),!.
flatten([],[]).

% concatenation of lists

conc([],L,L).
conc([X|L1],L2,[X|L]):-
	conc(L1,L2,L),!.
									     

% counts and deletes formulae in the answer set				       				    
count([El|Els],Lists,[(X,N)|Outs],Olist):-
    retractall(aux(_)),
    assert(aux(1)),
    count2(El,Lists,X),
    delete2(El,Lists,Res),
    aux(N),
    count(Els,Res,Outs,Olist).

count([],Resid,[],Resid).

delete2(El,[L|Ls],[Re|Res]):-
    exclude(El,L,Re),
    delete2(El,Ls,Res).

delete2(_,[],[]).

% exclude/3: deletes subsumed formulae and keeps the lest general

exclude(El,[L|Ls],Ls):-
    subsumes_chk(El,L).

exclude(El,[L|Ls],Ls):-
    subsumes_chk(L,El).

exclude(El,[L|Ls],[L|Zs]):-
    exclude(El,Ls,Zs).

exclude(_,[],[]).


% count2/3 checks whether El subsumes or is subsumed by any other formula in the intermediate answer set

count2(El,[L|Ls],X):-
    member2(El,L,GEl),
    count2(GEl,Ls,X).

count2(GEl,[],GEl).

% member2/3 checks for formula subsumption

member2(X,[Y|_],Y):-
    subsumes_chk(X,Y),
    counter.

member2(X,[Y|_],X):-
    subsumes_chk(Y,X),
    counter.

member2(X,[],X).
member2(X,[_|Xs],Z):-
    member2(X,Xs,Z).

counter:-
    aux(X),
    retract(aux(X)),
    Y is X+1,
    assert(aux(Y)).
