
%% Version 1.0 - works better but do not generalise

%writeC(X,Y):-
%    [datatest],
%    tell('choose.dat'),
%    choose((successor(T2,T1),state(X,T1),state(Y,T2)), trans, X, Y, T2, T1),
%    told.
%
%choose((X,Y,Z), OutPred, Arg1, Arg2, T2, T1):-
%    X,Y,Z,
%    write(OutPred),write('('), write(Arg1), 
%    write(','), write(Arg2),
%    write(').'),nl,!,
%    choose((successor(T3,T2),state(XX,T3),state(YY,T2)), trans, XX, YY, T3, T2).
%choose(_,_,_,_,_,_).


%% Version 2.0 - works for all! But still needs to generalise the number of pred. to call


writeC:-
    [data4],
    tell('choose.dat'),
%    choose(eq,(successor(T2,T1),state([A,B],T1),state([],T2)), trans, [A,B], [], T1, T2),
%    choose(or,(successor(T2,T1),state([A,B],T1),state([C],T2)), trans, [A,B], [C], T1, T2),
    choose(time,(successor(T2,T1),state(X,T1),state(Y,T2)), trans, X, Y, T1, T2), 
    told.

choose(eq,(X,Y,Z), OutPred, Arg1, Arg2, T1, T2):-
    X,Y,Z,
    write(OutPred),write('('), write(Arg1), 
    write(','), write(Arg2),
    write(').'),nl,
   fail.

choose(or,(X,Y,Z), OutPred, Arg1, Arg2, T1, T2):-
    X,Y,Z,
    Arg2 \= [],
    write(OutPred),write('('), write(Arg1), 
    write(','), write(Arg2),
    write(').'),nl,
   fail.

choose(time,(X,Y,Z), OutPred, Arg1, Arg2, T1, T2):-
    X,Y,Z,
    write(X), write('.'), nl,
    write(OutPred),write('('), write(Arg1), 
    write(','), write(Arg2),
    write(','), write(T1),
    write(','), write(T2),
    write(').'),nl,
   fail.

choose(_,_,_,_,_,_,_).

