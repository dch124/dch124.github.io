:- set(posonly)?
:- set(c,10)?
:- set(r,2000)?
:- set(i,3)?
:- set(h,1000)?
:- modeh(1,trans([+face,+face],[+face],+time,+time))?
:- modeh(1,trans([+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face],[+face],+time,+time))?
:- modeb(100,successor(-time,-time))?
:- modeb(100,state([+face],-time))?
:- consult(rules)?
:- generalise(trans/4)?

face(c0).
face(c1).
face(c2).
face(c3).
face(c4).
face(c5).
face(nil).

trans([A],[B],C,D) :- successor(D,C).
trans([A],[B,C],D,E) :- successor(E,D).
trans([A,B],[C],D,E) :- successor(E,D).

time(dg1_8_301).
time(dg1_8_324).
time(dg1_8_340).
time(dg1_8_363).
time(dg1_8_376).
time(dg1_8_389).
time(dg1_8_405).
time(dg1_8_418).
time(dg1_8_441).
time(dg1_8_454).
time(dg1_8_469).
time(dg1_8_483).
time(dg1_8_500).
time(dg1_8_511).
time(dg1_8_529).
time(dg1_8_543).
time(dg1_8_559).
time(dg1_8_571).
time(dg1_8_587).
time(dg1_8_604).
time(dg1_8_622).
time(dg1_8_635).
time(dg1_8_655).
time(dg1_8_674).
time(dg1_8_692).
time(dg1_8_712).
time(dg1_8_735).
time(dg1_8_753).
time(dg1_8_773).
time(dg1_8_790).
time(dg1_8_811).
time(dg1_8_832).
time(dg1_8_861).
time(dg1_8_877).
time(dg1_8_898).
time(dg1_8_916).
time(dg1_8_934).
time(dg1_8_952).
time(dg1_8_971).
time(dg1_8_992).
time(dg1_8_1006).
time(dg1_8_1025).
time(dg1_8_1042).
time(dg1_8_1059).
time(dg1_8_1077).
time(dg1_8_1100).
time(dg1_8_1121).
time(dg1_8_1134).
time(dg1_8_1155).
time(dg1_8_1172).
time(dg1_8_1193).
time(dg1_8_1216).
time(dg1_8_1229).
time(dg1_8_1246).
time(dg1_8_1264).
time(dg1_8_1285).
time(dg1_8_1298).
time(dg1_8_1315).
time(dg1_8_1332).
time(dg1_8_1353).
time(dg1_8_1369).
time(dg1_8_1387).
time(dg1_8_1403).
time(dg1_8_1421).
time(dg1_8_1438).
time(dg1_8_1458).
time(dg1_8_1490).
time(dg1_8_1509).
time(dg1_8_1526).
time(dg1_8_1542).
time(dg1_8_1561).
time(dg1_8_1580).
time(dg1_8_1597).
time(dg1_8_1613).
time(dg1_8_1630).
time(dg1_8_1652).
time(dg1_8_1672).
time(dg1_8_1691).
time(dg1_8_1713).
time(dg1_8_1733).
time(dg1_8_1748).
time(dg1_8_1764).
time(dg1_8_1778).
time(dg1_8_1799).
time(dg1_8_1816).
time(dg1_8_1835).
time(dg1_8_1856).
time(dg1_8_1874).
time(dg1_8_1894).
time(dg1_8_1915).
time(dg1_8_1929).
time(dg1_8_1949).
time(dg1_8_1963).
time(dg1_8_1994).
time(dg1_8_2015).
time(dg1_8_2031).
time(dg1_8_2054).
time(dg1_8_2068).
time(dg1_8_2082).
time(dg1_8_2100).
time(dg1_8_2119).
time(dg1_8_2132).
time(dg1_8_2148).
time(dg1_8_2165).
time(dg1_8_2178).
time(dg1_8_2198).
time(dg1_8_2227).
time(dg1_8_2244).

'*trans'([A,B],[C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A],[B,C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A,B],[C,D],E,F) :- face(A), face(B), face(C), face(D),
	time(E), time(F).
'*trans'([A],[B],C,D) :- face(A), face(B), time(C), time(D).

successor(dg1_8_324,dg1_8_301).
successor(dg1_8_340,dg1_8_324).
successor(dg1_8_363,dg1_8_340).
successor(dg1_8_376,dg1_8_363).
successor(dg1_8_389,dg1_8_376).
successor(dg1_8_405,dg1_8_389).
successor(dg1_8_418,dg1_8_405).
successor(dg1_8_441,dg1_8_418).
successor(dg1_8_454,dg1_8_441).
successor(dg1_8_469,dg1_8_454).
successor(dg1_8_483,dg1_8_469).
successor(dg1_8_500,dg1_8_483).
successor(dg1_8_511,dg1_8_500).
successor(dg1_8_529,dg1_8_511).
successor(dg1_8_543,dg1_8_529).
successor(dg1_8_559,dg1_8_543).
successor(dg1_8_571,dg1_8_559).
successor(dg1_8_587,dg1_8_571).
successor(dg1_8_604,dg1_8_587).
successor(dg1_8_622,dg1_8_604).
successor(dg1_8_635,dg1_8_622).
successor(dg1_8_655,dg1_8_635).
successor(dg1_8_674,dg1_8_655).
successor(dg1_8_692,dg1_8_674).
successor(dg1_8_712,dg1_8_692).
successor(dg1_8_735,dg1_8_712).
successor(dg1_8_753,dg1_8_735).
successor(dg1_8_773,dg1_8_753).
successor(dg1_8_790,dg1_8_773).
successor(dg1_8_811,dg1_8_790).
successor(dg1_8_832,dg1_8_811).
successor(dg1_8_861,dg1_8_832).
successor(dg1_8_877,dg1_8_861).
successor(dg1_8_898,dg1_8_877).
successor(dg1_8_916,dg1_8_898).
successor(dg1_8_934,dg1_8_916).
successor(dg1_8_952,dg1_8_934).
successor(dg1_8_971,dg1_8_952).
successor(dg1_8_992,dg1_8_971).
successor(dg1_8_1006,dg1_8_992).
successor(dg1_8_1025,dg1_8_1006).
successor(dg1_8_1042,dg1_8_1025).
successor(dg1_8_1059,dg1_8_1042).
successor(dg1_8_1077,dg1_8_1059).
successor(dg1_8_1100,dg1_8_1077).
successor(dg1_8_1121,dg1_8_1100).
successor(dg1_8_1134,dg1_8_1121).
successor(dg1_8_1155,dg1_8_1134).
successor(dg1_8_1172,dg1_8_1155).
successor(dg1_8_1193,dg1_8_1172).
successor(dg1_8_1216,dg1_8_1193).
successor(dg1_8_1229,dg1_8_1216).
successor(dg1_8_1246,dg1_8_1229).
successor(dg1_8_1264,dg1_8_1246).
successor(dg1_8_1285,dg1_8_1264).
successor(dg1_8_1298,dg1_8_1285).
successor(dg1_8_1315,dg1_8_1298).
successor(dg1_8_1332,dg1_8_1315).
successor(dg1_8_1353,dg1_8_1332).
successor(dg1_8_1369,dg1_8_1353).
successor(dg1_8_1387,dg1_8_1369).
successor(dg1_8_1403,dg1_8_1387).
successor(dg1_8_1421,dg1_8_1403).
successor(dg1_8_1438,dg1_8_1421).
successor(dg1_8_1458,dg1_8_1438).
successor(dg1_8_1490,dg1_8_1458).
successor(dg1_8_1509,dg1_8_1490).
successor(dg1_8_1526,dg1_8_1509).
successor(dg1_8_1542,dg1_8_1526).
successor(dg1_8_1561,dg1_8_1542).
successor(dg1_8_1580,dg1_8_1561).
successor(dg1_8_1597,dg1_8_1580).
successor(dg1_8_1613,dg1_8_1597).
successor(dg1_8_1630,dg1_8_1613).
successor(dg1_8_1652,dg1_8_1630).
successor(dg1_8_1672,dg1_8_1652).
successor(dg1_8_1691,dg1_8_1672).
successor(dg1_8_1713,dg1_8_1691).
successor(dg1_8_1733,dg1_8_1713).
successor(dg1_8_1748,dg1_8_1733).
successor(dg1_8_1764,dg1_8_1748).
successor(dg1_8_1778,dg1_8_1764).
successor(dg1_8_1799,dg1_8_1778).
successor(dg1_8_1816,dg1_8_1799).
successor(dg1_8_1835,dg1_8_1816).
successor(dg1_8_1856,dg1_8_1835).
successor(dg1_8_1874,dg1_8_1856).
successor(dg1_8_1894,dg1_8_1874).
successor(dg1_8_1915,dg1_8_1894).
successor(dg1_8_1929,dg1_8_1915).
successor(dg1_8_1949,dg1_8_1929).
successor(dg1_8_1963,dg1_8_1949).
successor(dg1_8_1994,dg1_8_1963).
successor(dg1_8_2015,dg1_8_1994).
successor(dg1_8_2031,dg1_8_2015).
successor(dg1_8_2054,dg1_8_2031).
successor(dg1_8_2068,dg1_8_2054).
successor(dg1_8_2082,dg1_8_2068).
successor(dg1_8_2100,dg1_8_2082).
successor(dg1_8_2119,dg1_8_2100).
successor(dg1_8_2132,dg1_8_2119).
successor(dg1_8_2148,dg1_8_2132).
successor(dg1_8_2165,dg1_8_2148).
successor(dg1_8_2178,dg1_8_2165).
successor(dg1_8_2198,dg1_8_2178).
successor(dg1_8_2227,dg1_8_2198).
successor(dg1_8_2244,dg1_8_2227).
successor(dg1_8_2262,dg1_8_2244).
