:- set(posonly)?
:- set(c,10)?
:- set(r,2000)?
:- set(i,3)?
:- set(h,1000)?
:- modeh(1,trans([+face,+face],[+face],+time,+time))?
:- modeh(1,trans([+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face],[+face],+time,+time))?
:- modeb(100,successor(-time,-time))?
:- modeb(100,state([+face],-time))?
:- consult(rules)?
:- generalise(trans/4)?

face(c0).
face(c1).
face(c2).
face(c3).
face(c4).
face(c5).
face(nil).

trans([A],[B],C,D) :- successor(D,C).
trans([A],[B,C],D,E) :- successor(D,F), successor(E,D).
trans([A,B],[C],D,E) :- successor(E,D).

time(dg1_12_301).
time(dg1_12_339).
time(dg1_12_359).
time(dg1_12_377).
time(dg1_12_397).
time(dg1_12_416).
time(dg1_12_438).
time(dg1_12_463).
time(dg1_12_482).
time(dg1_12_501).
time(dg1_12_519).
time(dg1_12_536).
time(dg1_12_558).
time(dg1_12_577).
time(dg1_12_598).
time(dg1_12_621).
time(dg1_12_637).
time(dg1_12_654).
time(dg1_12_674).
time(dg1_12_695).
time(dg1_12_714).
time(dg1_12_732).
time(dg1_12_752).
time(dg1_12_777).
time(dg1_12_800).
time(dg1_12_826).
time(dg1_12_838).
time(dg1_12_856).
time(dg1_12_872).
time(dg1_12_892).
time(dg1_12_907).
time(dg1_12_927).
time(dg1_12_945).
time(dg1_12_963).
time(dg1_12_983).
time(dg1_12_1003).
time(dg1_12_1030).
time(dg1_12_1052).
time(dg1_12_1068).
time(dg1_12_1092).
time(dg1_12_1122).
time(dg1_12_1141).
time(dg1_12_1171).
time(dg1_12_1203).
time(dg1_12_1229).
time(dg1_12_1248).
time(dg1_12_1271).
time(dg1_12_1290).
time(dg1_12_1318).
time(dg1_12_1341).
time(dg1_12_1363).
time(dg1_12_1388).
time(dg1_12_1416).
time(dg1_12_1438).
time(dg1_12_1463).
time(dg1_12_1486).
time(dg1_12_1507).
time(dg1_12_1529).
time(dg1_12_1549).
time(dg1_12_1570).
time(dg1_12_1592).

'*trans'([A,B],[C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A],[B,C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A,B],[C,D],E,F) :- face(A), face(B), face(C), face(D),
	time(E), time(F).
'*trans'([A],[B],C,D) :- face(A), face(B), time(C), time(D).

successor(dg1_12_339,dg1_12_301).
successor(dg1_12_359,dg1_12_339).
successor(dg1_12_377,dg1_12_359).
successor(dg1_12_397,dg1_12_377).
successor(dg1_12_416,dg1_12_397).
successor(dg1_12_438,dg1_12_416).
successor(dg1_12_463,dg1_12_438).
successor(dg1_12_482,dg1_12_463).
successor(dg1_12_501,dg1_12_482).
successor(dg1_12_519,dg1_12_501).
successor(dg1_12_536,dg1_12_519).
successor(dg1_12_558,dg1_12_536).
successor(dg1_12_577,dg1_12_558).
successor(dg1_12_598,dg1_12_577).
successor(dg1_12_621,dg1_12_598).
successor(dg1_12_637,dg1_12_621).
successor(dg1_12_654,dg1_12_637).
successor(dg1_12_674,dg1_12_654).
successor(dg1_12_695,dg1_12_674).
successor(dg1_12_714,dg1_12_695).
successor(dg1_12_732,dg1_12_714).
successor(dg1_12_752,dg1_12_732).
successor(dg1_12_777,dg1_12_752).
successor(dg1_12_800,dg1_12_777).
successor(dg1_12_826,dg1_12_800).
successor(dg1_12_838,dg1_12_826).
successor(dg1_12_856,dg1_12_838).
successor(dg1_12_872,dg1_12_856).
successor(dg1_12_892,dg1_12_872).
successor(dg1_12_907,dg1_12_892).
successor(dg1_12_927,dg1_12_907).
successor(dg1_12_945,dg1_12_927).
successor(dg1_12_963,dg1_12_945).
successor(dg1_12_983,dg1_12_963).
successor(dg1_12_1003,dg1_12_983).
successor(dg1_12_1030,dg1_12_1003).
successor(dg1_12_1052,dg1_12_1030).
successor(dg1_12_1068,dg1_12_1052).
successor(dg1_12_1092,dg1_12_1068).
successor(dg1_12_1122,dg1_12_1092).
successor(dg1_12_1141,dg1_12_1122).
successor(dg1_12_1171,dg1_12_1141).
successor(dg1_12_1203,dg1_12_1171).
successor(dg1_12_1229,dg1_12_1203).
successor(dg1_12_1248,dg1_12_1229).
successor(dg1_12_1271,dg1_12_1248).
successor(dg1_12_1290,dg1_12_1271).
successor(dg1_12_1318,dg1_12_1290).
successor(dg1_12_1341,dg1_12_1318).
successor(dg1_12_1363,dg1_12_1341).
successor(dg1_12_1388,dg1_12_1363).
successor(dg1_12_1416,dg1_12_1388).
successor(dg1_12_1438,dg1_12_1416).
successor(dg1_12_1463,dg1_12_1438).
successor(dg1_12_1486,dg1_12_1463).
successor(dg1_12_1507,dg1_12_1486).
successor(dg1_12_1529,dg1_12_1507).
successor(dg1_12_1549,dg1_12_1529).
successor(dg1_12_1570,dg1_12_1549).
successor(dg1_12_1592,dg1_12_1570).
successor(dg1_12_1615,dg1_12_1592).
