:- set(posonly)?
:- set(c,10)?
:- set(r,2000)?
:- set(i,3)?
:- set(h,1000)?
:- modeh(1,trans([+face,+face],[+face],+time,+time))?
:- modeh(1,trans([+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face,+face],[+face,+face],+time,+time))?
:- modeh(1,trans([+face],[+face],+time,+time))?
:- modeb(100,successor(-time,-time))?
:- modeb(100,state([+face],-time))?
:- consult(rules)?
:- generalise(trans/4)?

face(c0).
face(c1).
face(c2).
face(c3).
face(c4).
face(c5).
face(nil).

trans([A],[B],C,D) :- successor(D,C).
trans([A],[A,B],C,D) :- successor(D,C).
trans([A],[B,A],C,D) :- successor(D,C).
trans([A,B],[C],D,E) :- successor(E,D).

time(dg1_6_301).
time(dg1_6_325).
time(dg1_6_343).
time(dg1_6_363).
time(dg1_6_384).
time(dg1_6_401).
time(dg1_6_422).
time(dg1_6_438).
time(dg1_6_460).
time(dg1_6_482).
time(dg1_6_499).
time(dg1_6_518).
time(dg1_6_532).
time(dg1_6_553).
time(dg1_6_569).
time(dg1_6_586).
time(dg1_6_600).
time(dg1_6_620).
time(dg1_6_636).
time(dg1_6_652).
time(dg1_6_668).
time(dg1_6_683).
time(dg1_6_703).
time(dg1_6_718).
time(dg1_6_742).
time(dg1_6_761).
time(dg1_6_779).
time(dg1_6_805).
time(dg1_6_822).
time(dg1_6_836).
time(dg1_6_855).
time(dg1_6_873).
time(dg1_6_890).
time(dg1_6_909).
time(dg1_6_925).
time(dg1_6_946).
time(dg1_6_972).
time(dg1_6_992).
time(dg1_6_1010).
time(dg1_6_1028).
time(dg1_6_1046).
time(dg1_6_1062).
time(dg1_6_1078).
time(dg1_6_1096).
time(dg1_6_1111).
time(dg1_6_1132).
time(dg1_6_1147).
time(dg1_6_1165).
time(dg1_6_1182).
time(dg1_6_1197).
time(dg1_6_1216).
time(dg1_6_1228).
time(dg1_6_1249).
time(dg1_6_1266).
time(dg1_6_1282).
time(dg1_6_1298).
time(dg1_6_1316).
time(dg1_6_1330).
time(dg1_6_1351).
time(dg1_6_1364).
time(dg1_6_1383).
time(dg1_6_1399).
time(dg1_6_1416).
time(dg1_6_1433).
time(dg1_6_1450).
time(dg1_6_1464).
time(dg1_6_1486).
time(dg1_6_1499).
time(dg1_6_1517).
time(dg1_6_1532).
time(dg1_6_1551).
time(dg1_6_1569).
time(dg1_6_1582).
time(dg1_6_1601).
time(dg1_6_1615).

'*trans'([A,B],[C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A],[B,C],D,E) :- face(A), face(B), face(C), time(D),
	time(E).
'*trans'([A,B],[C,D],E,F) :- face(A), face(B), face(C), face(D),
	time(E), time(F).
'*trans'([A],[B],C,D) :- face(A), face(B), time(C), time(D).

successor(dg1_6_325,dg1_6_301).
successor(dg1_6_343,dg1_6_325).
successor(dg1_6_363,dg1_6_343).
successor(dg1_6_384,dg1_6_363).
successor(dg1_6_401,dg1_6_384).
successor(dg1_6_422,dg1_6_401).
successor(dg1_6_438,dg1_6_422).
successor(dg1_6_460,dg1_6_438).
successor(dg1_6_482,dg1_6_460).
successor(dg1_6_499,dg1_6_482).
successor(dg1_6_518,dg1_6_499).
successor(dg1_6_532,dg1_6_518).
successor(dg1_6_553,dg1_6_532).
successor(dg1_6_569,dg1_6_553).
successor(dg1_6_586,dg1_6_569).
successor(dg1_6_600,dg1_6_586).
successor(dg1_6_620,dg1_6_600).
successor(dg1_6_636,dg1_6_620).
successor(dg1_6_652,dg1_6_636).
successor(dg1_6_668,dg1_6_652).
successor(dg1_6_683,dg1_6_668).
successor(dg1_6_703,dg1_6_683).
successor(dg1_6_718,dg1_6_703).
successor(dg1_6_742,dg1_6_718).
successor(dg1_6_761,dg1_6_742).
successor(dg1_6_779,dg1_6_761).
successor(dg1_6_805,dg1_6_779).
successor(dg1_6_822,dg1_6_805).
successor(dg1_6_836,dg1_6_822).
successor(dg1_6_855,dg1_6_836).
successor(dg1_6_873,dg1_6_855).
successor(dg1_6_890,dg1_6_873).
successor(dg1_6_909,dg1_6_890).
successor(dg1_6_925,dg1_6_909).
successor(dg1_6_946,dg1_6_925).
successor(dg1_6_972,dg1_6_946).
successor(dg1_6_992,dg1_6_972).
successor(dg1_6_1010,dg1_6_992).
successor(dg1_6_1028,dg1_6_1010).
successor(dg1_6_1046,dg1_6_1028).
successor(dg1_6_1062,dg1_6_1046).
successor(dg1_6_1078,dg1_6_1062).
successor(dg1_6_1096,dg1_6_1078).
successor(dg1_6_1111,dg1_6_1096).
successor(dg1_6_1132,dg1_6_1111).
successor(dg1_6_1147,dg1_6_1132).
successor(dg1_6_1165,dg1_6_1147).
successor(dg1_6_1182,dg1_6_1165).
successor(dg1_6_1197,dg1_6_1182).
successor(dg1_6_1216,dg1_6_1197).
successor(dg1_6_1228,dg1_6_1216).
successor(dg1_6_1249,dg1_6_1228).
successor(dg1_6_1266,dg1_6_1249).
successor(dg1_6_1282,dg1_6_1266).
successor(dg1_6_1298,dg1_6_1282).
successor(dg1_6_1316,dg1_6_1298).
successor(dg1_6_1330,dg1_6_1316).
successor(dg1_6_1351,dg1_6_1330).
successor(dg1_6_1364,dg1_6_1351).
successor(dg1_6_1383,dg1_6_1364).
successor(dg1_6_1399,dg1_6_1383).
successor(dg1_6_1416,dg1_6_1399).
successor(dg1_6_1433,dg1_6_1416).
successor(dg1_6_1450,dg1_6_1433).
successor(dg1_6_1464,dg1_6_1450).
successor(dg1_6_1486,dg1_6_1464).
successor(dg1_6_1499,dg1_6_1486).
successor(dg1_6_1517,dg1_6_1499).
successor(dg1_6_1532,dg1_6_1517).
successor(dg1_6_1551,dg1_6_1532).
successor(dg1_6_1569,dg1_6_1551).
successor(dg1_6_1582,dg1_6_1569).
successor(dg1_6_1601,dg1_6_1582).
successor(dg1_6_1615,dg1_6_1601).
successor(dg1_6_1631,dg1_6_1615).
